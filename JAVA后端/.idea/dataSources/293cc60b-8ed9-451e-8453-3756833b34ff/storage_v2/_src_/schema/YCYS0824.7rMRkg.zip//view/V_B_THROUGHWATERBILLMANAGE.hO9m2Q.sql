create view V_B_THROUGHWATERBILLMANAGE as
select distinct bi."USERINFOID",
    (select sum(WATERATE) from BILL where USERINFOID = bi.userinfoid) as Arrearscount,
bi."METERINFOID",bi."METERCODE",bi."BILLSTATE",bi."INVOICEPRINTSTATE",
   case bi.Billstate when 1 then '已缴费'
                 when 2 then '未缴费'
                   else '' end as BillstateName,
           case bi.INVOICEPRINTSTATE when 1 then '已打印'
                                    when 2 then '未打印'
                                    when 3 then '延迟打印'
                   else '' end as INVOICEPRINTSTATEName,
            case ui.userstate when 8 then '停水中'

                   else '' end as userstateName,

ui."USERNAME",ui."USERADDRESS",ui."CONTECT",ui."CONTECTPERSON",ui."EMAIL",ui."ACCOUNTMMONEY",ui."USERINFOCODE",ui."USERSTATE",
r."ROSTERID",r."ROSTERCODE",r."ROSTERNAME"
   from BILL bi
    left join am_u_userinfo ui on bi.userinfoid=ui.userinfoid
    left join am_r_roster r on ui.rosterid=r.rosterid


/

