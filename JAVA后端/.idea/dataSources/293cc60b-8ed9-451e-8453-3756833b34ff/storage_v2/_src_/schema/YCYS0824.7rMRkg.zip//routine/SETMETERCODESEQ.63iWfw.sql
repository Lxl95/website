create procedure SetMeterCodeSeq(
  mValue long
)  is


begin

execute immediate 'alter sequence Seq_MeterCode increment by ' || mValue;

end SetMeterCodeSeq;


/

