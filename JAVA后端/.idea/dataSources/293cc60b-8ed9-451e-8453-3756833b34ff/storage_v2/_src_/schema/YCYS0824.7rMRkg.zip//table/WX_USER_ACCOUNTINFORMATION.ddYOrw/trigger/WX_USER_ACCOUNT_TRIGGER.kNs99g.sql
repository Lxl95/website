create trigger WX_USER_ACCOUNT_TRIGGER
    before insert
    on WX_USER_ACCOUNTINFORMATION
    for each row
begin
  select wx_user_accountInformation_sq.nextval into :NEW.id from dual;
end;

/

