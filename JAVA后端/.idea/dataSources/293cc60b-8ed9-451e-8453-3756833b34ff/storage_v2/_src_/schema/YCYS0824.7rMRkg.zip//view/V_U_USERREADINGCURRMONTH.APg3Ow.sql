create view V_U_USERREADINGCURRMONTH as
SELECT r.meterreaderid,
       sm.cadminname,
       u.welladd,
       u.meterwalladdress,
       u.contect,
       u.mixwatertypeid,
       u.mixwatertype,
       u.mixwaterrate,
       u.mixwaterflow,
       u.usewatertypeid,
       bu.usewatertypename,
       l.LOCATIOAREAID,
       l.locationareacode,
       l.locationareaname,
       c.communtyid,
       c.communtycode,
       c.communtyname,
       r.rostercode,
       r.rosterid,
       r.rostername,
       u.userinfoid,
       u.userstate,
       u.userinfocode,
       u.cardid,
       u.username,
       u.useraddress,
       mi.METERINFOID,
       mi.METERCODE,
       mi.METERBRANDID,
       mi.METERCALID,
       mi.METERTYPE,
       mi.METERUSE,
       mi.METERBASENUMBER,
       mi.METERCURRENTREADING,
       mi.METERADDRESS,
       mi.METERSTATE,
       ml.lastmonthnumber,
       ml.readnumber,
       ml.currenttraffic,
       ml.readdate,
       ml.datayear,
       ml.datamonth,
       u.remark,
       u.rosterorder,
       mc.metercal,
       s.siteid,
       s.sitecode,
       s.sitename,
       b.meterbrandname,
       ml.ismakebill as isaccount,--u.isaccount,

       case
         when (ml.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              ml.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)) or
              (ml.readdate > sysdate) then
          ml.lastmonthnumber
         else
          ml.readnumber
       end as lastnumber,
        case
         when (ml.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              ml.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)) or
              (ml.readdate > sysdate) then
          ml.readnumber
         else
          null
       end as currnum,
       case
         when (ml.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              ml.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)) or
              (ml.readdate > sysdate) then
          ml.currenttraffic
         else
          null
       end as currwaternum,
       case
         when ml.addflow is null then
          0
         else
          ml.addflow
       end as addflow,
       case
         when ml.Creadmeterstate =0 then '未抄'
         when ml.Creadmeterstate =1 then '已抄'
           else '未抄'
       end as Creadmeterstate,
       mf.METERFIXLOGID,
       ml.cRemark,case
         when (ml.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              ml.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)) or
              (ml.readdate > sysdate) then
          ml.lossaddflow
         else
          0
       end as lossaddflow
  FROM MM_M_METERINFO mi
  LEFT join AM_U_USERINFO u
    on u.meterinfoid = mi.meterinfoid
  left join (select ml.meterinfoid,
                    max(ml.meterdatacurrentmonthid) meterdatacurrentmonthid
               from mm_m_meterdatacurrentmonth ml
              group by ml.meterinfoid) t
    on t.meterinfoid = mi.meterinfoid
  left join mm_m_meterdatacurrentmonth ml
    on t.meterdatacurrentmonthid = ml.meterdatacurrentmonthid
  left join AM_R_ROSTER r
    on r.rosterid = u.rosterid
  left join sm_p_admin sm
    on sm.iadminid = r.meterreaderid
  left join SM_S_SITE s
    on u.siteid = s.siteid
  left join SM_P_LOCATIONAREA l
    on u.locatioareaid = l.locatioareaid
  left join BS_U_COMMUNITY c
    on u.communtyid = c.communtyid
  left join mm_m_meterbrand b
    on mi.meterbrandid = b.meterbrandid
  LEFT JOIN MM_M_METERCAL mc
    ON mi.metercalid = mc.metercalid
  left join bs_b_usewatertype bu
    on u.usewatertypeid = bu.usewatertypeid
  left join mm_m_meterfixlog mf
    ON mf.USERINFOID = u.userinfoid
   AND mf.FIXSTATE = 1


/

