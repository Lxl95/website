create trigger TB_XZLCDETAILFHTR
    before insert
    on TB_XZLCDETAILFH
    for each row
begin
    select tb_xzlcdetailfhsq.nextval into :new.keyid from dual;
    end;

/

