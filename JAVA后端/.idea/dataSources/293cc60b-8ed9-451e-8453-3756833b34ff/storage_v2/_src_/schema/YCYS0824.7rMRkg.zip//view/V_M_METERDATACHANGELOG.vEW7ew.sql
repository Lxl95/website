create view V_M_METERDATACHANGELOG as
select mdl."METERDATACHANGELOGID",mdl."METERINFOID",mdl."CHANGEDREADNUMBER",mdl."OLDREADNUMBER",
mdl."MODIFYTIME",mdl."OPERATORID",mdl."REMARK",mdl."MODIFYTYPE",mi.metercode,mi.meteraddress,ad.cadminname,ui.userinfocode,ui.username,ui.cardid
    from MM_M_METERDATACHANGELOG mdl left join am_u_userinfo ui on ui.meterinfoid=mdl.meterinfoid
    join mm_m_meterinfo mi on mdl.meterinfoid=mi.meterinfoid

                                     join sm_p_admin ad on mdl.operatorid=ad.iadminid


/

