create view V_R_ROSTER as
SELECT distinct AM_R_ROSTER.METERREADINGTYPE,
                AM_R_ROSTER.rosterid,
                AM_R_ROSTER.SITEID,
                AM_R_ROSTER.ROSTERCODE,
                ROSTERNAME,
                METERREADINGCYCLE,
                STARTREADINGDAY,
                STARTLATEFINEDAY,
                METERREADERID,
                ROSTERTYPE,
                ROSTERSTATE,
                AM_R_ROSTER.remark,
                IADMINID,
                IDEPTID,
                IROLEID,
                CADMINNAME,
                CADMINSEX,
                CADMINPASSWORD,
                CADMINTEL,
                CADMINEMAIL,
                IISLOCKED,
                DEXPIREDATE,
                IISALLOWCHANGEPWD,
                CLASTLOGINIP,
                DLASTLOGINTIME,
                DLASTLOGOUTTIME,
                ILOGINTIMES,
                CTITLEPIC,
                ISKINID,
                SM_S_SITE.sitename,
                res.total,
                res.summoney,
                METERREADERIDS,
                Am_r_Roster.Installuserid
  FROM AM_R_ROSTER
  left join SM_P_ADMIN
    on AM_R_ROSTER.meterreaderid = SM_P_ADMIN.iadminid
  left join SM_S_SITE
    on AM_R_ROSTER.siteid = SM_S_SITE.siteid
  left join (select r.rosterid,
                    count(0) as total,
                    sum(ACCOUNTMMONEY) as summoney
               from am_r_roster r
              right join am_u_userinfo ui
                 on r.rosterid = ui.rosterid
              group by r.rosterid) res
    on res.rosterid = AM_R_ROSTER.Rosterid


/

