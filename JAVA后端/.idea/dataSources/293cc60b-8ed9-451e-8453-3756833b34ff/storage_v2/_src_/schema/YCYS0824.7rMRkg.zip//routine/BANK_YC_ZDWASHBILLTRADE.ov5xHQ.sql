create procedure Bank_YC_ZDWashBillTrade(verdate              in VARCHAR2, --对账日期
                                                    userinfocode         in VARCHAR2,
                                                    OriginalRunWaterCode in VARCHAR2, --原流水号
                                                    Results              out VARCHAR2) AS
  ReturnInfoCode   VARCHAR2(3); --返回信息码
  PrestoteOut      NUMBER(11, 2); --预存销账
  PrestoteIn       NUMBER(11, 2); --预存转入
  Bills            VARCHAR2(200); --账单集合
 
  USERID           VARCHAR2(200);
  usercode         VARCHAR2(50) := userinfocode;

  maxpaylogid      NUMBER;
  minpaylogig      number;
  PayLogID         NUMBER;
  sPayLogID        NUMBER;
  vercount         NUMBER;
  typecount        number;
  sucesscount      number;
  sussrunwatercode VARCHAR2(200);
  vbbankccode VARCHAR2(200);
  vbtradeccode VARCHAR2(200);
  vbiadminid number;
  paidtypee number;
  shijiao number(20,2);
  cc number ;

  OweReusts        sys_refcursor;

begin
select count(0)
    into vercount
    FROM B_VERIFYBILL T
    
   WHERE T.PAYDDATE = verdate
     AND t.RESULT in (0)
     and t.useinfocode in (usercode)
     and t.bankcurrentnum in (OriginalRunWaterCode);
     -----------------银行扣款成功，营收失败，直接重新调用收费
     if(vercount>0) then
    select t.bankcurrentnum,t.bankccode,t.tradeccode,t.operaterid,t.paidmoney
         INTO sussrunwatercode,vbbankccode,vbtradeccode,vbiadminid,shijiao
        from  B_VERIFYBILL t
       where T.PAYDDATE = verdate AND t.RESULT in (0)
             and t.useinfocode=usercode and t.bankcurrentnum=OriginalRunWaterCode;
delete B_VERIFYBILL b where b.useinfocode=usercode and b.payddate=verdate and b.bankcurrentnum=OriginalRunWaterCode ;
commit;
     Bank_YC_VerBillUpdate(usercode,
                           vbtradeccode ,
                           vbbankccode,
                           shijiao ,
                           sussrunwatercode,
                           verdate ,vbiadminid,
                           Results );   
    
     
     else
  select count(0)
    into vercount
    FROM B_VERIFYBILL T
     JOIN B_PAYLOG bp
      on T.paylogid = bp.paylog
   WHERE T.PAYDDATE = verdate
     AND t.RESULT in (2)
     and t.useinfocode in (usercode)
     and t.bankcurrentnum in (OriginalRunWaterCode)
     AND bp.PAYREDSTATE = 0;
delete from  b_verbillpay;
commit;
  ---1查询对账失败的缴费记录的最大paylogid和最小id
    SELECT  bp.userinfoid,nvl(max(bp.paylog),0),nvl(min(bp.paylog),0)
          into USERID,maxpaylogid,minpaylogig
            FROM B_VERIFYBILL t
             JOIN B_PAYLOG bp
              on t.paylogid = bp.paylog
           WHERE T.PAYDDATE = verdate
             AND t.RESULT in (2)
             and t.useinfocode=usercode
             and t.bankcurrentnum = OriginalRunWaterCode
             AND bp.PAYREDSTATE = 0 group by bp.userinfoid;
  --2.将失败记录以后的成功的交易存储到临时表中，全部红冲后，在重新执行收费
 
--3.查询银行失败交易之后，缴费成功的记录 
 select nvl(sum(count(0)),0)
    into typecount
    from b_paylog p
   where p.payredstate = 0 and p.paidtype<>6
     and p.paylog > maxpaylogid
     and p.userinfoid = USERID
   group by p.paidtype;
   --失败之后有缴费成功
    select nvl(sum(count(0)),0)
    into sucesscount
    from b_paylog p
   where p.payredstate = 0 and p.paidtype=6
     and p.paylog > maxpaylogid
     and p.userinfoid = USERID
   group by p.paidtype;
   ----
    select nvl(sum(count(0)),0) into cc
    from b_paylog p
   where p.payredstate = 0
     and p.paylog > maxpaylogid
     and p.userinfoid = USERID and p.paidtype=6
   group by p.paidtype;
   if(cc>0) then 
   select p.paidtype
    into paidtypee
    from b_paylog p
   where p.payredstate = 0
     and p.paylog > maxpaylogid
     and p.userinfoid = USERID and p.paidtype=6
   group by p.paidtype;
   end if;
  if (typecount > 0) then  --银行交易失败后，又有其他缴费方式，自动对账不做处理
   
    Results := '000';
    return;
  else --先红冲最后一笔记录，在冲失败记录，再用成功的一笔流水号执行收费
    
    --****************************先执行红冲多交的一笔
    OPEN OweReusts FOR
      select P.BILLIDS,
             P.PRESTOREOUT,
             P.PRESTOREIN,
             b.spaylog,
             p.bankcurrentnum,p.paylog,t.bankccode,t.tradeccode,p.iadminid
        from  B_VERIFYBILL t
        JOIN B_PAYLOG p on t.paylogid = p.paylog
        left join bill b on b.paylog = p.paylog
       where p.payredstate = 0
         and p.bankcurrentnum=OriginalRunWaterCode and t.payddate=verdate
         and p.userinfoid = USERID order by p.paylog desc;
    LOOP
      FETCH OweReusts
        INTO Bills, PrestoteOut, PrestoteIn, sPayLogID, sussrunwatercode,PayLogID,vbbankccode,vbtradeccode,vbiadminid;
      EXIT WHEN OweReusts%NOTFOUND;
      IF (Bills IS NOT NULL) THEN
      
        --更新账单缴费状态
        UPDATE BILL b SET b.billstate = 2 WHERE b.billid in (Bills);
        --更新缴费记录红冲状态
        UPDATE B_PAYLOG pl
           SET pl.payredstate    = 1,
               pl.redtime        = sysdate-1,
               pl.payrediadminid = vbiadminid,
               pl.remark         = '银行冲账'
         WHERE pl.paylog = PayLogID;
         update s_paylog s set s.payredstate=1,
                s.redtime = sysdate-1,
                s.payrediadminid = vbiadminid,
                s.remark = '银行冲账'
                 where s.spaylog=sPayLogID;
        --更新账户余额
        UPDATE AM_U_USERINFO
           SET ACCOUNTMMONEY = ACCOUNTMMONEY + to_number(PrestoteOut) -
                               to_number(PrestoteIn)
         WHERE USERINFOID = USERID;
      
        ReturnInfoCode := '00';
      ELSE
        ReturnInfoCode := '03'; --无记录
      END IF;
      commit;             
    END LOOP;
  ---**********************************红冲完后重新缴费******************************
  delete B_VERIFYBILL b where b.useinfocode=usercode and b.payddate=verdate ;
  commit;
   
      select
             t.bankcurrentnum,t.bankccode,t.tradeccode,t.operaterid,sum(t.paidmoney)
                     INTO sussrunwatercode,vbbankccode,vbtradeccode,vbiadminid,shijiao

        from  B_VERIFYBILL t
       where t.payddate=verdate 
         and t.useinfocode = usercode and t.bankcurrentnum=OriginalRunWaterCode
   group by       t.bankcurrentnum,t.bankccode,t.tradeccode,t.operaterid;
delete B_VERIFYBILL b where b.useinfocode=usercode and b.payddate=verdate and b.bankcurrentnum=OriginalRunWaterCode ;
commit;
     Bank_YC_VerBillUpdate(usercode,
                           vbtradeccode ,
                           vbbankccode,
                           shijiao ,
                           sussrunwatercode,
                           verdate ,vbiadminid,
                           Results );
                  
 
  --***********************************红冲完后重新缴费结束******************************
end if;
end if;
  IF (ReturnInfoCode = '000') THEN
    Results := '00';
  ELSE
  
    Results := ReturnInfoCode;
  END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN
  
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
    ROLLBACK;
  
end Bank_YC_ZDWashBillTrade;


/

