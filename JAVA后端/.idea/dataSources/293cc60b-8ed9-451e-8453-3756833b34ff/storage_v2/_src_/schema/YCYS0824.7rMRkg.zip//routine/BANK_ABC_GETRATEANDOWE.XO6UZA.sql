create procedure Bank_ABC_GetRateAndOwe(UserCode in VARCHAR2,
                                                   BillDate in VARCHAR2,
                                                   Results  out VARCHAR2) AS
  ReturnInfoCode     VARCHAR2(2); --返回信息码
  USERINFOCODE       VARCHAR2(20) := UserCode;
  USERNAME           VARCHAR2(200);
  USERADDRESS        VARCHAR2(200);
  PAYWAY             VARCHAR2(3); --缴费方式 1：现金 2：代扣 3：托收 4：支票 5:预付
  BankCode           VARCHAR2(10) := 'NY        '; --银行代号 农业银行默认NY
  BANKACCOUNT        VARCHAR2(32); --银行账号
  BaseBillDate       VARCHAR2(8) := BillDate;
  OweCount           VARCHAR2(2); --欠费月份数
  TotalOwe           VARCHAR2(12); --欠费总额 减去预存 单位:分
  sumwate            NUMBER(20, 2);--总欠费包含违约金
    sumsf            NUMBER(20, 2);--总欠费
  ACCOUNTMMONEY      NUMBER(20, 2); --账户余额 单位:分
  ACCOUNTMMONEY1      VARCHAR2(20); --账户余额 单位:分
  TotalFellBackMoney VARCHAR2(12) := '000000000000'; --总违约金 单位:分
  Blank              VARCHAR2(1) := ' '; --空
  OweDate            VARCHAR2(8); --欠费月份
  CurrentFlow        VARCHAR2(12); --该月总水量
  sumCurrentFlow        VARCHAR2(12); --总水量
  WaterRate          VARCHAR2(12); --该月水费 单位:分
  FellBackMoney      VARCHAR2(12); --该月违约金 单位:分
  CurrentTotalRate   VARCHAR2(12); --当月总水费 单位:分
  FellBackStartDate  VARCHAR2(8) := '00000000'; --违约金起算日期
sumwyj   NUMBER(20, 2); --违约金 单位:分
  OweReusts              sys_refcursor;
  OweReustsString        VARCHAR2(6400); --12笔的欠费记录
  USERINFOID             VARCHAR2(30);
  ADVANCEPRINTOPERATERID NUMBER; --预打印人
  USERID                 NUMBER;


begin

  select
         replace(RPAD(decode(T.USERNAME,null,' ', T.USERNAME),64),' ',' '),
         replace(RPAD(decode(T.USERADDRESS,null,' ', T.USERADDRESS),64),' ',' '),
         decode(T.PAYWAY, null, ' ', T.PAYWAY),
         REPLACE(RPAD(decode(T.BANKACCOUNT, null, ' ', T.BANKACCOUNT), 32), ' ', ' '),
         T.ACCOUNTMMONEY,
         decode(T.ACCOUNTMMONEY*100, null, ' ', T.ACCOUNTMMONEY*100),
         T.USERINFOID

    INTO USERNAME,
         USERADDRESS,
         PAYWAY,
         BANKACCOUNT,
         ACCOUNTMMONEY,
         ACCOUNTMMONEY1,
         USERINFOID
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = UserCode
     AND ROWNUM = 1;

  IF (PAYWAY = '3') THEN
    ReturnInfoCode := '24'; --托收不能在银行缴费
  END IF;

  IF (USERNAME IS NOT NULL) THEN
    USERID := USERINFOID;
    IF (BillDate = '00000000') THEN
      --生成每月用水量 协议变长部分
      OPEN OweReusts FOR
        SELECT B.BILLYEAR || REPLACE(LPAD(B.BILLMONTH, 2), ' ', '0') || '01',
               REPLACE(RPAD(B.WATERATE * 100, 12), ' ', ' '),
               REPLACE(RPAD(B.CURRENTTRAFFIC, 12), ' ', ' '),
               REPLACE(RPAD(B.WATERATE * 100, 12), ' ', ' '),
               B.ADVANCEPRINTOPERATERID
          FROM BILL B
         WHERE B.USERINFOID = USERID
           AND B.BILLSTATE = 2
           AND B.ISRECTIFY = 0;

      LOOP
        FETCH OweReusts
          INTO OweDate,
               WaterRate,
               CurrentFlow,
               CurrentTotalRate,
               ADVANCEPRINTOPERATERID;
        EXIT WHEN OweReusts%NOTFOUND;
        IF (ADVANCEPRINTOPERATERID IS NOT null) THEN
          ReturnInfoCode := '11'; --预打印状态
        END IF;
      /*  OweReustsString := OweReustsString || OweDate || CurrentFlow ||
                           WaterRate || '000000000000' || CurrentTotalRate ||
                           FellBackStartDate;*/

      END LOOP;
    ELSE
      --生成每月用水量 协议变长部分
      OPEN OweReusts FOR
        SELECT B.BILLYEAR || REPLACE(LPAD(B.BILLMONTH, 2), ' ', '0') || '01',
               REPLACE(RPAD(B.WATERATE * 100, 12), ' ', ' '),
               REPLACE(RPAD(B.CURRENTTRAFFIC, 12), ' ', ' '),
               REPLACE(RPAD(B.WATERATE * 100, 12), ' ', ' '),
               B.ADVANCEPRINTOPERATERID
          FROM BILL B
         WHERE B.USERINFOID = USERID
           AND B.BILLSTATE = 2
           AND B.ISRECTIFY = 0
           AND B.BILLYEAR = to_number(substr(BillDate, 1, 4))
           AND B.BILLMONTH = to_number(substr(BillDate, 5, 2));

      LOOP
        FETCH OweReusts
          INTO OweDate,
               WaterRate,
               CurrentFlow,
               CurrentTotalRate,
               ADVANCEPRINTOPERATERID;
        EXIT WHEN OweReusts%NOTFOUND;
        IF (ADVANCEPRINTOPERATERID IS NOT null) THEN
          ReturnInfoCode := '11'; --预打印状态
        END IF;
       /* OweReustsString := OweReustsString || OweDate || CurrentFlow ||
                           WaterRate || '000000000000' || CurrentTotalRate ||
                           FellBackStartDate;*/

      END LOOP;
    END IF;

    IF (ACCOUNTMMONEY is null) THEN
      ACCOUNTMMONEY := 0; --账户余额为0
      end if;
   SELECT COUNT(0)
      INTO OweCount
      from BILL B
     WHERE B.USERINFOID = USERID
       AND B.BILLSTATE = 2
       AND B.ISRECTIFY = 0;

     if(OweCount>0) then
       SELECT COUNT(0),
  (SUM(B.WATERATE)+sum(b.latefee)-sum(b.REDUCTIONMONEY) - ACCOUNTMMONEY) * 100,SUM(B.WATERATE)+sum(b.latefee)-sum(b.REDUCTIONMONEY)
 , (sum(b.latefee) - sum(b.REDUCTIONMONEY))*100 sumlatef,
 SUM(B.WATERATE)*100,sum(b.currenttraffic)
      INTO OweCount, TotalOwe,sumwate,sumwyj,sumsf,sumCurrentFlow
      from BILL B
     WHERE B.USERINFOID = USERID
       AND B.BILLSTATE = 2
       AND B.ISRECTIFY = 0
     GROUP BY B.USERINFOID;
     ACCOUNTMMONEY:=ACCOUNTMMONEY-sumwate;
     if(ACCOUNTMMONEY<0) then
     ACCOUNTMMONEY:=0;
     end if;
     ACCOUNTMMONEY1:=ACCOUNTMMONEY*100;
       OweReustsString :=  '00000000' || REPLACE(RPAD(sumCurrentFlow, 12), ' ', ' ')  ||REPLACE(RPAD(sumsf, 12), ' ', ' ') ||REPLACE(RPAD(sumwyj, 12), ' ', ' ')  || REPLACE(RPAD(sumwate*100, 12), ' ', ' ')  || '00000000';
     end if;

    IF (OweCount = 0 OR TotalOwe <= 0) THEN
      ReturnInfoCode := '00'; --不欠费
      TotalOwe:=0;
      OweReustsString :=  '00000000' ||  '000000000000' ||
                            '000000000000' ||  '000000000000' ||  '000000000000' || '00000000';
    ELSE
      if(ReturnInfoCode ='11') then
         ReturnInfoCode := '11';
       else
         ReturnInfoCode := '00';
        end if;
    END IF;
  ELSE
    ReturnInfoCode := '08'; --不欠费
  END IF;
  IF (ReturnInfoCode = '00' or ReturnInfoCode = '11') THEN
    Results := ReturnInfoCode || REPLACE(RPAD(USERINFOCODE, 20), ' ', ' ') ||
               USERNAME || USERADDRESS ||
               REPLACE(RPAD(PAYWAY, 3), ' ', ' ') || BankCode ||
               BANKACCOUNT || BaseBillDate ||
               REPLACE(RPAD(OweCount, 2), ' ', ' ') ||
               REPLACE(RPAD(TotalOwe, 12), ' ', ' ') ||
               REPLACE(RPAD(ACCOUNTMMONEY1, 12), ' ', ' ') ||
               TotalFellBackMoney || Blank || OweReustsString;
  ELSE
    Results := ReturnInfoCode;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '03'; --没有查到数据
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '02'; --报错
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '02'; --报错
    Results        := ReturnInfoCode;

end Bank_ABC_GetRateAndOwe;


/

