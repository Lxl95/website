create trigger TRG_BS_B_USER_WATERTYPE_MAP
    before insert
    on BS_B_USER_WATERTYPE_MAP
    for each row
DECLARE
   integrity_error   EXCEPTION;
   errno             INTEGER;
   errmsg            CHAR (200);
BEGIN
   SELECT SEQ_BS_B_USER_WATERTYPE_MAP.NEXTVAL
     INTO :NEW.ID
     FROM DUAL;
--  Errors handling
EXCEPTION
   WHEN integrity_error
   THEN
      raise_application_error (errno, errmsg);
END;
/

