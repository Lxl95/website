create view V_P_ADMIN_NEW as
SELECT     SM_P_ADMIN.iAdminID,SM_P_ADMIN.iDeptID, SM_P_ADMIN.iRoleID ,cAdminName ,cAdminSex,SM_P_ADMIN.Worknumber,cAdminPassWord,cAdminTel ,cAdminEmail  , SM_P_ADMIN.iIsLocked , dExpireDate ,
         SM_P_ADMIN.iIsAllowChangePWD , cLastLoginIP ,dLastLoginTime ,dLastLogoutTime ,iLoginTimes ,cTitlePic  ,iSkinID,
         SM_P_DEPARTMENT.cDepName, SM_P_Role.cRoleName,SM_P_DEPARTMENT.LocatioAreaIDs,SM_P_ADMIN.siteids,SM_P_ADMIN.Usersid,SM_P_ADMIN.ISGROUPLEADER,BS_B_ADMINCLIEND.CLIENTID,SM_P_ADMIN.Memberids,ELEINVID,sm_p_admin.isprintinvoice

 FROM         SM_P_ADMIN INNER JOIN
                      SM_P_DEPARTMENT ON SM_P_ADMIN.iDeptID = SM_P_DEPARTMENT.iDeptID INNER JOIN
                      SM_P_Role ON SM_P_ADMIN.iRoleID = SM_P_Role.iRoleID
                      LEFT JOIN BS_B_ADMINCLIEND on SM_P_ADMIN.IADMINID=BS_B_ADMINCLIEND.IADMINID


/

