create view V_B_BILLSPECIFICRATE as
select bsc."BILLSPECIFICRATEID",bsc."SPECIFICPRICEITEMID",bsc."TOTALPRICES",bsc."BILLID",spi.price,spi.itemtype,spi.specificpriceitemname
    from B_BILLSPECIFICRATE bsc left join bs_b_specificpriceitem spi on bsc.SPECIFICPRICEITEMID =spi.specificpriceitemid


/

