create view V_M_METERAPPMONTH as
select case when m3.addflow is null then 0 else m3.addflow end as addflow, m3.isupload,m3.rosterid, m3.userinfoid, m3.meterinfoid,m3.datayear,m3.datamonth,m3.image,m3.wellid,m3.estimatereadmeterres,m3.readmeterdate,
m4.lastmonthnumber,m4.readnumber,m4.currenttraffic,m4.meterappmonthdataid,m3.meterreaderid,m3.cremark,m3.readmeterstate from MM_M_METERAPPMONTHDATA m3 inner join (
select m.meterappmonthdataid,m.userinfoid,m.lastmonthnumber,m.readnumber,m.readnumber-m.lastmonthnumber+decode(m.addflow,null,0, m.addflow) as currenttraffic from MM_M_METERAPPMONTHDATA m
  inner join (
   select mdd1.lastmonthnumber,mdd1.meterappmonthdataid from (select md.userinfoid, max(md.meterappmonthdataid) as meterappmonthdataid from MM_M_METERAPPMONTHDATA md
                               group by md.userinfoid order by meterappmonthdataid asc) mdd
           inner join  MM_M_METERAPPMONTHDATA mdd1 on mdd.meterappmonthdataid=mdd1.meterappmonthdataid
             )lm  on lm.meterappmonthdataid=m.meterappmonthdataid
  ) m4 on m3.meterappmonthdataid=m4.meterappmonthdataid
  left join am_r_roster r on r.rosterid=m3.rosterid


/

