create view V_SMS_QIANFEI as
select am.userinfoid,'['||am.userinfocode||']'||am.username userinfocode,am.accountmmoney-waterate waterate,am.contect,accountmmoney,am.username ,am.useraddress,am.siteid,am.rosterid
from (select sum(waterate+nvl(bb.latefee,0)) waterate ,bb.userinfoid from bill bb  where bb.billstate=2 group by bb.userinfoid ) b
left join am_u_userinfo am  on b.userinfoid=am.userinfoid where  am.accountmmoney-waterate<=0


/

