create view V_U_WELLSET as
SELECT    c.wellid,c.wellname,c.wellcode,c."LOCATIOAREAID",c."ROSTERID",c."SITEID",c."COMMUNTYADDRESS",c."PIPECODE",c."MODULECODE",c."COMMUNTYLONGITUDE",c."COMMUNTYLATITUDE",c."COMMUNTYGISINFO",c."TOPNUMBER",c."COMNUMBER",c."BUILDINGNUMBER",c."UNITNUMBER",c."ADMINTEL",c."ADMINNAME",c."ZBXQZHS",c."ECGSSBCJ",c."ECGSSBXH",c."PUMPADDRESS",l.locationareaname,s.sitename,r.rostername,t.userCount

 FROM         mm_w_meterwellrelation c  left JOIN SM_P_LOCATIONAREA l ON c.locatioareaid=l.locatioareaid
                               left JOIN SM_S_SITE s ON  c.siteid=s.siteid
                               left JOIN AM_R_ROSTER r on c.rosterid=r.rosterid
                               left join (select u.wellid,count(0) as userCount from mm_w_userwell u group by u.wellid) t on t.wellid = c.wellid


/

