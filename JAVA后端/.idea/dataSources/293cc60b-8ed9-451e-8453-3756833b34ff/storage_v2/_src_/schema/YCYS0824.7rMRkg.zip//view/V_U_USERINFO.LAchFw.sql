create view V_U_USERINFO as
SELECT userinfoid,
       AM_U_USERINFO.userinfocode,
       AM_U_USERINFO.Communtyid,
       AM_U_USERINFO.siteid,
       AM_R_ROSTER.rosterid,
       AM_R_ROSTER.rostercode,
       AM_R_ROSTER.rostername,
       rosterorder,
       ismultimeteruser,
       AM_U_USERINFO.metercode,
       useraddress,
       usertype,
       AM_U_USERINFO.username,
       identitytype,
       identityvalue,
       contect,
       contectperson,
       email,
       mm_m_meterinfo.METERWATERTYPEID,
       userstate,
       familycount,
       personcount,
       wellwater,
       secwatersupply,
       elcbill,
       mm_m_meterinfo.installtime,
       urgeway,
       STEPPRICEITEMID,
       LIMITUSEPRICEITEMID,
       readmeterstate,
       usercreatetime,
       useractivatime,
       usercancellationtime,
       projectcode,
       watersupplycontractcode,
       supplysigntime,
       stopsupplytime,
       buildunit,
       builder,
       checker,
       checkerid,
       accountmmoney,
       payway,
       bankaccount,
       bankname,
       AM_U_USERINFO.remark,
       AM_U_USERINFO.meterinfoid,
       MM_M_METERINFO.meteraddress,
       AM_U_USERINFO.Callphone,
       a.cadminname,
       cardid
  FROM AM_U_USERINFO
  join AM_R_ROSTER
    on AM_U_USERINFO.Rosterid = AM_R_ROSTER.Rosterid
  join MM_M_METERINFO
    on AM_U_USERINFO.meterinfoid = MM_M_METERINFO.meterinfoid
  join sm_p_admin a
    on AM_R_ROSTER.METERREADERID = a.iadminid
 where (AM_U_USERINFO.rosterid <> 0 or AM_U_USERINFO.rosterid <> '') --and (AM_U_USERINFO.siteid <> 0 or  AM_U_USERINFO.siteid <> '')
 order by AM_U_USERINFO.Rosterorder asc


/

