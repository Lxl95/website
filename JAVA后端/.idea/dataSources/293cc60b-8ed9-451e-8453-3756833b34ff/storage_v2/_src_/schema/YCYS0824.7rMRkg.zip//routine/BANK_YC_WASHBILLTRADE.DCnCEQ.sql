create procedure Bank_YC_WashBillTrade(BankCode             in VARCHAR2, --银行代号 区分各大银行
                                                  PayID                in VARCHAR2, --操作员
                                                  PayDate              in VARCHAR2, --收费日期 必须当天
                                                  usercode             in varchar2, --用户编号
                                                  redmoney             in number, --冲账金额
                                                  OriginalRunWaterCode in VARCHAR2, --原流水号
                                                  NetWorkCode          in VARCHAR2, --网点代号 储蓄所或分理处的代号
                                                  Results              out VARCHAR2,
                                                  outdata              out VARCHAR2) AS
  ReturnInfoCode VARCHAR2(3); --返回信息码
  PrestoteOut    NUMBER(11, 2); --预存销账
  PrestoteIn     NUMBER(11, 2); --预存转入
  Bills          VARCHAR2(200); --账单集合
  USERNAME       varchar(80);
  USERADDRESS    varchar(80);
  USERID         VARCHAR2(30);
  PayLogID       NUMBER;
  Nowdate        VARCHAR2(8);
  OweReusts      sys_refcursor;

begin

  select to_char(sysdate, 'yyyymmdd') into Nowdate from dual;

  select am.username, am.useraddress

    INTO USERNAME, USERADDRESS

    FROM am_u_userinfo am
   WHERE am.userinfocode = trim(usercode);

  IF (Nowdate = PayDate) THEN
    --查询对账单中缴费记录ID
    OPEN OweReusts FOR
      SELECT bp.paylog

        FROM B_VERIFYBILL b
        LEFT JOIN B_PAYLOG bp
          on b.paylogid = bp.paylog
       WHERE b.bankccode = trim(BankCode)
         AND bp.IADMINID = trim(PayID)
         AND to_char(bp.ddatetime, 'yyyyMMdd') = trim(PayDate)
         AND trim(bp.BANKCURRENTNUM) = trim(OriginalRunWaterCode)
         AND bp.PAYREDSTATE = 0;

    LOOP
      FETCH OweReusts
        INTO PayLogID;

      EXIT WHEN OweReusts%NOTFOUND;

      IF (PayLogID is not null) THEN

        select P.BILLIDS, P.USERINFOID, P.PRESTOREOUT, P.PRESTOREIN

          INTO Bills, USERID, PrestoteOut, PrestoteIn

          FROM B_PAYLOG P
         WHERE P.Paylog = PayLogID
           AND P.PAYREDSTATE = 0
           AND ROWNUM = 1;

        IF (Bills IS NOT NULL) THEN

          --更新账单缴费状态
          UPDATE BILL b SET b.billstate = 2 WHERE b.billid in (Bills);
          --更新缴费记录红冲状态
          UPDATE B_PAYLOG pl
             SET pl.payredstate    = 1,
                 pl.redtime        = sysdate,
                 pl.payrediadminid = PayID
           WHERE pl.paylog = PayLogID;
          --更新账户余额
          UPDATE AM_U_USERINFO
             SET ACCOUNTMMONEY = ACCOUNTMMONEY + to_number(PrestoteOut) -
                                 to_number(PrestoteIn)
           WHERE USERINFOID = USERID;

          ReturnInfoCode := '000';
        ELSE
          ReturnInfoCode := '021'; --无记录
        END IF;

      ELSE
        ReturnInfoCode := '021'; --无记录
      END IF;

      commit;
    END LOOP;
    ReturnInfoCode := nvl(ReturnInfoCode, '021');
  ELSE
    ReturnInfoCode := '012'; --不能隔日对账
  END IF;
  IF (ReturnInfoCode = '000') THEN
    Results := ReturnInfoCode;
    outdata := '000229' || '03' || REPLACE(RPAD(BankCode, 2), ' ', ' ') ||
               ReturnInfoCode || REPLACE(RPAD(usercode, 10), ' ', ' ') ||
               REPLACE(RPAD(OriginalRunWaterCode, 20), ' ', ' ') ||
               REPLACE(RPAD(nvl(USERNAME,'0'), 80), ' ', ' ') ||
               REPLACE(RPAD(nvl(USERADDRESS,'0'), 80), ' ', ' ') ||
               REPLACE(lPAD(redmoney, 8,0), ' ', ' ') ||
               REPLACE(RPAD(PayDate, 8), ' ', ' ') ||
               REPLACE(RPAD(PayID, 8), ' ', ' ') || '@@';
  ELSE

    Results := ReturnInfoCode;
  END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
    ROLLBACK;

end Bank_YC_WashBillTrade;


/

