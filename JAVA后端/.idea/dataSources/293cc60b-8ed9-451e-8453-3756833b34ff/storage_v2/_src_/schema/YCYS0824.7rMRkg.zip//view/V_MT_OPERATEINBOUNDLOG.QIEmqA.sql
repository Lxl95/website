create view V_MT_OPERATEINBOUNDLOG as
SELECT  ib."OPERATELOGID",ib."STUFFMODEID",ib."OPERATETIME",ib."OPERATER",ib."OPERATECODEID",ib."STUFFCOST",ib."ACCOUNTER",ib."RECEIPTOR",
ib."INBOUNDCOUNT",s.stuffmodename,o.operatecodename,s.stuffmodecode,ib.inbounddate,st.stufftypename,s.currentcount,ib.saleprice,so.storageid,so.storagename,ib.onselfprice
  from mt_operateinboundlog ib left join MT_STUFFMODE s on s.stuffmodeid=ib.stuffmodeid
                               left join mt_stufftype st on st.stufftypeid=s.stufftypeid
                               left join MT_OPERATECODE o on o.operatecodeid=st.operatecodeid
                               left join mt_storage so on so.storageid=ib.storageid


/

