create trigger WX_SAFETY_PERMISSION_TRIGGER
    before insert
    on WX_SAFETY_PERMISSION
    for each row
begin
  select wx_safety_permission_sq.nextval into :NEW.id from dual;
end;

/

