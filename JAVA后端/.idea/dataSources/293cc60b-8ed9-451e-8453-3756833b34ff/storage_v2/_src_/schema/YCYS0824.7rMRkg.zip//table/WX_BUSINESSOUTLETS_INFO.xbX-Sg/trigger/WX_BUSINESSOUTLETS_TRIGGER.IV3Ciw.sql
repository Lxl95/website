create trigger WX_BUSINESSOUTLETS_TRIGGER
    before insert
    on WX_BUSINESSOUTLETS_INFO
    for each row
begin
  select wx_businessoutlets_info_sq.nextval into :NEW.id from dual;
end;

/

