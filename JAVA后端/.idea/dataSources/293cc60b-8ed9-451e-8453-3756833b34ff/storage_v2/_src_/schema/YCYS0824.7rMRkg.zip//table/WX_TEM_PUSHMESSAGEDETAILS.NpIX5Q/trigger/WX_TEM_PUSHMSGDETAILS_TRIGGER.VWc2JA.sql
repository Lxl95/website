create trigger WX_TEM_PUSHMSGDETAILS_TRIGGER
    before insert
    on WX_TEM_PUSHMESSAGEDETAILS
    for each row
begin
  select wx_tem_pushMsgDetails_sq.nextval into :NEW.id from dual;
end;

/

