create view V_P_ROLE as
SELECT     iRoleID, cRoleName, iIsAllowChangePWD, iIsLocked, cRoleExplain
FROM         SM_P_ROLE


/

