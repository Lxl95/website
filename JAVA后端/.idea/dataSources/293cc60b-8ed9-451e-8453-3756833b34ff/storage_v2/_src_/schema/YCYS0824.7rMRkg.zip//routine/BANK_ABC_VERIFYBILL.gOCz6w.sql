create procedure Bank_ABC_VerifyBill(
                                                   VerifyBillDate    in VARCHAR2, --对账日期
                                                   BankCode  in VARCHAR2, --银行代号
                                                   NetWorkCode   in VARCHAR2, --网点代号 储蓄所或分理处的代号
                                                   InRecordCount   in VARCHAR2, --记录数
                                                   Results       out VARCHAR2) AS
  ReturnInfoCode  VARCHAR2(2); --返回信息码

  OweReusts              sys_refcursor;
  RecordCount         VARCHAR2(8); --记录数
  PayMoney      VARCHAR2(12); --实收总金额


begin

  select REPLACE(RPAD( COUNT(0), 8), ' ', ' '),   REPLACE(RPAD(SUM(T.PAIDMONEY)*100, 12), ' ', ' ')

    INTO RecordCount,
         PayMoney

    FROM B_VERIFYBILL T LEFT JOIN B_PAYLOG bp on T.paylogid=bp.paylog
   WHERE T.Bankccode = BankCode
  --   AND T.BANKSITECODE=NetWorkCode
     AND T.PAYDDATE=VerifyBillDate
     AND bp.PAYREDSTATE=0;
    -- AND ROWNUM = 1;

   IF (RecordCount = 0 ) THEN
      ReturnInfoCode := '03'; --无记录
      ELSE
         ReturnInfoCode := '00';
    END IF;
    IF( ReturnInfoCode = '00') THEN
    Results        := ReturnInfoCode ||RecordCount ||PayMoney ;
    ELSE
      Results        := ReturnInfoCode;
      END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '03'; --没有查到数据
      Results       := ReturnInfoCode  ;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '02'; --报错
     Results        := ReturnInfoCode  ;
  WHEN OTHERS THEN
    ReturnInfoCode := '02'; --报错
      Results        := ReturnInfoCode ;

end Bank_ABC_VerifyBill;


/

