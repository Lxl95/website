create view V_U_USERMETERINFON as
SELECT u.usertype,
       mi.sealnumber,
       r.meterreaderid,
       sm.cadminname,
       u.welladd,
       u.contect,
       u.meterwalladdress,
       l.locatioareaid,
       l.locationareacode,
       l.locationareaname,
       c.communtyid,
       c.communtycode,
       c.communtyname,
       r.rostercode,
       r.rosterid,
       r.rostername,
       u.userinfoid,
       u.userstate,
       u.userinfocode,
       u.username,
       u.useraddress,
       mi."METERINFOID",
       mi."METERCODE",
       mi."METERBRANDID",
       mi."METERCALID",
       mi."METERTYPE",
       mi."METERUSE",
       mi."METERBASENUMBER",
       mi."METERCURRENTREADING",
       mi."LASTNUMBER",
       mi."METERADDRESS",
       mi."METERSTATE",
       ml.lastmonthnumber,
       ml.readnumber,
       ml.currenttraffic,
       ml.readdate,
       ml.datayear,
       ml.datamonth,
       ml.lsumwnum,
      nvl( mt.currenttraffic,0) lastcurrent,
       u.remark,
       u.rosterorder,
       mc.metercal,
       s.siteid,
       s.sitecode,
       s.sitename,
       b.meterbrandname,
       u.isaccount,
       ml.meterdatacurrentmonthid,
       u.accountmmoney,
       case
         when ml.addflow is null then
          0
         else
          ml.addflow
       end as addflow,
       u.mixwatertypeid,
       u.mixwaterrate,
       u.mixwaterflow,
       u.usewatertypeid,
       u.cardid,
       bu.usewatertypename,
       new1.needtyperate,
       new1.needflow,
       new1.mixwatertype,
       new1.nusewatertypename
  FROM MM_M_METERINFO mi
  LEFT join AM_U_USERINFO u
    on u.userinfocode = mi.userinfocode
  left join

(select userinfoid,needtyperate,needflow,mixwatertype,useorder,userwatertype,usewatertypename as nusewatertypename from
(SELECT  T.userinfoid,listagg(T.typerate,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as needtyperate
,listagg(T.mixwaterflow,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as needflow,
listagg(T.mixwatertype,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as mixwatertype,
listagg(T.useorder,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as useorder,
listagg(T.userwatertype,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as userwatertype,
listagg(T.usewatertypename,',')  within group (order by T.userinfoid) over(partition by T.userinfoid) as usewatertypename

 FROM (select b.*,a.usewatertypename from bs_b_user_watertype_map b left join
  bs_b_usewatertype a on b.userwatertype= a.usewatertypeid  order by b.userinfoid,b.useorder) T
  )
  fa group by fa.userinfoid,fa.needtyperate,fa.needflow,fa.mixwatertype,fa.useorder,fa.userwatertype,fa.usewatertypename) new1 on u.userinfoid = new1.userinfoid
 left join (select ml.meterinfoid,
                    max(ml.meterdatacurrentmonthid) meterdatacurrentmonthid
               from mm_m_meterdatacurrentmonth ml
              group by ml.meterinfoid) t
    on mi.meterinfoid = t.meterinfoid
  left join mm_m_meterdatacurrentmonth ml    on t.meterdatacurrentmonthid = ml.meterdatacurrentmonthid
  left join (select * from (select row_number() over(partition by meterinfoid order by readdate desc) rn,mtt.meterinfoid,mtt.currenttraffic from mm_m_meterdatacurrentmonth mtt)  where rn=2) mt on mt.meterinfoid=mi.meterinfoid
  left join AM_R_ROSTER r   on r.rosterid = u.rosterid
  left join sm_p_admin sm   on sm.iadminid = r.meterreaderid
  left join SM_S_SITE s    on u.siteid = s.siteid
  left join SM_P_LOCATIONAREA l   on u.locatioareaid = l.locatioareaid
  left join BS_U_COMMUNITY c   on u.communtyid = c.communtyid
  left join mm_m_meterbrand b   on mi.meterbrandid = b.meterbrandid
  LEFT JOIN MM_M_METERCAL mc    ON mi.metercalid = mc.metercalid
  left join bs_b_usewatertype bu   on u.usewatertypeid = bu.usewatertypeid


/

