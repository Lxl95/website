create package BODY pkg_ys
AS
procedure Bank_YC_PayInfoUpdate(UserCode     in VARCHAR2, --用户代码
                                                  TradeCode    in VARCHAR2, --交易码
                                                  BankCode     in VARCHAR2, --银行识别码
                                                  PayMoney     in VARCHAR2, --缴费金额
                                                  RunWaterCode in VARCHAR2, --委托方流水号
                                                  PayDate      in VARCHAR2, -- 记账日期 收费日期yyyymmdd
                                                  PayID        in VARCHAR2, --操作员

                                                  Results out VARCHAR2,
                                                  --retoutdatya  out VARCHAR2,
                                                  outdata out ref_cursor) AS
  SQL_ERM          VARCHAR2(4000);
  --returncode          NVARCHAR2(4000);
  ReturnInfoLength VARCHAR2(6); --报文长度 不定长
  -- TradeCode          VARCHAR2(2) :='02'; --交易码
  --BankCode           VARCHAR2(2) := 'NY'; --银行识别号码  银行代号 农业银行默认NY
  ReturnInfoCode VARCHAR2(3); --响应码
  --RunWaterCode       VARCHAR2(20) :=RunWaterCode;--委托方流水号
  OweCount      VARCHAR2(2); --凭证张数，缴费笔数 欠费月份数
  PZCount       VARCHAR2(2); --凭证张数，发票张数，一张发票可打印四条账单
  USERINFOCODE1 VARCHAR2(10) := UserCode; --用户代码
  USERNAME1     VARCHAR2(80); --用户名称
  --以下是欠费集合重复
  UseWaterTypename_n VARCHAR2(30); --用水类型
  readnumber_n       VARCHAR2(10); --本次读数
  currenttraffic_n   VARCHAR2(10); --用水量
  price_n            VARCHAR2(10); --水费单价
  waterate_n         VARCHAR2(10); --水费金额
  wsf_n              VARCHAR2(10); --污水费金额
  sumwate_n          VARCHAR2(10); --金额

  remarks  VARCHAR2(100); --备注
  DXMoney  VARCHAR2(100) := PayMoney / 100; --大写金额
--  DXMoney1 VARCHAR2(100) := PayMoney / 100; --大写金额
  --XXMoney  VARCHAR2(13) := PayMoney / 100; --小写金额
  DWname   VARCHAR2(40); --单位名称
  nsrcode  VARCHAR2(30); --纳税人识别号

  BasePayMoney    VARCHAR2(12) := PayMoney; --缴费金额 银行原数据返回,不作为发票实收金额
  --TotalOwe        VARCHAR2(12); --欠费总额 单位:分
  FellBackMoney   VARCHAR2(12); --总违约金  去除违约金减免
  dyFellBackMoney VARCHAR2(12); --当月违约金 去除违约金减免

  ACCOUNTMMONEY1   NUMBER(20, 2); --账户余额 单位:分
  Balance          NUMBER(11, 2) := 0; --本次余额
  ThBalance        NUMBER(11, 2) := 0; --本次余额
  ShiJiao          FLOAT := 0;
  spayShiJiao          FLOAT := 0;
  CuurBalance      NUMBER(11, 2) := 0; --计算当前总可用金额(缴费现金+账户余额)
  CuurBalance_YuE  NUMBER(11, 2); --当前预存金额
  LastCountBalance NUMBER(11, 2);

  PrestoteOut   NUMBER(11, 2) := 0; --预存转出
  PrestoteIn    NUMBER(11, 2) := 0; --预存转入
  shouldPaySum  NUMBER(11, 2) := 0; --应收累加
 -- actPaid       NUMBER(11, 2) := 0; --实收
  laBlance      NUMBER(11, 2) := 0; --上次余额
 -- ShiShou       NUMBER(11, 2) := 0; --实收
  i             NUMBER := 0;
  --ii            NUMBER := 1;
  jj            NUMBER := 1;
  rownb         NUMBER;
  j             number; --每次账单rownumber取余后是否等0 或者判断出最后一次循环
  IsDanBi       NUMBER; --是否是单条账单
  Currwaterrate NUMBER(11, 2); --当月水费
  actPAIDMONEY  NUMBER(11, 2); --实收
  AllCurrwaterrate NUMBER(11, 2) := 0; --总应收水费
  AllPrestoteOut   NUMBER(11, 2) := 0; --总预存转出
  AllPrestoteIn    NUMBER(11, 2) := 0; --总预存转入

  /* PrestoteOut   NUMBER(11,2);--预存销账
  PrestoteIn     NUMBER(11,2);--预存准入    */
  --InvoiceForm    VARCHAR2(1) := ' '; --空 发票格式
  --CurrentFlow    VARCHAR2(12); --该月总水量
  --WaterRate      NUMBER(12, 2); --该月总水费 单位:分
  SUMWaterRate   VARCHAR2(12); --总欠费
  SumCurrentFlow VARCHAR2(12); --总水量

  OweReusts              sys_refcursor;
  OweReustsBills         VARCHAR2(200); --账单集合
  --OweReustsTotalOwe      NUMBER := 0; --欠费总金额
  OweReustsString        clob;--NVARCHAR2(4000); --12笔的欠费记录
  USERINFOIDs            NUMBER;
  --ADVANCEPRINTOPERATERID NUMBER; --预打印人
  BBILLID                NUMBER; --账单ID
  USERID                 NUMBER;
  --MONEY                  NUMERIC(10);
  paycash                NUMERIC(12, 2);
  maxpaylogid            NUMBER;
  maxspaylogid           NUMBER;
  maxbillid               NUMBER;
  maxVerifyBILLID        NUMBER;
  meterid             NUMBER;
  metcode              VARCHAR2(200); --水表编号
  num                    NUMBER;
  verpaidmoney  NUMERIC(12, 2);
  -- teSTID NUMBER;
  --billmonth              VARCHAR2(2);
  billreaddate VARCHAR2(8);
 retoutdata  clob;
  fpmoney   NUMERIC(12, 2); --发票之前的总金额
 -- syfpmoney NUMERIC(12, 2); --最后一张发票剩余显示大写金额
  lastnum   NUMBER := 0; --最后一张凭证账单数
  EndCode   VARCHAR2(2) := '@@'; --结束符号
begin

  select

   T.username,
   nvl(T.ACCOUNTMMONEY, 0) 　 ACCOUNTMMONEY,
   T.USERINFOID,
   replace(RPAD(decode(T.remark, null, ' ', T.remark), 100), ' ', ' '),
   replace(RPAD(decode(T.username, null, ' ', T.username), 40), ' ', ' '), --单位名称
   replace(RPAD(decode(T.vat, null, ' ', T.vat), 30), ' ', ' ') --纳税人识别号
  , t.meterinfoid,t.metercode
    INTO USERNAME1,
         ACCOUNTMMONEY1,
         USERINFOIDs,
         remarks, --备注
         DWname, --单位名称
         nsrcode --纳税人识别号
         ,meterid--水表id
         ,metcode
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = UserCode
     AND ROWNUM = 1;

  BEGIN

   -- MONEY := CAST(BasePayMoney AS NUMBER);
    IF (to_number(BasePayMoney) <= 0) THEN
      ReturnInfoCode := '009'; --金额错误 :小于等于0
      Results        := ReturnInfoCode;
      RETURN;
    ELSE
      dbms_output.put_line(BasePayMoney || '是[0-9]的数字序列');
    END IF;
  EXCEPTION
    WHEN value_error THEN
      --字符串转实数错误
      dbms_output.put_line(BasePayMoney || '不是[0-9]的数字序列');
      ReturnInfoCode := '009'; --金额错误 :不是数字
      Results        := ReturnInfoCode;
      RETURN;
  END;
 delete bill_jsbillid;
 commit;
  --验证是否有欠费
  SELECT COUNT(0) into num
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2 and b.waterate>0 and b.readdate is not null
             AND B.ISRECTIFY = 0;
    if(num >0) then
  --查询欠费笔数
  select nvl(t.num,0), nvl(t.sumwa,0), nvl(t.sumcu,0), nvl(t.sumwyj, 0)
    INTO OweCount, SUMWaterRate, SumCurrentFlow, FellBackMoney
    from (SELECT COUNT(0) as num,
                 SUM(B.WATERATE) + sum(b.latefee) - sum(b.REDUCTIONMONEY) as sumwa,
                 SUM(B.CURRENTTRAFFIC) as sumcu,
                 sum(b.latefee) - sum(b.REDUCTIONMONEY) sumwyj
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2 and  b.waterate>0 and b.readdate is not null
             AND B.ISRECTIFY = 0
           GROUP BY B.USERINFOID) t
   where rownum = 1;
   end if;
  
  --欠费笔数,是否是单条账单
  IsDanBi := OweCount;
  --获取实收金额
  paycash := to_number(PayMoney) / 100;
  --计算当前总可用金额(缴费现金+账户余额)
  CuurBalance := ACCOUNTMMONEY1 + paycash;
  -- 当前预存金额
  CuurBalance_YuE  := ACCOUNTMMONEY1;
  LastCountBalance := ACCOUNTMMONEY1;
  ShiJiao          := paycash - FellBackMoney;
  if(ShiJiao<0) then
    ShiJiao :=0;
    end if;
  spayShiJiao :=ShiJiao;
  --获取本次余额
  Balance := to_number(PayMoney) / 100 + ACCOUNTMMONEY1 -
             to_number(SUMWaterRate);
  if (Balance >= 0 ) and (num>0) then

    --**********************************************************循环结束
    IF (USERNAME1 IS NOT NULL) THEN
      USERID  := USERINFOIDs;
      fpmoney := 0;
      --****************************************************add 2018-11-30 凭证张数就是发票的张数，一张发票可以打印四条账单
      select ceil(OweCount / 4) into PZCount from dual;
      --取账单取余剩余最后一张发票上账单条数
      select mod(OweCount, 4) into lastnum from dual;
      --******************************************************获取循环洗漱和凭证张数结束***************************
      ---****************************************************①大循环凭证张数也就是发票张数
      OPEN OweReusts FOR
        SELECT row_number() over(partition by b.userinfoid order by b.billid asc) rn,
               nvl(uw.usewatertypename,' ') usewatertypename, --用水性质
              nvl( b.readnumber,0) readnumber, --本次读数
                nvl(b.currenttraffic,0) currenttraffic, --用水量
                nvl(bw1.price,0)price , --水费单价
                nvl((B.WATERATE + b.latefee - b.reductionmoney - nvl(bb1.wsf, 0)),0) wate, --水费金额
               (nvl(bb1.wsf, 0)) , --污水费
              nvl( (B.WATERATE + b.latefee - b.reductionmoney),0) sumwate, --金额
               nvl(b.waterate,0) waterate,
               b.billid,
               nvl(b.latefee - b.reductionmoney, 0) as yslatefine --应收滞纳金 已减去滞纳金减免

          FROM BILL B
          LEFT JOIN bs_b_usewatertype uw
            on uw.usewatertypeid = b.userwatertype
          left join (select bb.billid, nvl(sum(bb.totalprices), 0) as wsf
                       from b_billspecificrate bb
                       left join bs_b_specificpriceitem bs
                         on bs.specificpriceitemid = bb.specificpriceitemid
                      where bs.itemtype = 2
                      group by bb.billid) bb1
            on bb1.billid = b.billid
          left join (select (select sum(price)
                               from bs_b_specificpriceitem bs
                              where ',' || (bw.specificpriceitemids) || ',' like
                                    '%,' || to_char(bs.specificpriceitemid) || ',%') as price,
                            bw.usewatertypeid
                       from bs_b_usewatertype bw) bw1
            on bw1.usewatertypeid = b.userwatertype
         WHERE B.USERINFOID = USERID
           AND B.BILLSTATE = 2 and b.waterate>0 and b.readdate is not null
           AND B.ISRECTIFY = 0;
      LOOP
        FETCH OweReusts
          INTO rownb,
               UseWaterTypename_n,
               readnumber_n,
               currenttraffic_n,
               price_n,
               waterate_n,
               wsf_n,
               sumwate_n,
               Currwaterrate,
               BBILLID,
               dyFellBackMoney;
        EXIT WHEN OweReusts%NOTFOUND;
        --*******************************************②判断是否跳出下一次发票打印
        select mod(rownb, 4) into j from dual;
        if (j = 1) then
          OweReustsString := OweReustsString ||
                             REPLACE(RPAD(USERINFOCODE1, 10), ' ', ' ') ||
                             REPLACE(RPAD(USERNAME1, 80), ' ', ' ');
        end if;

        --ii :=ii+1;
        --生成每月用水量 协议变长部分
        fpmoney := fpmoney + sumwate_n;
        DXMoney := moneychinese(fpmoney);
        AllCurrwaterrate := AllCurrwaterrate + Currwaterrate;
        OweReustsString := OweReustsString ||
                           REPLACE(RPAD(UseWaterTypename_n, 30), ' ', ' ') ||
                           REPLACE(RPAD(readnumber_n, 10), ' ', ' ') ||
                           REPLACE(RPAD(currenttraffic_n, 10), ' ', ' ') ||
                           REPLACE(RPAD(price_n, 10), ' ', ' ') ||
                           REPLACE(RPAD(waterate_n, 10), ' ', ' ') ||
                           REPLACE(RPAD(wsf_n, 10), ' ', ' ') ||
                           REPLACE(RPAD(sumwate_n, 10), ' ', ' ');
        -------
        if (j = 0) then
          OweReustsString := OweReustsString ||
                             REPLACE(RPAD(remarks, 100), ' ', ' ') ||
                             REPLACE(RPAD(DXMoney, 100), ' ', ' ') ||
                             REPLACE(RPAD(fpmoney, 13), ' ', ' ') ||
                             REPLACE(RPAD(DWname, 40), ' ', ' ') ||
                             REPLACE(RPAD(nsrcode, 30), ' ', ' ');
          fpmoney         := 0;
        end if;
       -- dbms_output.put_line(OweReustsString);
        ----**********************************************①结束大循环循环发票张数
        --------------------------将billid插入到临时表中
        insert into bill_jsbillid(userinfoid, billid) values(USERID,BBILLID);
        --------------------------
        --循环插入数据
        i := i + 1;

        shouldPaySum := shouldPaySum + Currwaterrate+dyFellBackMoney; --累加应收
        IF (ShiJiao >= Currwaterrate) THEN
          PrestoteOut := 0; --预存转出
          PrestoteIn  := 0; --预存转入
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;
          IF (IsDanBi = 1) THEN
            dbms_output.put_line(BasePayMoney || '单笔操作无');
          ELSE
            ShiJiao := ShiJiao - Currwaterrate;
          END IF;
          if (IsDanBi = 1) then
            actPAIDMONEY := ShiJiao;
          else
            --如果不是最后一条
            if (i != OweCount) then
              actPAIDMONEY := Currwaterrate;
              --不是单笔的最后一条
            else
              actPAIDMONEY := ShiJiao + Currwaterrate;
            end if;

          end if;
          --本次余额处理
          ThBalance := CuurBalance_YuE;
          --上次余额处理
          laBlance := CuurBalance_YuE;
        ELSE
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;

          --上次余额处理
          laBlance := CuurBalance_YuE;
          --本次余额处理
          if(paycash < dyFellBackMoney) then
            CuurBalance_YuE := CuurBalance_YuE - (Currwaterrate - ShiJiao)-(dyFellBackMoney-paycash);
          else
            CuurBalance_YuE := CuurBalance_YuE - (Currwaterrate - ShiJiao);
          end if;
       
          ThBalance       := CuurBalance_YuE;
          actPAIDMONEY    := ShiJiao;
          --预存转出
          PrestoteOut := (Currwaterrate - ShiJiao);
          --没有转入操作 转入为0
          PrestoteIn := 0;
          ShiJiao    := 0;

        END IF;
        --最后一条----余额处理
        if (i = OweCount) then
          ThBalance := CuurBalance;
          --预存款转入
          if (CuurBalance >= LastCountBalance) then
            PrestoteIn := CuurBalance - LastCountBalance;
          else
            PrestoteIn := 0;
          end if;
        end if;
        --插入账单信息 B_PAYLOG
        --查询最大ID
        select b_paylogseq.nextval
          into maxpaylogid
          from dual;

        OweReustsBills := SUBSTR(OweReustsBills,
                                 1,
                                 INSTR(OweReustsBills, ',', -1) - 1);
       UPDATE AM_U_USERINFO u
         SET u.accountmmoney = ThBalance
       WHERE u.userinfoid = USERID;
        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine)
        VALUES
          (maxpaylogid,
           Currwaterrate,
           actPAIDMONEY,
           6,
           0,
           BBILLID,
           PrestoteIn,
           PrestoteOut,
           USERID,
           sysdate,
           laBlance,
           ThBalance,
           currenttraffic_n,
           RunWaterCode,
           PayID,
           6,
           RunWaterCode,
           PayID,
           dyFellBackMoney);

            AllPrestoteIn := AllPrestoteIn + PrestoteIn;
            AllPrestoteOut := AllPrestoteOut + PrestoteOut;
        --更新账单缴费状态
        UPDATE BILL b
           SET b.billstate = 1,
               b.paylog    = maxpaylogid
         WHERE b.billid = BBILLID;

        --添加对账信息
        --查询最大ID
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;
if(paycash < dyFellBackMoney) then
verpaidmoney := paycash;
else
  verpaidmoney :=actPAIDMONEY + nvl(dyFellBackMoney, 0);
  end if;
        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           verpaidmoney);
 
        commit;
      END LOOP;
      ------------------------------取余后,补剩余补账单数据
      if (lastnum != 0) then
        while jj <= 4 - lastnum loop
          OweReustsString := OweReustsString ||
                             REPLACE(RPAD(' ', 30), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ') ||
                             REPLACE(RPAD(' ', 10), ' ', ' ');
          if (jj = 4 - lastnum) then
            --最后发票下面备注和金额
            DXMoney         := moneychinese(fpmoney+PrestoteIn);
            OweReustsString := OweReustsString ||
                               REPLACE(RPAD(remarks, 100), ' ', ' ') ||
                               REPLACE(RPAD(DXMoney, 100), ' ', ' ') ||
                               REPLACE(RPAD(fpmoney+PrestoteIn, 13), ' ', ' ') ||
                               REPLACE(RPAD(DWname, 40), ' ', ' ') ||
                               REPLACE(RPAD(nsrcode, 30), ' ', ' ');

          end if;
          jj:= jj + 1;
        end loop;
      end if;
      dbms_output.put_line(OweReustsString);
      -------------------------------取余后结束
      --获取S_PAYLOG编号
  select s_paylogseq.nextval
    into maxspaylogid
    from dual;
      ---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine)
      VALUES
        (maxspaylogid,
         AllCurrwaterrate,
         spayShiJiao,
         6,
         0,
         AllPrestoteIn,
         AllPrestoteOut,
         USERID,
         sysdate,
        LastCountBalance,
         ThBalance,
         SumCurrentFlow,
         RunWaterCode,
         PayID,
         6,
         RunWaterCode,
         PayID,
         FellBackMoney);
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = Balance
       WHERE u.userinfoid = USERID;
          --更新账单SPALOY
        UPDATE BILL b
           SET  b.spaylog   = maxspaylogid
         WHERE b.billid in(select bi.billid from bill_jsbillid bi where bi.userinfoid=USERID);
      commit;
      ReturnInfoCode := '000'; --成功
    ELSE
      ReturnInfoCode := '021'; --不欠费
    END IF;
 --elsif(OweCount>0 ) then
 --   ReturnInfoCode := '009'; --缴费金额不足
  else---------------------走预存接口
       PZCount :=1;
       ReturnInfoCode := '000';
    --插入bill信息
     select decode(max(to_number(b.billid)),
                      null,
                      0,
                      max(to_number(b.billid)))
          into maxbillid
          from bill b;
        maxbillid := maxbillid + 1;

    --插入账单信息 B_PAYLOG
        --查询最大ID
        select b_paylogseq.nextval
          into maxpaylogid
          from dual ;
      --获取S_PAYLOG编号
  select s_paylogseq.nextval
    into maxspaylogid
    from dual;
insert into BILL(BILLID,USERINFOID,METERINFOID,METERCODE,LASTMONTHNUMBER,READNUMBER,CURRENTTRAFFIC,WATERATE,BILLSTATE,INVOICEPRINTSTATE,BILLYEAR,BILLMONTH,ISRECTIFY,PAYLOG,MAKEBLLLTIME,SPAYLOG)  VALUES(maxbillid,USERINFOIDs,meterid,metcode,0,0,0,0,1,2,to_char(sysdate,'yyyy'),to_char(sysdate,'MM'),0,maxpaylogid,sysdate,maxspaylogid);


        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine)
        VALUES
          (maxpaylogid,
           0,
           paycash,
           6,
           0,
           maxbillid,
           paycash,
           0,
           USERINFOIDs,
           sysdate,
           LastCountBalance,
           LastCountBalance+paycash,
           0,
           RunWaterCode,
           PayID,
           6,
           RunWaterCode,
           PayID,
           0);
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           paycash);
---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine)
      VALUES
        (maxspaylogid,
         0,
         paycash,
         6,
         0,
         paycash,
         0,
         USERINFOIDs,
         sysdate,
        LastCountBalance,
         LastCountBalance+paycash,
         0,
         RunWaterCode,
         PayID,
         6,
         RunWaterCode,
         PayID,
         0);
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = u.accountmmoney+paycash
       WHERE u.userinfoid = USERINFOIDs;
       commit;
        DXMoney := moneychinese(paycash);
        OweReustsString := REPLACE(RPAD(USERINFOCODE1, 10), ' ', ' ') ||
                             REPLACE(RPAD(USERNAME1, 80), ' ', ' ') ||
                           REPLACE(RPAD(' ', 30), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ')||
                           REPLACE(RPAD(' ', 30), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ')||
                           REPLACE(RPAD(' ', 30), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ')||
                           REPLACE(RPAD(' ', 30), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ') ||
                           REPLACE(RPAD(' ', 10), ' ', ' ')||
                             REPLACE(RPAD(remarks, 100), ' ', ' ') ||
                             REPLACE(RPAD(DXMoney, 100), ' ', ' ') ||
                             REPLACE(RPAD(paycash, 13), ' ', ' ') ||
                             REPLACE(RPAD(DWname, 40), ' ', ' ') ||
                             REPLACE(RPAD(nsrcode, 30), ' ', ' ');
                             OweCount:=0;
    -----------------------走预存接口结束
  end if;
  select PZCount * 733 + 37 into ReturnInfoLength from dual;
  IF (ReturnInfoCode = '000') THEN
    Results := ReturnInfoCode;
    retoutdata := lpad(ReturnInfoLength, 6, '0') ||
               REPLACE(RPAD(TradeCode, 2), ' ', ' ') ||
               REPLACE(RPAD(BankCode, 2), ' ', ' ') || ReturnInfoCode ||
               REPLACE(RPAD(RunWaterCode, 20), ' ', ' ')
               || lpad(ceil(OweCount/4), 2,'0') ||OweReustsString ||  EndCode;
               --retoutdata :=retoutdatya;
    --retoutdata:= returncode;
    insert into BILL_jsinfo(waterFID,woutdata,insertdate)values(RunWaterCode,retoutdata,sysdate);
    OPEN outdata FOR
              SELECT waterFID,woutdata,insertdate
                FROM BILL_jsinfo a1
               WHERE a1.waterFID = RunWaterCode;

  ELSE
    Results := ReturnInfoCode;
  END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
     delete B_VERIFYBILL b where b.useinfocode=UserCode and b.bankcurrentnum=RunWaterCode and b.payddate=PayDate;
    commit;
    

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY)
        VALUES
          ((select nvl(max(b.VERIFYBILLID),0)+1 from B_VERIFYBILL b) ,
           0,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           paycash);
           COMMIT;
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN TOO_MANY_ROWS THEN
    delete B_VERIFYBILL b where b.useinfocode=UserCode and b.bankcurrentnum=RunWaterCode and b.payddate=PayDate;
    commit;
 

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY)
        VALUES
          ((select nvl(max(b.VERIFYBILLID),0)+1 from B_VERIFYBILL b) ,
           0,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           paycash);
           COMMIT;
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN OTHERS THEN
      delete B_VERIFYBILL b where b.useinfocode=UserCode and b.bankcurrentnum=RunWaterCode and b.payddate=PayDate;
    commit;
     SQL_ERM:=SQLERRM;
        
     INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_YC_PayInfoUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_YC_PayInfoUpdate');
   

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY)
        VALUES
          ((select nvl(max(b.VERIFYBILLID),0)+1 from B_VERIFYBILL b) ,
           0,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           paycash);
     COMMIT;
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
  

    ROLLBACK;
 end;   
END pkg_ys;
/

