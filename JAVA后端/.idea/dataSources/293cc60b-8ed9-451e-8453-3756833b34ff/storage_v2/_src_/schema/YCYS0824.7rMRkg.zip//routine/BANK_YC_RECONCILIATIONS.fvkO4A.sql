create procedure Bank_YC_Reconciliations(VerifyBillDate in VARCHAR2, --对账日期
                                                    userinfocode   in VARCHAR2, --用户编号
                                                    SumMoney       in VARCHAR2, --用户金额
                                                    BankCode       in VARCHAR2, --银行代号
                                                    Results        out VARCHAR2,
                                                    outdata        out VARCHAR2) AS
  ReturnInfoCode VARCHAR2(3); --返回信息码
  usercode varchar2(50);

  RecordCount VARCHAR2(50); --记录数
  PayMoney    VARCHAR2(20); --实收总金额

  OriginalRunWaterCode VARCHAR2(200);
  NetWorkCode  VARCHAR2(200);
  sumcount    VARCHAR2(50); 
  OweReusts        sys_refcursor;
begin
usercode:=userinfocode;
select nvl(sum(count(0)) ,0)
    into sumcount
 FROM B_VERIFYBILL T
     JOIN B_PAYLOG bp
      on T.paylogid = bp.paylog
      left join am_u_userinfo am on am.userinfoid=bp.userinfoid
   WHERE T.Bankccode = BankCode
     AND am.userinfocode  = usercode
     AND to_char(bp.ddatetime, 'yyyyMMdd') = VerifyBillDate
     AND bp.PAYREDSTATE = 0  group by t.useinfocode;
     if(sumcount>0)then
select lpad(SUM(bp.PAIDMONEY+bp.latefine) * 100 ,8,'0')  
    into PayMoney
 FROM B_VERIFYBILL T
     JOIN B_PAYLOG bp
      on T.paylogid = bp.paylog
      left join am_u_userinfo am on am.userinfoid=bp.userinfoid
   WHERE T.Bankccode = BankCode
     AND am.userinfocode  = usercode
     AND to_char(bp.ddatetime, 'yyyyMMdd') = VerifyBillDate
     AND bp.PAYREDSTATE = 0 ;
   ----如果总金额一致，直接按照户号和对账日期更新
if( PayMoney = SumMoney) then
Results :=  '000';
      update B_VERIFYBILL b set b.result=1 where b.Bankccode = BankCode
     AND b.payddate = VerifyBillDate and b.useinfocode=usercode;
    outdata := '成功';
    -----否则按照银行流水号更新具体成功交易
    else    
        OPEN OweReusts FOR
 select *  from ( select  COUNT(0) cc ,
       lpad(SUM(bp.PAIDMONEY+bp.latefine) * 100 ,8,'0'),bp.BANKCURRENTNUM,bp.banksitecode
         
    FROM B_VERIFYBILL T
    LEFT JOIN B_PAYLOG bp
      on T.paylogid = bp.paylog
      left join am_u_userinfo am on am.userinfoid=bp.userinfoid
   WHERE T.Bankccode = BankCode
     AND am.userinfocode  = usercode
     AND to_char(bp.ddatetime, 'yyyyMMdd') = VerifyBillDate
     AND bp.PAYREDSTATE = 0 group by bp.BANKCURRENTNUM,bp.banksitecode 
     order by count(0) asc
     ) vb where  vb.cc=1;
     loop
  FETCH OweReusts into RecordCount, PayMoney,OriginalRunWaterCode,NetWorkCode;
       EXIT WHEN OweReusts%NOTFOUND;
  IF (RecordCount = 0) THEN
    ReturnInfoCode := '021'; --无记录需要红冲
     update B_VERIFYBILL b set b.result=2 where b.Bankccode = BankCode
     AND b.payddate = VerifyBillDate and b.bankcurrentnum=OriginalRunWaterCode;
      outdata := '无记录需要红冲';
  ELSe
    ReturnInfoCode := '000';
    update B_VERIFYBILL b set b.result=1 where b.Bankccode = BankCode
     AND b.payddate = VerifyBillDate and b.bankcurrentnum=OriginalRunWaterCode;
      outdata := '成功';
  END IF;
 
  end loop;
  end if;
   
commit;
else
      update B_VERIFYBILL b set b.result=3 where b.Bankccode = BankCode
     AND b.payddate = VerifyBillDate and b.useinfocode=usercode;
    outdata := '失败';
  end if;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;

end Bank_YC_Reconciliations;


/

