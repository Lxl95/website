create view V_SMS_HUIZONGQIANFEI as
select am.userinfoid,
       am.userinfocode,
       am.contect,
       am.username,
    (nvl(b.waterate,0)-nvl(am.accountmmoney,0)) as YE,
    (nvl(b.waterate,0)-nvl(am.accountmmoney,0)) AS WATERATE,
   to_char( sysdate,'yyyy-MM-dd') today,
       accountmmoney,
       am.useraddress,
       am.siteid,
       am.rosterid,am.custominfoid,am.communtyid
  from (select userinfoid,sum(waterate+bb.latefee) waterate from bill  bb where  bb.billstate = 2 and bb.isrectify = 0
   and bb.waterate > 0 group by userinfoid) b
  left join am_u_userinfo am
    on b.userinfoid = am.userinfoid
    and am.payway not in (5,12,13) and am.userstate not in(3) and am.userinfoid is not  null


/

