create trigger TB_XZLCDETAILYJTR
    before insert
    on TB_XZLCDETAILYSYJ
    for each row
begin
    select tb_xzlcdeysyjsq.nextval into :new.keyid from dual;
    end;

/

