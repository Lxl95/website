create view V_B_WATERRATEINFO as
select b.readdate,'水费生成应收' as type,b.makebllltime,0 as paidmoney ,b.waterate,u.Accountmmoney,0 as lastmonthnumber,0 as readnumber ,0 as currenttraffic ,b.userinfoid,b.meterinfoid,u.userinfocode,b.billid,u.username,b.billstate,0 as thisbalance,0 as lastbalance from bill b
 left join am_u_userinfo u on b.userinfoid=u.userinfoid
 union
select b.readdate,'水费现金收款' as type,p.ddatetime,p.paidmoney,b.waterate,am.Accountmmoney, b.lastmonthnumber,b.readnumber,b.currenttraffic ,b.userinfoid,b.meterinfoid,am.userinfocode ,b.billid,am.username,b.billstate,p.thisbalance,p.lastbalance from b_paylog p
left join bill b ON p.billids LIKE '%' || to_char(b.billid) || '%' AND p.userinfoid = b.userinfoid
left join am_u_userinfo am on b.userinfoid=am.userinfoid where b.billstate=1 and p.payredstate=0


/

