create trigger TRG_SM_P_PARAM
    before insert
    on SM_P_PARAM
    for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
begin
    SELECT seq_sm_param.nextval INTO :new.PARAMID FROM dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/

