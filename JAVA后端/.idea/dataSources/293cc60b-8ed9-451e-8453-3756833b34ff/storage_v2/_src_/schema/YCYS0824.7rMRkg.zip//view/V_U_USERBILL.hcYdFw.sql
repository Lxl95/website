create view V_U_USERBILL as
select distinct s.sitename,u.openid, u.userinfoid,u.userinfocode,u.username,u.accountmmoney,u.contect,u.useraddress,uw.usewatertypename, um.lastnumber,um.metercurrentreading,
                         decode(bi.sumwate,null,0,bi.sumwate) as sumwate,
                         decode(bi.sumwatenum,null,0,bi.sumwatenum) as sumwatenum


                             from  am_u_userinfo u
                             left join sm_s_site s on u.siteid=s.siteid
                              left join  bill b  on b.userinfoid=u.userinfoid
                            left join (select bb.userinfoid,sum(bb.waterate) as sumwate
                            ,sum(bb.currenttraffic) as sumwatenum
                            from bill bb where bb.billstate=2 and bb.isrectify=0  group by bb.userinfoid) bi on b.userinfoid=bi.userinfoid

                             left join (select m.lastnumber,m.metercurrentreading,m.meterinfoid from  mm_m_meterinfo m ) um on um.meterinfoid=u.meterinfoid
                            left join bs_b_usewatertype uw on uw.usewatertypeid=u.usewatertypeid


/

