create trigger T_AM_U_NEW_USERLOG
    before insert
    on AM_U_NEW_USERLOG
    for each row
declare
  -- local variables here
begin
  select U_NEW_USERLOG.Nextval into:new.ID from dual;
end t_AM_U_NEW_USERLOG;

/

