create trigger WX_INDEX_INDEXDATA_TRIGGER
    before insert
    on WX_INDEX_INDEXDATA
    for each row
begin
  select wx_index_indexdata_sq.nextval into :NEW.id from dual;
end;

/

