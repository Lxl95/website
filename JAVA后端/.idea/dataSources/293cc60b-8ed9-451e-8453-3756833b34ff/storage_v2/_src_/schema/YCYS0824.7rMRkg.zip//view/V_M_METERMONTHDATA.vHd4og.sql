create view V_M_METERMONTHDATA as
select m.meterbrandid,m.metercalid,m.metertype,m.meteruse,m.meterbasenumber,m.meteraddress,m.meterstate, ui.userinfocode,ui.username,ui.contect,  mmd."METERDATACURRENTMONTHID",mmd."USERINFOID",mmd."METERINFOID",mmd."METERCODE",mmd."LASTMONTHNUMBER",mmd."READNUMBER",mmd."CURRENTTRAFFIC",mmd."READDATE",mmd."ISMAKEBILL",ui.userinfoid as UserID,r."ROSTERID",r."ROSTERCODE",r."ROSTERNAME",r."METERREADINGCYCLE",r."STARTREADINGDAY",r."STARTLATEFINEDAY",r."METERREADERID",r."ROSTERTYPE",r."ROSTERSTATE",r."REMARK",r."SITEID",
to_char(mmd.readdate,'mm') as CurrentMonth  ,to_char(mmd.readdate,'yyyy')  as CurrentYear,case when c.communtyid is null then 0 else c.communtyid end as communtyid,c.communtycode,c.communtyname,c.communtyaddress
    from MM_M_METERDATACURRENTMONTH mmd
    left join am_u_userinfo ui on ui.meterinfoid = mmd.meterinfoid
    left join am_r_roster r on ui.rosterid = r.rosterid
    left join bs_u_community c on ui.communtyid = c.communtyid
    left join MM_M_METERINFO m on mmd.meterinfoid=m.meterinfoid


/

