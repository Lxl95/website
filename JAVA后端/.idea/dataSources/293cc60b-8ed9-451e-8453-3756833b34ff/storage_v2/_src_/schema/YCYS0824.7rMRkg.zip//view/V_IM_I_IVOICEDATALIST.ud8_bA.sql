create view V_IM_I_IVOICEDATALIST as
SELECT il."INVOICEDATALISTID",
       il."INVOICETYPE",
       il."INVOICEVERSIONCODE",
       il."INVOICENUMBER",
       il."INVOICEGETUSERID",
       il.INVOICEGETTIME,
       il."INVOICEGETOPERID",
       il."INVOICEREVERTUSERID",
       il."INVOICEREVERTTIME",
       il."INVOICEREVERTOPERID",
       il."INVOICEDUMPINGUSERID",
       il."INVOICEDUMPINGTIME",
       il."INVOICEDUMPINGOPERID",
       il."INVOICESTATE",
       il."RECEIVEINVOICEPERSON",
       il."INVOICEUSERID",
       il."INVOICETIME",
       il."INVOICEOPERID",
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicegetuserid) as InvoicGetUsername,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicegetoperid) as InvoiceOpername,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicerevertuserid) as InvoiceRevertname,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicerevertoperid) as InvoiceRevertOpername,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicedumpinguserid) as InvoiceDumpingname,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicedumpingoperid) as InvoiceDumpingOpername,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoiceuserid) as INVOICEUSERName,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.INVOICEOPERID) as INVOICEInOPERName,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicerevertfileid) as INVOICEREVERTFILEName,
       (select a.cadminname
          from sm_p_admin a
         where a.iadminid = il.invoicerevertfileoperid) as INVOICEREVERTFILEOPERName,
       il.invoicerevertfiletime,
       i.invoicestate as invoicestatefic,
       il.isused
  FROM IM_I_IVOICEDATALIST il
  JOIN im_i_ivoicespecific i
    on il.invoicetype = i.invoicetype
   and il.invoiceversioncode = i.invoiceversioncode

/

