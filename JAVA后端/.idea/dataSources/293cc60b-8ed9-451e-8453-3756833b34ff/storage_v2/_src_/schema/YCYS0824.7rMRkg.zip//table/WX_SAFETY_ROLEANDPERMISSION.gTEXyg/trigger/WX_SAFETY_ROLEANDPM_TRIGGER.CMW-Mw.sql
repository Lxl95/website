create trigger WX_SAFETY_ROLEANDPM_TRIGGER
    before insert
    on WX_SAFETY_ROLEANDPERMISSION
    for each row
begin
  select wx_safety_roleAndPermission_sq.nextval into :NEW.id from dual;
end;

/

