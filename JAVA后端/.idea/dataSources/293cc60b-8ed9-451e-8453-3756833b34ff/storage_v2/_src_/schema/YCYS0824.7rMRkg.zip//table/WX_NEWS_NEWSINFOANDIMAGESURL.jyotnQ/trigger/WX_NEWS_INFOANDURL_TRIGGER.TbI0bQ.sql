create trigger WX_NEWS_INFOANDURL_TRIGGER
    before insert
    on WX_NEWS_NEWSINFOANDIMAGESURL
    for each row
begin
  select wx_news_InfoAndUrl_sq.nextval into :NEW.id from dual;
end;

/

