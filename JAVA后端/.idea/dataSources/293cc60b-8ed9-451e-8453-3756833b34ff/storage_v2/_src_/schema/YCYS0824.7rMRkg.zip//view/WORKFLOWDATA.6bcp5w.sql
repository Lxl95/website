create view WORKFLOWDATA as
select  '' as  lsh, '' as  instanceid ,'' as  REQUESTTELPHONE, '' as  INSTALLADRESS,'' as  PRINT, '' as  SBKJ   from dual


/

