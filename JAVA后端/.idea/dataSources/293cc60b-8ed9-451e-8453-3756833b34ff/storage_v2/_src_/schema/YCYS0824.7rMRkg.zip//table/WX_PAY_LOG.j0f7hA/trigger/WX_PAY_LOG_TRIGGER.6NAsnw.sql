create trigger WX_PAY_LOG_TRIGGER
    before insert
    on WX_PAY_LOG
    for each row
begin
  select wx_pay_log_sq.nextval into :NEW.id from dual;
end;

/

