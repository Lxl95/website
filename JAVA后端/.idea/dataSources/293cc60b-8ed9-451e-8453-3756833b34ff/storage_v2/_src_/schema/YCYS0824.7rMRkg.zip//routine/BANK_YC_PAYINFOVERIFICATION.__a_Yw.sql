create procedure Bank_YC_PayInfoVerification(UserCode     in VARCHAR2, --用户代码
                                                  PayMoney     in VARCHAR2, --缴费金额
                                                  Results out VARCHAR2) AS
ReturnInfoCode VARCHAR2(3); --响应码
 BasePayMoney    VARCHAR2(12) := PayMoney; --缴费金额 银行原数据返回
 USERNAME1     VARCHAR2(80); --用户名称
 ACCOUNTMMONEY1   NUMBER(20, 2); --账户余额 单位:分
  Balance          NUMBER(11, 2) := 0; --本次余额
    SUMWaterRate   VARCHAR2(12); --总欠费
 USERINFOIDs            NUMBER;
 num                    NUMBER;
   SQL_ERM          VARCHAR2(4000);

begin

  select

   T.username,
   nvl(T.ACCOUNTMMONEY, 0) 　 ACCOUNTMMONEY,
   T.USERINFOID

    INTO USERNAME1,
         ACCOUNTMMONEY1,
         USERINFOIDs
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = UserCode
     AND ROWNUM = 1;
       BEGIN

   -- MONEY := CAST(BasePayMoney AS NUMBER);
    IF (to_number(BasePayMoney) <= 0) THEN
      ReturnInfoCode := '009'; --金额错误 :小于等于0
      Results        := ReturnInfoCode;
      RETURN;
    ELSE
      dbms_output.put_line(BasePayMoney || '是[0-9]的数字序列');
    END IF;
  EXCEPTION
    WHEN value_error THEN
      --字符串转实数错误
      dbms_output.put_line(BasePayMoney || '不是[0-9]的数字序列');
      ReturnInfoCode := '009'; --金额错误 :不是数字
      Results        := ReturnInfoCode;
      RETURN;
  END;
  --验证是否有欠费
  SELECT COUNT(0) into num
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2 and b.waterate>0 and b.readdate is not null
             AND B.ISRECTIFY = 0;
    if(num >0) then
  --查询欠费笔数
  select nvl(t.num,0), nvl(t.sumwa,0)
    INTO num, SUMWaterRate
    from (SELECT COUNT(0) as num,
                 SUM(B.WATERATE) + sum(b.latefee) - sum(b.REDUCTIONMONEY) as sumwa

            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2 and  b.waterate>0 and b.readdate is not null
             AND B.ISRECTIFY = 0
           GROUP BY B.USERINFOID) t
   where rownum = 1;
   end if;

  --获取本次余额
  Balance := to_number(PayMoney) / 100 + ACCOUNTMMONEY1 -
             to_number(SUMWaterRate);

  if (Balance >= 0 ) and (num>0) then
     ReturnInfoCode := '000'; 
     Results        := ReturnInfoCode;
     else
        ReturnInfoCode := '009'; --缴费金额不足
        Results        := ReturnInfoCode;
     end if;
     EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN OTHERS THEN
     SQL_ERM:=SQLERRM;
     INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_YC_PayInfoUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_YC_PayInfoUpdate');
     COMMIT;
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;


    ROLLBACK;
 end;


/

