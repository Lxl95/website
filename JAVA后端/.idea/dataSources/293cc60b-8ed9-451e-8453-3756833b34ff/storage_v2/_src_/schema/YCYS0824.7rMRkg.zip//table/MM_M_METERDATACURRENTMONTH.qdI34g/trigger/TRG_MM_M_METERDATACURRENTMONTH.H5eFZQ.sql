create trigger TRG_MM_M_METERDATACURRENTMONTH
    before insert
    on MM_M_METERDATACURRENTMONTH
    for each row
DECLARE
   integrity_error   EXCEPTION;
   errno             INTEGER;
   errmsg            CHAR (200);
BEGIN
   SELECT seq_mm_meterdatacurrentmonth.NEXTVAL
     INTO :NEW.meterdatacurrentmonthid
     FROM DUAL;
--  Errors handling
EXCEPTION
   WHEN integrity_error
   THEN
      raise_application_error (errno, errmsg);
END;
/

