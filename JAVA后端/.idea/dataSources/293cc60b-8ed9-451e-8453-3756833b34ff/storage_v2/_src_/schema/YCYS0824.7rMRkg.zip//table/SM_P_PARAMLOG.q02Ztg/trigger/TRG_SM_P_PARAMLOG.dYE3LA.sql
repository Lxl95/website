create trigger TRG_SM_P_PARAMLOG
    before insert
    on SM_P_PARAMLOG
    for each row
declare
    integrity_error  exception;
    errno            integer;
    errmsg           char(200);
begin
    SELECT seq_sm_paramlog.nextval INTO :new.paramlogid FROM dual;

--  Errors handling
exception
    when integrity_error then
       raise_application_error(errno, errmsg);
end;
/

