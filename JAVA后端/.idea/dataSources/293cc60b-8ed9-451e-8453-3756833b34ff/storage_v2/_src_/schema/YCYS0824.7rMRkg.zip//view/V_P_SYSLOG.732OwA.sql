create view V_P_SYSLOG as
SELECT  iSysLogID, iAdminID, cURL, cIP, dLoginDT, cAdminName,
                   (SELECT  cFunName
                   FROM     sm_p_function
                   WHERE   (iFunID = SM_P_SysLog.iFunctionID)) AS cFunName, iFunctionID
FROM     SM_P_SysLog where iFunctionID<>0  order by dLoginDT desc


/

