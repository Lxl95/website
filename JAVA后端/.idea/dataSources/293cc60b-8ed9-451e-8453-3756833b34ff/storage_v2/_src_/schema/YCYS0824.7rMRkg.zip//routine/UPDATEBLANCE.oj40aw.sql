create procedure updateBlance is
  paidmoney       number := 0;
  thisbalance     number := 0;
  prestorein      number := 0;
  prestoreout     number := 0;
  receivablemoney number := 0;
begin
  --开始游标
  declare
    cursor c_joba is --找到所有需要修改的用户
      select am.userinfocode,
             am.accountmmoney,
             ua.thisbance,
             am.userinfoid,
             am.metercode,
             am.meterinfoid,
             am.rosterid
        from am_u_userinfo am
        left join user_accountMoney ua
          on ua.userinfocode = am.userinfocode
       where am.accountmmoney <> ua.thisbance;
    c_rowa c_joba%rowtype;
  begin
    for c_rowa in c_joba loop
      receivablemoney := 0; --应收金额为0
      if c_rowa.accountmmoney > c_rowa.thisbance then
        paidmoney   := 0;
        prestorein  := 0;
        prestoreout := c_rowa.accountmmoney - c_rowa.thisbance;
      else
        --新系统少，需要添加
        paidmoney   := c_rowa.thisbance - c_rowa.accountmmoney;
        prestorein  := paidmoney;
        prestoreout := 0;
      end if;
      ----------------------
      begin
        Insert into b_paylog
          (paylog,
           receivablemoney,
           paidmoney,
           paidtype,
           prestorein,
           prestoreout,
           billids,
           lastbalance,
           thisbalance,
           latefine,
           ddatetime,
           paylogbatch,
           userinfoid)
        values
          ((select max(bp.paylog) + 1 from b_paylog bp),
           receivablemoney,
           paidmoney,
           1,
           prestorein,
           prestoreout,
           -999,
           c_rowa.thisbance + prestoreout - prestorein,
           c_rowa.thisbance,
           0,
           sysdate,
           c_rowa.userinfoid || '_' || c_rowa.userinfocode || '_' ||
           to_char(sysdate, 'yyyyMMdd'),
           c_rowa.userinfoid);
        Insert into s_paylog
          (spaylog,
           receivablemoney,
           paidmoney,
           paidtype,
           prestorein,
           prestoreout,
           lastbalance,
           thisbalance,
           latefine,
           ddatetime,
           paylogbatch,
           userinfoid)
        values
          ((select max(sp.spaylog) + 1 from s_paylog sp),
           receivablemoney,
           paidmoney,
           1,
           prestorein,
           prestoreout,
           c_rowa.thisbance + prestoreout - prestorein,
           c_rowa.thisbance,
           0,
           sysdate,
           c_rowa.userinfoid || '_' || c_rowa.userinfocode || '_' ||
           to_char(sysdate, 'yyyyMMdd'),
           c_rowa.userinfoid);
        insert into bill
          (billid,
           userinfoid,
           meterinfoid,
           metercode,
           lastmonthnumber,
           readnumber,
           currenttraffic,
           readdate,
           waterate,
           billstate,
           billyear,
           billmonth,
           isrectify,
           paylog,
           makebllltime,
           meterreaderid,
           userinfocode,
           rosterid,
           spaylog)
        values
          ((select max(b.billid) + 1 from bill b),
           c_rowa.userinfoid,
           c_rowa.meterinfoid,
           c_rowa.metercode,
           0,
           0,
           0,
           sysdate,
           0,
           1,
           2018,
           11,
           0,
           (select max(bp.paylog) from b_paylog bp),
           sysdate,
           1,
           c_rowa.userinfocode,
           c_rowa.rosterid,
           (select max(spaylog) from s_paylog sp));
         update am_u_userinfo am set am.accountmmoney = c_rowa.thisbance where am.userinfoid = c_rowa.userinfoid;
      exception
        when others then
          dbms_output.put_line(c_rowa.userinfoid);
          continue;
      end;
      ----------------------
      commit;
    end loop;
  end;
end updateBlance;


/

