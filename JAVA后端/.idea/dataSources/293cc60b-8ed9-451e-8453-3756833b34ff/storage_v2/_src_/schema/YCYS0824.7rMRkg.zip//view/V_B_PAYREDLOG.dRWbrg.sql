create view V_B_PAYREDLOG as
SELECT u.userinfocode, u.username,u.useraddress,u.usertype,p."PAYLOG",p."RECEIVABLEMONEY",p."PAIDMONEY",p."PAIDTYPE",p."INVOICEPRINTSTATE",p."BILLIDS",p."AGENT",p."PRESTOREIN",p."PRESTOREOUT",p."CARDAMOUNT",p."COMPORT",p."CARDAGENT",p."PATCHCARDAMOUNT",p."PATCHCURRENTNUM",p."PATCHCARDNUM",p."CHEQUEAMOUNT",p."CHEQUENUM",p."CHEQUEAGENT",p."PATHCHCARDAGENT",p."USERINFOID",p."DDATETIME",p."PAYREDSTATE",b.billid,b.meterinfoid,b.metercode,
b.lastmonthnumber,b.readnumber,b.currenttraffic,b.readdate,b.waterate,b.billstate,b.billyear,b.billmonth,b.isrectify,p.redtime,spa.CADMINNAME,spa.cadminemail,u.cardid


  FROM b_paylog p
  left JOIN bill b ON p.billids LIKE '%' || to_char(b.billid) || '%' AND p.userinfoid = b.userinfoid
  left join am_u_userinfo u on p.userinfoid=u.userinfoid
	left join SM_P_ADMIN spa on spa.IADMINID = p.PAYREDIADMINID


/

