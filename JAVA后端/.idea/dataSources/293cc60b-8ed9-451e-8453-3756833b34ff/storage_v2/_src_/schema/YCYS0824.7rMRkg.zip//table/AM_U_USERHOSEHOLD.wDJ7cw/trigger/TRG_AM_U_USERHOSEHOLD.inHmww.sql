create trigger TRG_AM_U_USERHOSEHOLD
    before insert
    on AM_U_USERHOSEHOLD
    for each row
DECLARE
   integrity_error   EXCEPTION;
   errno             INTEGER;
   errmsg            CHAR (200);
BEGIN
   SELECT SEQ_AM_U_USERHOSEHOLDID.NEXTVAL
     INTO :NEW.ID
     FROM DUAL;
--  Errors handling
EXCEPTION
   WHEN integrity_error
   THEN
      raise_application_error (errno, errmsg);
END;

/

