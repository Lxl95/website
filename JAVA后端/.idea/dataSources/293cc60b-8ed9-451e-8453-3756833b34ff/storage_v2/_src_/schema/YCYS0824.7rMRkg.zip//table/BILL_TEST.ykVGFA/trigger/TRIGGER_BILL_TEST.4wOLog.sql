create trigger TRIGGER_BILL_TEST
    before insert
    on BILL_TEST
    for each row
begin
  select bill_test_sequence.nextval into :new.billid from dual;
end Trigger_Bill_Test;

/

