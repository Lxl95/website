create trigger WX_INDEX_UMD_TRIGGER
    before insert
    on WX_INDEX_INDEXUPSTREAMMSGDIST
    for each row
begin
  select wx_index_UpstreamMsgDist_sq.nextval into :NEW.id from dual;
end;

/

