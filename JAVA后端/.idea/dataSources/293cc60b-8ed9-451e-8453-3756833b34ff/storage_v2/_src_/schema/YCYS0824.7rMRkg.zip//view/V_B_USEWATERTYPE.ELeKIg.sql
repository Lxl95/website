create view V_B_USEWATERTYPE as
select max(specificpriceitemid) specificpriceitemid,
       max(usewatertypeid) usewatertypeid,
       max(usewatertypename) usewatertypename,
       max(usewatertype) usewatertype,
       max(mainusewatertype) mainusewatertype
  from (select regexp_substr(b.specificpriceitemids, '[^,]+', 1, level) specificpriceitemid,
               b.usewatertypeid,
               b.usewatertypename,
               b.usewatertype,
               b.mainusewatertype
          from bs_b_usewatertype b
        connect by regexp_substr(b.specificpriceitemids, '[^,]+', 1, level) is not null) t1
 group by t1.specificpriceitemid
having count(t1.specificpriceitemid) > 0
union
 select '36',111,uwt.usewatertypename,uwt.usewatertype,uwt.mainusewatertype from bs_b_usewatertype uwt where uwt.usewatertypeid=111
 union
 select '37',111,uwt.usewatertypename,uwt.usewatertype,uwt.mainusewatertype from bs_b_usewatertype uwt where uwt.usewatertypeid=111


/

