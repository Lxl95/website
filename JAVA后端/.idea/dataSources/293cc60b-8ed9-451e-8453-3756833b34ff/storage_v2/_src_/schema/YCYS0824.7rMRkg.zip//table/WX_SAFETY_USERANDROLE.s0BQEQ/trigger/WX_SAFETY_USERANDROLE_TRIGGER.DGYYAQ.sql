create trigger WX_SAFETY_USERANDROLE_TRIGGER
    before insert
    on WX_SAFETY_USERANDROLE
    for each row
begin
  select wx_safety_userAndRole_sq.nextval into :NEW.id from dual;
end;

/

