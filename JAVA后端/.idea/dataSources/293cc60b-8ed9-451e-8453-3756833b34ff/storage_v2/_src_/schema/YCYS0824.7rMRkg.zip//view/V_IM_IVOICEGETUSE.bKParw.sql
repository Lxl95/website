create view V_IM_IVOICEGETUSE as
SELECT il."INVOICELOGID",il."INVOICESTARTNUM",il."INVOICEENDTNUM",il."INVOICEGETUSERID",il.INVOICEGETTIME ,il."INVOICEOPERA",il."OPERATYPE",il."INSTORAGENUM",il."INVOICESPECIFICID",isp.invoicetype,isp.invoiceversioncode,isp.invoicestate,
  (select a.cadminname from sm_p_admin a where a.iadminid=il.invoicegetuserid) as INVOICEGETUSERname
  ,(select a.cadminname from sm_p_admin a where a.iadminid=il.invoiceopera) as INVOICEGETOPERNAME

      FROM IM_I_IVOICELOG il join IM_I_IVOICESPECIFIC isp
                             on il.invoicespecificid=isp.invoicespecificid


/

