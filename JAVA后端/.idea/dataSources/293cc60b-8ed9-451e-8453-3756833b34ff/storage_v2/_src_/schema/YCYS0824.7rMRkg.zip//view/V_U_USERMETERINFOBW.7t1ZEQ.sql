create view V_U_USERMETERINFOBW as
SELECT /*l.locatioareaid,
       l.locationareacode,
       l.locationareaname,
       c.communtyid,
       c.communtycode,
       c.communtyname,*/
       r.rostercode,
       r.rosterid,
       c.communtycode,mmw.wellid Meterwallcode,
      -- r.rostername,
       u.userinfoid,
       u.userstate,
       c.custominfocode,
       u.usertype,
       mi."METERINFOID",
       mi."METERCODE",
       mi."METERBRANDID",
       mi."METERCALID",
       mi."METERTYPE",
       mi."METERUSE",
       mi."METERBASENUMBER",
       mi."METERCURRENTREADING",
       mi."METERADDRESS",
       mi."METERSTATE",
    /*   ml.lastmonthnumber,
       ml.readnumber,
       ml.currenttraffic,
       ml.readdate,
       ml.datayear,
       ml.datamonth,*/
       u.remark,
       u.rosterorder,
       mc.metercal,
       s.siteid,
       s.sitecode,
       s.sitename,  r.rostername,  u.userinfocode,u.useraddress,
       u.username,
       b.meterbrandname,
       u.isaccount,
       case u.userstate when 5 then '拆表'
                     else '正常'
                       end as userstate1,
      -- ml.meterdatacurrentmonthid,
       --ml.addflow,
       US.USEWATERTYPENAME,bim.SEALCODE,bim.SEALCODE1,bim.SEALCODE2,bim.METERCAGETORY,bim.meteruse AS METERUSEBIM,bim.INSTALLTYPE,bim.METERSTANDARD,bim.METERBRAND,bim.CALIBER,bim.METERTYPE AS METERTYPEBIM,bim.LOCATION
,bim.WARNINGVALUE,bim.WAREHOUSE,bim.STATE,bim.OPERATIME,vv.CREATETIME,nvl(vv1.changedate,mi.changetime) changedate
  FROM MM_M_METERINFO mi
   join AM_U_USERINFO u
    on u.userinfocode = mi.userinfocode
   left join am_c_custominfo c
    on u.custominfoid = c.custominfoid
   left join mm_w_userwell mmw
    on mmw.userid = u.userinfoid
 /* left join (select t.*
  from (select m.*, row_number() over(partition by m.meterinfoid order by m.meterdatacurrentmonthid desc) rn
          from mm_m_meterdatacurrentmonth m) t
 where t.rn = 1) ml
    on mi.meterinfoid = ml.meterinfoid*/
  left join AM_R_ROSTER r
    on r.rosterid = u.rosterid

  left join SM_S_SITE s
    on u.siteid = s.siteid
  left join SM_P_LOCATIONAREA l
    on u.locatioareaid = l.locatioareaid
  left join BS_U_COMMUNITY c
    on u.communtyid = c.communtyid
  left join mm_m_meterbrand b
    on mi.meterbrandid = b.meterbrandid
  LEFT JOIN MM_M_METERCAL mc
    ON mi.metercalid = mc.metercalid
  LEFT JOIN BS_B_USEWATERTYPE US
    ON mi.meterwatertypeid = US.USEWATERTYPEID
     LEFT JOIN (select * from  BW_I_METERINPUT bmm where bmm.state=4) bim ON bim.metercode = mi.metercode
     left join (select max(bl.createtime) as createtime,bl.usercode from bw_c_changemeterlog bl group by bl.usercode ) vv  on vv.usercode=u.userinfocode
      left join (select max(bl.changedate) as changedate,bl.usercode from bw_c_changemeterlog bl group by bl.usercode ) vv1  on vv1.usercode=u.userinfocode


/

