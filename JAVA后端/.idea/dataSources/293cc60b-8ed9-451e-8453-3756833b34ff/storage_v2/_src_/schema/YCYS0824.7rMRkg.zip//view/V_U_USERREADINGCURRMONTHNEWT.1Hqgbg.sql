create view V_U_USERREADINGCURRMONTHNEWT as
SELECT r.meterreaderid,
       sm.cadminname,
       u.welladd,
       u.meterwalladdress,
       u.contect,
       u.mixwatertypeid,
       u.mixwatertype,
       u.mixwaterrate,
       u.mixwaterflow,
       u.usewatertypeid,
       bu.usewatertypename,
       l.LOCATIOAREAID,
       l.locationareacode,
       l.locationareaname,
       c.communtyid,
       c.communtycode,
       c.communtyname,
       r.rostercode,
       r.rosterid,
       r.rostername,
       u.userinfoid,
       u.userstate,
       u.userinfocode,
       u.cardid,
       u.username,
       u.useraddress,
       mi.METERINFOID,
       mi.METERCODE,
       mi.METERBRANDID,
       mi.METERCALID,
       mi.METERTYPE,
       mi.METERUSE,
       mi.METERBASENUMBER,
       mi.METERCURRENTREADING,
       mi.METERADDRESS,
       mi.METERSTATE,
       ml.lastmonthnumber,
       ml.readnumber,
       ml.currenttraffic,
       ml.readdate,
       ml.datayear,
       ml.datamonth,
       ml.METERDATACURRENTMONTHID,
       u.remark,
       u.rosterorder,
       mc.metercal,
       s.siteid,
       s.sitecode,
       s.sitename,
       b.meterbrandname,
       ml.ismakebill as isaccount,--u.isaccount,是否开账
       ml.readnumber as currnum,---本次读数
       ml.lastmonthnumber as lastnumber,---上次读数
       ml.currenttraffic as currwaternum,---用水量
       ml.creadmeterstate,
       case
         when ml.addflow is null then
          0
         else
          ml.addflow
       end as addflow,
       mf.METERFIXLOGID
  FROM MM_M_METERINFO mi
  LEFT join AM_U_USERINFO u
    on u.meterinfoid = mi.meterinfoid
  left join mm_m_meterdatacurrentmonth ml
    on u.meterinfoid = ml.meterinfoid
  left join AM_R_ROSTER r
    on r.rosterid = u.rosterid
  left join sm_p_admin sm
    on sm.iadminid = r.meterreaderid
  left join SM_S_SITE s
    on u.siteid = s.siteid
  left join SM_P_LOCATIONAREA l
    on u.locatioareaid = l.locatioareaid
  left join BS_U_COMMUNITY c
    on u.communtyid = c.communtyid
  left join mm_m_meterbrand b
    on mi.meterbrandid = b.meterbrandid
  LEFT JOIN MM_M_METERCAL mc
    ON mi.metercalid = mc.metercalid
  left join bs_b_usewatertype bu
    on u.usewatertypeid = bu.usewatertypeid
  left join mm_m_meterfixlog mf
    ON mf.USERINFOID = u.userinfoid
   AND mf.FIXSTATE = 1


/

