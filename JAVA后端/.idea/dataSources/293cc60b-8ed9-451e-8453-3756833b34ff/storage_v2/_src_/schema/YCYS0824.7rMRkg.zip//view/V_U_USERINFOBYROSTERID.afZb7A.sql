create view V_U_USERINFOBYROSTERID as
select u.usertype,
       u.sealnumber,
       wl.communityname,
       u.meterreaderid,
       /*(select count(distinct(readdate)) from bill  where USERINFOID=u.userinfoid and  billstate=2  and isrectify=0) as Arrearscount ,
       (select sum(WATERATE) from BILL where USERINFOID = u.userinfoid and  billstate=2  and isrectify=0 ) as SumMoney,*/
       bb2.Arrearscount,
       bb2.SumMoney,
       case
         when Sumcurrenttraffic is null then
          0
         else
          Sumcurrenttraffic
       end as Sumcurrenttraffic,
       u.WELLADD,
       am.sumcount,
       wl.wellid,
       wl.wellname,
       wl.corrdinate,
       u.usewatertypeid,
       u.usewatertypename,
       u.contect,
       u.meterwalladdress,
       u.mixwatertypeid,
       --u.mixwatertypeid,
       u.mixwaterrate,
       u.mixwaterflow,
       u."LOCATIOAREAID",
       u."LOCATIONAREACODE",
       u."LOCATIONAREANAME",
       u."COMMUNTYID",
       u."COMMUNTYCODE",
       u."COMMUNTYNAME",
       u."ROSTERCODE",
       u."ROSTERID",
       u."ROSTERNAME",
       u."USERINFOID",
       u."USERSTATE",
       u."USERINFOCODE",
       u."USERNAME",
       u."USERADDRESS",
       u."METERINFOID",
       u."METERCODE",
       u."METERBRANDID",
       u."METERCALID",
       u."METERTYPE",
       u."METERUSE",
       u."METERBASENUMBER",
       u."METERCURRENTREADING",
       u."METERADDRESS",
       u."METERSTATE",
       u."LASTMONTHNUMBER",
       u."READNUMBER",
       u."CURRENTTRAFFIC",
       u."READDATE",
       u."DATAYEAR",
       u."DATAMONTH",
       u."REMARK",
       u."ROSTERORDER",
       u."METERCAL",
       u."SITEID",
       u."SITECODE",
       u."SITENAME",
       u."METERBRANDNAME",
       u."ISACCOUNT",
       u."CURRNUM",
       u."LASTNUMBER",
       u."CURRWATERNUM",
       u."ADDFLOW",
       mm.meterdatacurrentmonthid,
       mm.ismakebill,
       u.mixwatertype,
 round((select AVG(currenttraffic)
  from MM_M_METERDATACURRENTMONTH t
 where meterinfoid = mm.meterinfoid
   and READDATE between add_months(mm.READDATE, -3) and
       mm.READDATE),
2) as avgCurrenttraffic,u.accountmmoney
  from v_u_userreadingcurrmonthapp u
  LEFT JOIN mm_m_meterdatacurrentmonth mm
    on mm.meterinfoid = u.METERINFOID
   and mm.datayear = u.DATAYEAR
   and mm.datamonth = u.DATAMONTH
  LEFT JOIN mm_w_userwell w
    on w.userid = u.USERINFOID
  LEFT JOIN mm_w_meterwellrelation wl
    on w.wellid = wl.wellid
  LEFT JOIN (select count(0) as sumcount, u.rosterid
               from am_u_userinfo u
              group by u.rosterid) am
    on am.rosterid = u.rosterid
  left join (select sum(b.currenttraffic) as Sumcurrenttraffic, b.userinfoid
               from bill b
              where billstate = 2
                and isrectify = 0
              group by userinfoid) bb
    on bb.userinfoid = u.userinfoid
  left join (select count(0) as Arrearscount,
                    sum(b.WATERATE) as SumMoney,
                    b.userinfoid
               from bill b
              where billstate = 2
                and isrectify = 0
              group by userinfoid) bb2
    on bb2.userinfoid = u.userinfoid
 order by w.wellid asc


/

