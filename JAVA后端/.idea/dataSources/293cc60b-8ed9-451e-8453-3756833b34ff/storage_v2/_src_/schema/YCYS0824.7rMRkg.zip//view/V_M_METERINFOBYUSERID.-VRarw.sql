create view V_M_METERINFOBYUSERID as
select b.meterbrandname,mc.metercal,
       CASE m.metertype
          WHEN 0 THEN '远传'
          WHEN 1 THEN '普表'
          ELSE ''
       END
          AS mmetertype,
      CASE m.meteruse
          WHEN 1 THEN '计费'
          WHEN 2 THEN '考核'
          ELSE ''
       END
          AS mmeteruse,
      CASE m.meterstate
          WHEN 1 THEN '正在使用'
          WHEN 0 THEN '未使用'
          ELSE ''
       END
          AS mmeterstate,m."METERBRANDID",m."METERCALID",m."METERTYPE",m."METERUSE",m."METERBASENUMBER",m."METERADDRESS",m."METERSTATE",m."USERINFOCODE",m."USERNAME",m."CONTECT",m."METERDATACURRENTMONTHID",m."USERINFOID",m."METERINFOID",m."METERCODE",m."LASTMONTHNUMBER",m."READNUMBER",m."CURRENTTRAFFIC",m."READDATE",m."ISMAKEBILL",m."USERID",m."ROSTERID",m."ROSTERCODE",m."ROSTERNAME",m."METERREADINGCYCLE",m."STARTREADINGDAY",m."STARTLATEFINEDAY",m."METERREADERID",m."ROSTERTYPE",m."ROSTERSTATE",m."REMARK",m."SITEID",m."CURRENTMONTH",m."CURRENTYEAR",m."COMMUNTYID",m."COMMUNTYCODE",m."COMMUNTYNAME",m."COMMUNTYADDRESS"
from v_m_metermonthdata m
   left join am_u_userinfo u on m.USERINFOID=u.userinfoid
   left join mm_m_meterbrand b on m.meterbrandid=b.meterbrandid
   left join mm_m_metercal mc on m.metercalid=mc.metercalid
   left join BS_B_USEWATERTYPE uw on u.usewatertypeid=uw.usewatertypeid


/

