create trigger WX_TEM_TEMPLATE_TRIGGER
    before insert
    on WX_TEM_TEMPLATE
    for each row
begin
  select wx_tem_template_sq.nextval into :NEW.id from dual;
end;

/

