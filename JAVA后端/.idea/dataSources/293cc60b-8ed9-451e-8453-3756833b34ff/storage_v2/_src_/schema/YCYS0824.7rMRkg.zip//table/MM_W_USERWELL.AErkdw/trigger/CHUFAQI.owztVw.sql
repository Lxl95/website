create trigger CHUFAQI
    before insert
    on MM_W_USERWELL
    for each row
    when (new.USERWELLID is null)
begin
  select xulie.nextval into:new.USERWELLID from dual;
  end;
/

