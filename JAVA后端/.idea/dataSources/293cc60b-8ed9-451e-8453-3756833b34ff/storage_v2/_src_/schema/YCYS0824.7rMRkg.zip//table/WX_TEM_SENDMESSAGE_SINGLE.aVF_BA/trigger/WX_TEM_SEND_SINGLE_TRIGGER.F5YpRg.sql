create trigger WX_TEM_SEND_SINGLE_TRIGGER
    before insert
    on WX_TEM_SENDMESSAGE_SINGLE
    for each row
begin
  select wx_tem_send_single_sq.nextval into :NEW.id from dual;
end;

/

