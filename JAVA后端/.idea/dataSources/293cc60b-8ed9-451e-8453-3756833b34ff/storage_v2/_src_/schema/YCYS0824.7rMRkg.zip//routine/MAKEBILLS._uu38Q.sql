create procedure makebills  AS
  begin
  declare
    cursor c_job is

 select * from bill b left join VIEW_CB_Info v on b.billid=v.id;
    c_row c_job%rowtype;
  begin
    for c_row in c_job loop
   --是否已开账删除原来帐单 2 预存不够扣的也删除
         DELETE FROM BILL B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null;
         DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null;

         select max(billid+1) into maxbillid from bill;
      ----------------------
      declare
        cursor c_jobb is
             select st.*,bst.itemtype,bt.usewatertype bttype from specificpricetemp st left join bs_b_specificpriceitem bst on st.spid=bst.specificpriceitemid left join bs_b_usewatertype bt on st.tid=bt.usewatertypeid;

        c_roww c_jobb%rowtype;
      begin
        for c_roww in c_jobb loop


--1：非混合用水
            if c_row.mixwatertype=0 or  c_row.mixwatertype is null then
              --【1】，非混合用水 非否居民用水
                IF   c_roww.bttype = 1 and c_row.usewatertypeid=c_roww.tid     then
                   --生成基本用水

                    DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null and b.specificpriceitemid=c_roww.spid;
                    insert into b_billspecificrate (BILLSPECIFICRATEID, SPECIFICPRICEITEMID, TOTALPRICES, BILLID, CURRENTFLOW,  METERDATACURRENTMONTHID)
                    values ((select max(BILLSPECIFICRATEID+1) from b_billspecificrate), c_roww.spid,
                    c_roww.price*c_row.currenttraffic,
                    maxbillid, c_row.currenttraffic
                    , c_row.meterdatacurrentmonthid);
                end IF ;
                ---居民用水
             IF   c_roww.bttype = 2 and c_row.usewatertypeid=c_roww.tid   then
                   --生成基本用水
               get_waterate_jt(c_row.STEPPRICEITEMID, c_row.jieti1,c_row.jieti2,c_row.steponeprice,c_row.steponeprice2,c_row.currenttraffic,c_row.YEARCYCLESUMFLOW,maxbillid,c_row.METERDATACURRENTMONTHID,c_row.usewatertypeid) ;
             end IF ;
          end if;

--2：混合用水1，定比  【1】，不走阶梯或阶梯0   【2】，阶梯一  【3】，阶梯二
          if c_row.mixwatertype=1 then
                --【1】，非混合用水 非否居民用水
             IF   c_roww.bttype = 1 and c_row.usewatertypeid=c_roww.tid    then
                   --生成基本用水
                        DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null and b.specificpriceitemid=c_roww.spid;
                    insert into b_billspecificrate (BILLSPECIFICRATEID, SPECIFICPRICEITEMID, TOTALPRICES, BILLID, CURRENTFLOW,  METERDATACURRENTMONTHID)
                    values ((select max(BILLSPECIFICRATEID+1) from b_billspecificrate), c_roww.spid,
                    c_roww.price*c_row.currenttrafficbz,
                    maxbillid, c_row.currenttrafficbz
                    , c_row.meterdatacurrentmonthid);
                end IF ;
                ---居民用水
             IF   c_roww.bttype = 2 and c_row.usewatertypeid=c_roww.tid   then
                   --生成基本用水
               get_waterate_jt(c_row.STEPPRICEITEMID, c_row.jieti1,c_row.jieti2,c_row.steponeprice,c_row.steponeprice2,c_row.currenttrafficbz,c_row.YEARCYCLESUMFLOW,maxbillid,c_row.METERDATACURRENTMONTHID,c_row.usewatertypeid) ;
             end IF ;


              IF   c_roww.bttype = 1 and c_row.mixwatertypeid=c_roww.tid    then
                   --生成基本用水
                        DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null and b.specificpriceitemid=c_roww.spid;
                    insert into b_billspecificrate (BILLSPECIFICRATEID, SPECIFICPRICEITEMID, TOTALPRICES, BILLID, CURRENTFLOW,  METERDATACURRENTMONTHID)
                    values ((select max(BILLSPECIFICRATEID+1) from b_billspecificrate), c_roww.spid,
                    c_roww.price*c_row.currenttrafficb,
                    maxbillid, c_row.currenttrafficb
                    , c_row.meterdatacurrentmonthid);
                end IF ;
                ---居民用水
             IF   c_roww.bttype = 2 and c_row.mixwatertypeid=c_roww.tid   then
                   --生成基本用水
               get_waterate_jt(c_row.STEPPRICEITEMID, c_row.jieti1,c_row.jieti2,c_row.steponeprice,c_row.steponeprice2,c_row.currenttrafficb,c_row.YEARCYCLESUMFLOW,maxbillid,c_row.METERDATACURRENTMONTHID, c_row.mixwatertypeid) ;
             end IF ;

          end if;


--3：混合用水2，定量  【1】，不走阶梯或阶梯0   【2】，阶梯一  【3】，阶梯二
           if c_row.mixwatertype=2 then
                      --【1】，非混合用水 非否居民用水
             IF   c_roww.bttype = 1 and c_row.usewatertypeid=c_roww.tid    then
                   --生成基本用水
                        DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null and b.specificpriceitemid=c_roww.spid;
                    insert into b_billspecificrate (BILLSPECIFICRATEID, SPECIFICPRICEITEMID, TOTALPRICES, BILLID, CURRENTFLOW,  METERDATACURRENTMONTHID)
                    values ((select max(BILLSPECIFICRATEID+1) from b_billspecificrate), c_roww.spid,
                    c_roww.price*c_row.currenttrafficlz,
                    maxbillid, c_row.currenttrafficlz
                    , c_row.meterdatacurrentmonthid);
                end IF ;
                ---居民用水
             IF   c_roww.bttype = 2 and c_row.usewatertypeid=c_roww.tid   then
                   --生成基本用水
               get_waterate_jt(c_row.STEPPRICEITEMID, c_row.jieti1,c_row.jieti2,c_row.steponeprice,c_row.steponeprice2,c_row.currenttrafficlz,c_row.YEARCYCLESUMFLOW,maxbillid,c_row.METERDATACURRENTMONTHID,c_row.usewatertypeid) ;
             end IF ;


              IF   c_roww.bttype = 1 and c_row.mixwatertypeid=c_roww.tid    then
                   --生成基本用水
                        DELETE FROM B_BILLSPECIFICRATE B WHERE B.METERDATACURRENTMONTHID =c_row.METERDATACURRENTMONTHID and B.METERDATACURRENTMONTHID is not null and b.specificpriceitemid=c_roww.spid;
                    insert into b_billspecificrate (BILLSPECIFICRATEID, SPECIFICPRICEITEMID, TOTALPRICES, BILLID, CURRENTFLOW,  METERDATACURRENTMONTHID)
                    values ((select max(BILLSPECIFICRATEID+1) from b_billspecificrate), c_roww.spid,
                    c_roww.price*c_row.currenttrafficl,
                    maxbillid, c_row.currenttrafficl
                    , c_row.meterdatacurrentmonthid);
                end IF ;
                ---居民用水
             IF   c_roww.bttype = 2 and c_row.mixwatertypeid=c_roww.tid   then
                   --生成基本用水
               get_waterate_jt(c_row.STEPPRICEITEMID, c_row.jieti1,c_row.jieti2,c_row.steponeprice,c_row.steponeprice2,c_row.currenttrafficl,c_row.YEARCYCLESUMFLOW,maxbillid,c_row.METERDATACURRENTMONTHID, c_row.mixwatertypeid) ;
             end IF ;
          end if;

   commit;
        end loop;
      end;
      ----------------------

       --生成帐单
       iswaterate:=0;
       select sum(totalprices) into  iswaterate from b_billspecificrate  where meterdatacurrentmonthid=c_row.METERDATACURRENTMONTHID;
       insert into bill (BILLID, USERINFOID, METERINFOID, METERCODE, LASTMONTHNUMBER, READNUMBER, CURRENTTRAFFIC, READDATE, WATERATE,
                  BILLSTATE, INVOICEPRINTSTATE, BILLYEAR, BILLMONTH, ISRECTIFY,makebllltime, METERDATACURRENTMONTHID)
                 values (maxbillid, c_row.userinfoid, c_row.meterinfoid, c_row.metercode,
                 c_row.lastmonthnumber, c_row.readnumber, c_row.CURRENTTRAFFIC, c_row.readdate,
                 iswaterate,
                  2, 2, c_row.datayear, c_row.datamonth, 0,sysdate,c_row.METERDATACURRENTMONTHID);

     --修改用户开账状态
      UPDATE AM_U_USERINFO SET isaccount=1 WHERE USERINFOID =c_row.userinfoid;
     --修改记录为已开账
      UPDATE MM_M_METERDATACURRENTMONTH SET ismakebill=1 WHERE METERDATACURRENTMONTHID=c_row.METERDATACURRENTMONTHID;
     --账户余额大于0 并且小于当前水费时，将当月余额不足信息添加到历史记录中
     -- if (account > 0 & account < trifficPrice)
       commit;

     insertnum:=nvl(insertnum,0)+1;
     returnresult:=nvl(returnresult,0)+1;
    end loop;

  end;
  end makebills;


/

