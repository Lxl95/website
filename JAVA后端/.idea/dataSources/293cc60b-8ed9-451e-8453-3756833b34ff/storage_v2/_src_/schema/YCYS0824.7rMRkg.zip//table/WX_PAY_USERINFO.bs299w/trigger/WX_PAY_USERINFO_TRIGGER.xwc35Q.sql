create trigger WX_PAY_USERINFO_TRIGGER
    before insert
    on WX_PAY_USERINFO
    for each row
begin
  select wx_pay_userInfo_sq.nextval into :NEW.id from dual;
end;

/

