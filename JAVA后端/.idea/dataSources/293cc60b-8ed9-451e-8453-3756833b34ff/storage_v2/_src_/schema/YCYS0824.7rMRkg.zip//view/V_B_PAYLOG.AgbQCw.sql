create view V_B_PAYLOG as
SELECT u.rosterid,
       u.userinfocode,
       u.username,
       u.useraddress,
       u.usertype,
       u.usewatertypeid,
       p.thisbalance,
       p."PAYLOG",
      (nvl(p.receivablemoney,0)+nvl(p.latefine,0)) as receivablemoney ,
       case
         when p.PAIDMONEY = 0 and (p.latefine + p.receivablemoney +
              NVL(P.rubbishcost, 0) = p.prestoreout) then
          NVL(P.PAIDMONEY, 0)
         else
          NVL(P.PAIDMONEY, 0) + NVL(P.LATEFINE, 0) + NVL(P.rubbishcost, 0) -
          (nvl(p.prestorein, 0) + nvl(p.lastbalance, 0) -
           nvl(p.prestoreout, 0) - nvl(p.thisbalance, 0))
       end PAIDMONEY,
       p."PAIDTYPE",
       p."INVOICEPRINTSTATE",
       p."BILLIDS",
       p."AGENT",
       p."PRESTOREIN",
       p."PRESTOREOUT",
       p."CARDAMOUNT",
       p."COMPORT",
       p."CARDAGENT",
       p."PATCHCARDAMOUNT",
       p."PATCHCURRENTNUM",
       p."PATCHCARDNUM",
       p."CHEQUEAMOUNT",
       p."CHEQUENUM",
       p."CHEQUEAGENT",
       p."PATHCHCARDAGENT",
       p."USERINFOID",
       p."DDATETIME",
       p."PAYREDSTATE",
       b.billid,
       b.meterinfoid,
       b.metercode,
       b.lastmonthnumber,
       b.readnumber,
       b.currenttraffic,
       b.readdate,
       b.waterate,
       b.billstate,
       b.billyear,
       b.billmonth,
       b.isrectify,
       b.billtype,
       p.redtime,
       spa.CADMINNAME,
       spa.cadminemail,
       p.rubbishcost,
       p.latefine,
       u.cardid,
       u.isfavor,
       p.INVOICEDATALISTID
  FROM b_paylog p
  left JOIN bill b
    ON p.paylog = b.paylog
  left join am_u_userinfo u
    on p.userinfoid = u.userinfoid
  left join SM_P_ADMIN spa
    on spa.IADMINID = p.iadminid


/

