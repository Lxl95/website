create procedure StartReadMeter(
adduser in number, --创建人userID
meterInfoidt in number --水表ID 
--Results       out VARCHAR2
)as

ReturnInfoCode  VARCHAR2(2); --返回信息码
yd number := 0; --是否已冻结
maxmetermonthid  number := 0; --月冻结ID最大值
LastMonthID number := 0; --上月冻结ID

begin
  
      select max(METERDATACURRENTMONTHID) into LastMonthID from MM_M_METERDATACURRENTMONTH
       where METERINFOID = meterInfoidt;
 
    select COUNT(*) into yd from MM_M_METERDATACURRENTMONTH
    where METERINFOID = meterInfoidt
    and (to_char(nvl(I_DATA,sysdate), 'yyyy-mm')) = (to_char(sysdate,'yyyy-mm'));

    if(yd=0) then
      select decode(max(to_number(t.METERDATACURRENTMONTHID)),null,0,max(to_number(t.METERDATACURRENTMONTHID)))
      into maxmetermonthid
      from MM_M_METERDATACURRENTMONTH t
      where regexp_like(t.METERDATACURRENTMONTHID, '(^[0-9])');

      insert into MM_M_METERDATACURRENTMONTH
                  (METERDATACURRENTMONTHID,
                  userinfoid, meterinfoid, metercode, lastmonthnumber,readnumber,
                  currenttraffic,readdate,ismakebill ,
                  datayear ,datamonth ,addflow,I_DATA,i_adminid,L_ID)
      select      (maxmetermonthid + 1),
                     (select max(userinfoid) from am_u_userinfo where meterinfoid=meterInfoidt),
                      meterinfoid,metercode,lastnumber,metercurrentreading ,
                     (metercurrentreading+addflow-lastnumber),sysdate ,0 ,
                     to_char(sysdate,'yyyy'),to_char(sysdate,'mm'), 
                     addflow ,sysdate,adduser,LastMonthID
      from MM_M_METERINFO where METERINFOID = meterInfoidt ;

    end if;

     ReturnInfoCode := '1'; --成功
     --Results :=ReturnInfoCode;

    EXCEPTION 
      when others then
        ReturnInfoCode := '2'; --失败
        --Results :=ReturnInfoCode;
        
end StartReadMeter;


/

