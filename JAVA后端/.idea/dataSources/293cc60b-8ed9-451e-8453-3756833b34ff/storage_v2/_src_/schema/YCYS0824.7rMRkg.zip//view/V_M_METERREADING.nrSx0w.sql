create view V_M_METERREADING as
select m.meterdatacurrentmonthid,
       m.readdate,
       amu.ROSTERORDER,
       m.CREADMETERSTATE,
       (case m.CREADMETERSTATE
         when 0 then
          '未抄'
         when 1 then
          '已抄'
       end) as CREADMETERSTATES,
       mmwm.wellid,
       amu.userinfoid,
       sms.siteid,
       sms.sitename,
       amu.cardid,
       amu.userinfocode,
       mmwm.wellname /*表井号*/,
       amr.METERREADERID /*抄表员ID*/,
       smp.cadminname /*抄表员*/,
       amr.rosterid,
       amr.rostername /*测本名称*/,
       amu.username,
       mmmm.SEALNUMBER,
       amu.contect,
       bsb.usewatertypeid /*用水性质ID*/,
       bsb.usewatertypename as USEWATERTYPENAMES /*用水性质*/,
       mmmm.meterinfoid,
       mmmm.metercode,
       m.CREMARK /*抄表备注*/,
       m.ADDFLOW /*追加水量*/,
       m.lastmonthnumber /*上期读数*/,
       m.readnumber /*档期读数*/,
       m.CURRENTTRAFFIC /*当月用水量*/,
       m.datayear /*读取年份*/,
       m.datamonth /*读取月份*/,
       m.ISMAKEBILL as ISACCOUNT /*开账状态*/,
       (case m.ISMAKEBILL
         when 0 then
          '未开账'
         when 1 then
          '已开账'
       end) MAKEBILLSTATE /*开账状态*/,
       cal.metercal /*水表口径*/,
       brand.meterbrandname /*水表名牌*/,
       mmmm.METERTYPE /*水表类型*/,
       (case mmmm.METERTYPE
         when 0 then
          '远传表'
         when 1 then
          '普表'
       end) METERTYPENAME,
       mmmm.METERSTATE /*水表状态*/,
       (case mmmm.METERSTATE
         when 0 then
          '未使用'
         when 1 then
          '正在使用'
       end) METERSTATENAME,
       mmmm.METERUSE /*表用途*/,
       (case mmmm.METERUSE
         when 1 then
          '计费'
         when 2 then
          '考核'
       end) METERUSES,
       mmmm.METERBASENUMBER /*水表起算读数*/,
       amu.useraddress,
       mmmm.meteraddress,
       l.locationareaname /*地区名称*/,
       bsu.communtyname /*小区名称*/,
       bsu.communtycode,
       mmmm.steelnumber,
       ac.custominfocode
  from mm_m_meterdatacurrentmonth m
  left join am_u_userinfo amu
    on m.userinfoid = amu.userinfoid
  left join am_c_custominfo ac
    on ac.custominfoid = amu.custominfoid
  left join sm_s_site sms --站点
    on sms.siteid = amu.siteid
  left join am_r_roster amr --册本
    on amr.rosterid = amu.rosterid
  left join mm_w_userwell mmw
    on mmw.userid = amu.userinfoid
  left join MM_W_METERWELLRELATION mmwm
    on mmwm.wellid = mmw.wellid
  left join sm_p_admin smp
    on smp.iadminid = amr.meterreaderid
  left join bs_b_usewatertype bsb
    on bsb.usewatertypeid = amu.usewatertypeid
  left join mm_m_meterinfo mmmm
    on mmmm.meterinfoid = amu.meterinfoid
  left join mm_m_metercal cal
    on mmmm.metercalid = cal.metercalid
  left join MM_M_METERBRAND brand
    on brand.meterbrandid = mmmm.meterbrandid
  left join SM_P_LOCATIONAREA l
    on amu.locatioareaid = l.locatioareaid
  left join BS_U_COMMUNITY bsu
    on amu.communtyid = bsu.communtyid


/

