create view V_B_ARREARSCALLBILLMANAGE as
select distinct ui.siteid, ui.accountmmoney, ui.userinfocode,ui.userinfoid, ui.username,
                ui.useraddress,ui.userstate,ui.contect,ui.contectperson, bi.sumwate,bi.count,
                bi.sumcurr,m.metercode,case when ui.accountmmoney>bi.sumwate then 0
                                        else bi.sumwate-ui.accountmmoney end as qianfei
  from am_u_userinfo ui
  join (select count(0) as count, sum(b.waterate) sumwate,
               sum(b.currenttraffic) as sumcurr,
               b.userinfoid,
               b.meterinfoid
          from bill b
         where b.billstate = 2
           and b.isrectify = 0
         group by b.userinfoid, b.meterinfoid) bi
    on bi.userinfoid = ui.userinfoid
  left join mm_m_meterinfo m
    on m.meterinfoid = bi.meterinfoid


/

