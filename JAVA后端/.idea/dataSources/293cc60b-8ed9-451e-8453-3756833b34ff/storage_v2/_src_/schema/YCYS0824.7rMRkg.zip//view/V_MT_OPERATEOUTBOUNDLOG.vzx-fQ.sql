create view V_MT_OPERATEOUTBOUNDLOG as
SELECT ib."OPERATELOGID",ib."STUFFMODEID",ib."OPERATETIME",ib."OPERATER",ib."OPERATECODEID",ib."STUFFCOST",ib."ACCOUNTER",
ib."RECEIPTOR",ib.Outboundcount,s.stuffmodename,o.operatecodename,st.stufftypename,s.currentcount,so.storageid,so.storagename,ib.outusername
  from mt_operateoutboundlog ib left join MT_STUFFMODE s on s.stuffmodeid=ib.stuffmodeid

                               left join mt_stufftype st on st.stufftypeid=s.stufftypeid
                                left join MT_OPERATECODE o on o.operatecodeid=st.operatecodeid
                                      left join mt_storage so on so.storageid=ib.storageid


/

