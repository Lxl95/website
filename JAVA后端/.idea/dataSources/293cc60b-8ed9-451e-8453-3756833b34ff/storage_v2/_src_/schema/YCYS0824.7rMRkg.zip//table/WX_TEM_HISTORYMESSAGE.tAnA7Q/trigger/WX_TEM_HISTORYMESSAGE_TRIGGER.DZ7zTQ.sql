create trigger WX_TEM_HISTORYMESSAGE_TRIGGER
    before insert
    on WX_TEM_HISTORYMESSAGE
    for each row
begin
  select wx_tem_historyMessage_sq.nextval into :NEW.id from dual;
end;

/

