create view V_B_TOTALANDBRANCHUSER as
SELECT
t.totaluserid,t.branchuserid,
( select u.username from am_u_userinfo u where u.userinfoid=t.totaluserid) as totalusername,
( select u.username from am_u_userinfo u where u.userinfoid=t.branchuserid) as branchusername
  FROM bs_b_totalandbranchuser t


/

