create trigger WX_PAY_USER_TRIGGER
    before insert
    on WX_PAY_USER
    for each row
begin
  select wx_pay_user_sq.nextval into :NEW.id from dual;
end;

/

