create view V_W_WORKFLOW_TEMP_TRANSFER as
select  "ID","OPENID","INSTANCEID","RESERVATIONCODE","STATE","INSERTTIME","USERINFOCODE","USERNAME","USERADDRESS","CONTECT","EMAIL","IDENTITYTYPE","IDENTITYVALUE","UNITNAME","OPERADDRESS","INVOICEBANKNAME","REASON","REMARKS","FILES","UPDATETIME","WORKFLOWSTATE" from (
  select t.*,case when w.id is null then t.state else 100 end as workflowstate
    from WORKFLOW_TEMP_TRANSFER t
    left join (select * from WORKFLOWTASK order by sort desc) w on w.instanceid=t.instanceid
) a where a.workflowstate != 100  and a.STATE != -2


/

