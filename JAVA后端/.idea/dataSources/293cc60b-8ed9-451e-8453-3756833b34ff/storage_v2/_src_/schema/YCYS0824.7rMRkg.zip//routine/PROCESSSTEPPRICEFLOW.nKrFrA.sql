create PROCEDURE processsteppriceflow (
      out_msg       OUT      VARCHAR2,
      out_result    OUT      INTEGER                                --返回信息
   )
   AS
      n_id              NUMBER;
      n_flow          NUMBER;
      --dt_readdatelast      DATE;
      --dt_mindate        DATE;
      n_price     NUMBER;


      n_steponeflow   number;
      n_steponeflow2   number;
      n_steponeflow3   number;

      n_steponeprice   number;
      n_steponeprice2   number;
      n_steponeprice3   number;

      v_namen     VARCHAR (12);
      --v_createempcode   VARCHAR (32);

      TYPE refcur IS REF CURSOR;

      cur_rec           refcur;
      cur_recde           refcur;


begin
  out_msg := '处理多条数据！';
      out_result := 0;

      OPEN cur_rec FOR
         --select distinct(billid) as billid from b_billspecificrate where addtime >to_date('2017-11-20','yyyy-mm-dd') ; --30948 and itemtype =1
         --11月份的
         --10月份的
         --12月份开张
         select distinct(billid) as billid from b_billspecificrate where addtime >to_date('2017-12-30','yyyy-mm-dd') and addtime <to_date('2018-01-01','yyyy-mm-dd');
      FETCH cur_rec
       INTO n_id;--, dt_enddate, n_holidaytype, v_deptorgroup,
            --v_createempcode;

      WHILE (cur_rec%FOUND)
      LOOP
         IF (n_id <> 0)
         THEN
         n_steponeflow2:= 0;  --水量
           n_steponeprice2:= 0; --价格
           n_steponeflow3:= 0;  --水量
           n_steponeprice3:= 0; --价格
          n_steponeflow:= 0;  --水量
           n_steponeprice:= 0;
           --初始全部为0
         OPEN cur_recde FOR
         select currentflow,itemprice,substr(specificpriceitemname,-3) as isname  from b_billspecificrate where billid = n_id and itemtype =1 order by itemprice;  --新 只处理基本水费
 --除去他之外的最大值
         FETCH cur_recde INTO n_flow,n_price,v_namen;

         WHILE (cur_recde%FOUND)
         LOOP
          --写三个变量 --需要判断
          if trim(v_namen)='阶梯1' then
          n_steponeflow2:= n_flow;  --水量
           n_steponeprice2:= n_price; --价格
          elsif trim(v_namen)='阶梯2' then
           n_steponeflow3:= n_flow;  --水量
           n_steponeprice3:= n_price; --价格
          else
          n_steponeflow:= n_flow;  --水量
           n_steponeprice:= n_price; --价格
          end if;

         FETCH cur_recde
          INTO n_flow, n_price,v_namen;
        END LOOP;
         update b_billspecificrate set STEPONEFLOW=n_steponeflow,STEPONEPRICE=n_steponeprice,
     STEPONEFLOW2=n_steponeflow2, STEPONEPRICE2=n_steponeprice2, STEPONEFLOW3=n_steponeflow3,STEPONEPRICE3=n_steponeprice3 where billid = n_id and itemtype =1;--多条一起更新


      CLOSE cur_recde;

         END IF;

         FETCH cur_rec
          INTO n_id;
      END LOOP;

      CLOSE cur_rec;
     out_msg := '处理补充数据成功！';
      COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_result := 6;
         out_msg := TO_CHAR (SQLCODE) || '||||' || SQLERRM;

end processsteppriceflow;


/

