create FUNCTION MixWaterCurrentFlowFunc(METERINFOID    in number,
                                                   CurrentTraffic in number)
  return number is
  denizenWaterCurrentTraffic number := -1;
  --混合用水计算参数
  isMixWaterUser    number := 0;
  thismixwatertypeid    number := 0;
  thisusewatertypeid    number := 0;
  mixwatertype      number := 0;
  mixwaterrate      number(5, 2) := 0;
  mixwaterflow      number := 0;
  newMeterInfoId    number := METERINFOID;--当前水表信息
  newCurrentTraffic number := CurrentTraffic;--用水量
  mixUueWaterType   number := 0;
  mainUseWaterType  number := 0;
  mainWaterFlow     number :=0;
begin

  --查询是否为混合用水
  select count(0)
    into isMixWaterUser
    from AM_U_USERINFO t
   where t.mixwatertype != 0  --(不是无)
     and t.meterinfoid = newMeterInfoId;  --多表无法判断
--是混合用水才判断，后期直接改为超过一条才判断
  if (isMixWaterUser > 0) then

    --查询混合用水类别
    select t.mixwatertypeid,
           t.usewatertypeid,
           t.mixwatertype,
           t.mixwaterrate,
           t.mixwaterflow
      into thismixwatertypeid,  --混合用水类型id
           thisusewatertypeid, --主用水类型id
           mixwatertype,--混合用水类型  默认<1
           mixwaterrate,--混合用水比例
           mixwaterflow--混合用水定量
      from AM_U_USERINFO t
     where t.meterinfoid = newMeterInfoId
       and rownum = 1;


    --主用水性质类型
    select  decode(t.usewatertype,null,0,t.usewatertype)
      into mainUseWaterType
      from BS_B_USEWATERTYPE t
     where t.usewatertypeid = thisusewatertypeid and rownum=1;

    --混合用水性质类型
    select decode(t.usewatertype,null,0,t.usewatertype)
      into mixUueWaterType
      from BS_B_USEWATERTYPE t
     where t.usewatertypeid = thismixwatertypeid and rownum=1;

    -- 定比
    if (mixwatertype = 1) then
      if (mixwaterrate > 1) then
        mixwaterrate := 1;  --比例
      end if;
      --混合用水是居民用水
      if (mixUueWaterType = 2) then

        denizenWaterCurrentTraffic := trunc(mixwaterrate *
                                            newCurrentTraffic);--四舍五入
      end if;
      --主用水性质是居民用水
      if (mainUseWaterType = 2) then
        denizenWaterCurrentTraffic := trunc((1 - mixwaterrate) *
                                            newCurrentTraffic);
      end if;
    else  -- 定量
     --当月用水大于混合用水定量
     if (newCurrentTraffic >= mixwaterflow) then
          mainWaterFlow := newCurrentTraffic - mixwaterflow;
     else--当月用水小于混合用水定量  主用水性质水量为当月水量 混合用水为0
          mainWaterFlow := newCurrentTraffic;
          mixwaterflow := 0;
     end if;

      --混合用水是居民用水
      if (mixUueWaterType = 2) then
        denizenWaterCurrentTraffic := mixwaterflow;
      end if;
      --主用水性质是居民用水
      if (mainUseWaterType = 2) then
       denizenWaterCurrentTraffic := mainWaterFlow;

        end if;
      end if;
    end if;
  return(denizenWaterCurrentTraffic);
end MixWaterCurrentFlowFunc;

/

