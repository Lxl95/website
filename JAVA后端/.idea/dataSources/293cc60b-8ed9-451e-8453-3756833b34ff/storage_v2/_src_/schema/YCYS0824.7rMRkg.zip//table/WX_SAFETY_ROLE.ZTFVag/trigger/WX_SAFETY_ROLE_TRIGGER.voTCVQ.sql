create trigger WX_SAFETY_ROLE_TRIGGER
    before insert
    on WX_SAFETY_ROLE
    for each row
begin
  select wx_safety_role_sq.nextval into :NEW.id from dual;
end;

/

