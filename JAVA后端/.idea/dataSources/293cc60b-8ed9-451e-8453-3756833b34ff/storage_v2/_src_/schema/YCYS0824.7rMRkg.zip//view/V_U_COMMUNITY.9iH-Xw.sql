create view V_U_COMMUNITY as
SELECT    c."COMMUNTYID",c."COMMUNTYCODE",c."COMMUNTYNAME",c."LOCATIOAREAID",c."ROSTERID",c."SITEID",c."COMMUNTYADDRESS",c."PIPECODE",c."MODULECODE",c."COMMUNTYLONGITUDE",c."COMMUNTYLATITUDE",c."COMMUNTYGISINFO",c."TOPNUMBER",c."COMNUMBER",c."BUILDINGNUMBER",c."UNITNUMBER",c."ADMINTEL",c."ADMINNAME",c."ZBXQZHS",c."ECGSSBCJ",c."ECGSSBXH",c."PUMPADDRESS",l.locationareaname,s.sitename,r.rostername,t.userCount

 FROM         BS_U_COMMUNITY c  left JOIN SM_P_LOCATIONAREA l ON c.locatioareaid=l.locatioareaid
                               left JOIN SM_S_SITE s ON  c.siteid=s.siteid
                               left JOIN AM_R_ROSTER r on c.rosterid=r.rosterid
                               left join (select communtyid,count(0) as userCount from am_u_userinfo group by am_u_userinfo.communtyid) t on t.communtyid = c.communtyid


/

