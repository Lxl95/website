create view V_U_USERACCOUNTADVANCELOG as
SELECT
u."USERLOGID",u."USERINFOID",u."MODIFYTYPE",u."MODIFYTIME",u."OPERATORID",u."REMARK",a.cadminname,ui.userinfocode,ui.username,ui.useraddress,ui.usercreatetime,ui.cardid
 FROM         am_u_useraccountadvancelog u INNER JOIN
              sm_p_admin a ON u.operatorid=a.iadminid
             join am_u_userinfo ui on u.userinfoid=ui.userinfoid


/

