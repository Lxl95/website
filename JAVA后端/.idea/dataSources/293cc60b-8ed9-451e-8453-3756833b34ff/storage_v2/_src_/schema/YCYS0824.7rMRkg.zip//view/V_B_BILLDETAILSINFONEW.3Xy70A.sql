create view V_B_BILLDETAILSINFONEW as
select sum(b1.totalprices) as BASEPRICE,b.billid,am.userinfocode,am.username,am.metercode,b.waterate,b.lastmonthnumber,b.readnumber,b.currenttraffic,b.readdate,b.billstate,b.invoiceprintstate,b.billyear,b.billmonth,b.isrectify,am.useraddress,am.contect,am.contectperson,am.siteid,am.rosterid,(b.waterate-sum(b1.totalprices)) as STEPWATERPRICE from bill b , b_billspecificrate b1,am_u_userinfo am where b.billid=b1.billid and  b1.itemprice>0  and b.userinfoid=am.userinfoid group by b.billid,am.userinfocode,am.metercode,b.waterate,b.lastmonthnumber,b.readnumber,b.currenttraffic,b.readdate,b.billstate,b.invoiceprintstate,b.billyear,b.billmonth,am.useraddress,am.contect,am.contectperson,am.username,b.isrectify,am.siteid,am.rosterid


/

