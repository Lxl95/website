create PROCEDURE REMOTEMETERINSERTNEW (VMeterCode      in varchar2, --水表编号  铅封号
                                              NMeterCurrentReading in number, --水表当前读数
                                              Results             out number,
                                              Err_Mes             out varchar2) --返回状态

 AS

  --add by li.shuangli 增加损耗量计算和水资源量计算

  lastnum           number := 0; --上期读数;
  yd                number := 0; --是否存在当月月冻结数据
  isExistMonth      number := 0; --是否存在月冻结数据
  --weizhimin add
  --out_return varchar2(1000);
  int_rosterid        int; --全局变量
  errorException exception; --申明异常
  --errorCode number; --异常编码
  errorMsg  varchar2(1000);
  -----------------------------
  NewMeterCode           VARCHAR2(50); --:= MeterCode;(实际的水表编号)
  NewMeterinfoid         number;
  NewMeterCurrentReading number; --:= MeterCurrentReading;  ---不需要这样赋值
  Isupload              number; --是否开过账;
  userid                 number; --用户编号;
  --havemeter            integer; --用水性质
  int_METERAPPMONTHDATAID NUMBER;
BEGIN
  ---首先查找水表编号 和水表ID
  select m.metercode,m.meterinfoid into NewMeterCode,NewMeterinfoid  from Mm_m_Meterinfo m where m.sealnumber = VMeterCode;
  --select count(METERINFOID) into havemeter  from Mm_m_Meterinfo where meterinfoid = MeterCode;
  ---------------------------
  --首先查询是否存在月冻结记录 当月月冻结数据(当月是否存在数据)
  select COUNT(METERINFOID)
    into isExistMonth
    from mm_m_meterycbmonthdata
   where meterinfoid = NewMeterinfoid and to_char(readmeterdate,'YYYY-MM')=to_char(sysdate,'YYYY-MM');
  if (isExistMonth = 0) then  ----当月临时表不存在需要插入
    --不存在临时月冻结记录，从水表表中获取上期读数
    --select m.metercurrentreading
    --  into lastnum
    --  from mm_m_meterinfo m
    -- where m.metercode = NewMeterCode;
    --从月冻结中获取实际的记录
    select COUNT(METERINFOID)
    into yd
    from mm_m_meterdatacurrentmonth
     where meterinfoid = NewMeterinfoid and to_char(READDATE,'YYYY-MM')=to_char(sysdate,'YYYY-MM');
     if (yd>0) then ---有记录  ----一月多抄的会有问题
     select mm.USERINFOID,
           max(mm.LASTMONTHNUMBER)
      into userid, lastnum
      from mm_m_meterdatacurrentmonth mm where mm.meterinfoid = NewMeterinfoid
     and to_char(mm.READDATE,'YYYY-MM')=to_char(sysdate,'YYYY-MM') group by mm.USERINFOID;
     ---插入水表记录
     select am.rosterid into int_rosterid from am_u_userinfo am where am.userinfoid = userid;
     insert into mm_m_meterycbmonthdata(METERAPPMONTHDATAID,USERINFOID,METERINFOID,LASTMONTHNUMBER,
     READNUMBER,CURRENTTRAFFIC,DATAYEAR,DATAMONTH,ISUPLOAD,READMETERDATE,ROSTERID,ADDFLOW)
     values ((select max(METERAPPMONTHDATAID)+1 from mm_m_meterycbmonthdata),userid,NewMeterinfoid,
     lastnum,NMeterCurrentReading,(NMeterCurrentReading-lastnum),
     to_number(to_char(sysdate,'YYYY')),to_number(to_char(sysdate,'MM')),
     1,to_date(to_char(sysdate,'YYYY-MM-DD'),'YYYY-MM-DD'),int_rosterid,0);
     Results := 1;
   else
     Results := 3;
     Err_Mes:='水表编号'||NewMeterCode||'水表记录本月未进行开始抄表，无法进行处理。';
   end if;
  else   ----临时表已经有数据
    --1查询该表号上期读数
    select METERAPPMONTHDATAID,LASTMONTHNUMBER,READNUMBER,ISUPLOAD
    into int_METERAPPMONTHDATAID,lastnum,NewMeterCurrentReading,Isupload
    from mm_m_meterycbmonthdata
    where meterinfoid = NewMeterinfoid and to_char(readmeterdate,'YYYY-MM')=to_char(sysdate,'YYYY-MM');
   if Isupload=2 then
     Results := 3;
     Err_Mes:='水表编号'||NewMeterCode||'本月记录已经上传过，无需进行处理。';
   else
     if(NMeterCurrentReading<>NewMeterCurrentReading) then
     update mm_m_meterycbmonthdata m
       set m.READNUMBER = NMeterCurrentReading,
           m.CURRENTTRAFFIC= NMeterCurrentReading-lastnum
     where m.METERAPPMONTHDATAID = int_METERAPPMONTHDATAID; ---修改一下此条记录
     Results := 1;
     end if;
   end if;

    ---看是否需要更新一下
    /*
    select --COUNT(METERINFOID),
           max(MM_M_METERDATACURRENTMONTH.Lastmonthnumber)
      into yd, lastnum
      from MM_M_METERDATACURRENTMONTH
     where MeterCode = NewMeterCode
       and (to_char(READDATE, 'yyyy')) =
           (select to_char(sysdate, 'yyyy') as nowYear from dual)
       and (to_char(READDATE, 'mm')) =
           (select to_char(sysdate, 'mm') as nowYear from dual);
    if (yd = 0) then
      --2不存在当月月冻结，取最大日期的当期读数就是当前月份的上期读数
      select readnumber
        into lastnum
        from (select decode(mo.readnumber, null, 0, mo.readnumber) as readnumber,
                     row_number() over(partition by mo.meterinfoid order by mo.readdate desc) rn

                from MM_M_METERDATACURRENTMONTH mo
               where mo.metercode = NewMeterCode) mm
       where mm.rn = 1;
    end if;
    */
  end if;
  -------------------------
  /*select u.isaccount, u.userinfoid, u.usewatertypeid
    INTO IsAccount, userid, watertypeid
    from am_u_userinfo u
   where u.metercode = NewMeterCode;
   */

  /*
  if (IsAccount is null or IsAccount = 0) then
    --修改用水量
    update MM_M_METERINFO m
       set m.METERCURRENTREADING = NewMeterCurrentReading,
           m.lastnumber          = lastnum
     where m.metercode = NewMeterCode;
    Results := 1;
  else
    --已经开账用户不能修改
    Results := 2;
  end if;
  */
    insert into CEPRO(metercode,NUM,state,ERRORC) values (VMeterCode,NMeterCurrentReading,Results,errorMsg);
    COMMIT;
EXCEPTION

  /*WHEN NO_DATA_FOUND THEN
       errorMsg:= SUBSTR(SQLERRM, 1, 200);
       Results := 3;
  WHEN TOO_MANY_ROWS THEN
       errorMsg   := SUBSTR(SQLERRM, 1, 200);
       Results := 3;
  */
  WHEN OTHERS THEN
       Results := 3;
       errorMsg   := SUBSTR(SQLERRM, 1, 200);
       Err_Mes :=errorMsg;
       ROLLBACK;
       insert into CEPRO(metercode,NUM,state,ERRORC) values (VMeterCode,NMeterCurrentReading,Results,errorMsg);


end;


/

