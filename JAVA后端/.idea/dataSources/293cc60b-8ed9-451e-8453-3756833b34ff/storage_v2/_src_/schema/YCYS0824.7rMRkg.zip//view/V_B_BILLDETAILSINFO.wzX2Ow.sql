create view V_B_BILLDETAILSINFO as
select bi.billid,
       bi.waterate,
       bo.othertoatalPrice,
       ba.basePrice,
       br.limitwaterprice,
       br.mixwaterbaseprice,
       br.mixwaterotherprice,
       br.stepwaterprice,
       bi.lastmonthnumber,
       bi.readnumber,
       bi.currenttraffic,
       bi.readdate,
       bi.invoiceprintstate,
       CASE bi.Billstate
         WHEN 1 THEN
          '已缴费'
         WHEN 2 THEN
          '未缴费'
         ELSE
          ''
       END AS BillstateName,
       CASE bi.INVOICEPRINTSTATE
         WHEN 1 THEN
          '已打印'
         WHEN 2 THEN
          '未打印'
         WHEN 3 THEN
          '延迟打印'
         ELSE
          ''
       END AS INVOICEPRINTSTATEName,
       CASE bi.userstate
         WHEN 0 THEN
          '未立户'
         WHEN 1 THEN
          '正常'
         WHEN 2 THEN
          '销户'
         WHEN 3 THEN
          '停用'
         WHEN 4 THEN
          '欠费'
         WHEN 5 THEN
          '拆表'
         WHEN 6 THEN
          '过户中'
         WHEN 7 THEN
          '换表中'
         WHEN 8 THEN
          '停水'
         ELSE
          ''
       END AS UserStateName,
       CASE bi.usertype
         WHEN 1 THEN
          '户外'
         WHEN 2 THEN
          '户内'
         WHEN 3 THEN
          '高层户内'
         WHEN 4 THEN
          '高层管廊'
         ELSE
          ''
       END AS UserTypeName,
       bi.billstate,
       bi.billyear,
       bi.billmonth,
       bi.ISRECTIFY,
       bi."USERINFOID",
       bi."USERINFOCODE",
       bi."SITEID",
       bi."ROSTERID",
       bi."ROSTERORDER",
       bi."ISMULTIMETERUSER",
       bi."METERCODE",
       bi."USERADDRESS",
       bi."USERTYPE",
       bi."USERNAME",
       bi."IDENTITYTYPE",
       bi."IDENTITYVALUE",
       bi."CONTECT",
       bi."CONTECTPERSON",
       bi."EMAIL",
       bi."USEWATERTYPEID",
       bi."USERSTATE",
       bi."FAMILYCOUNT",
       bi."PERSONCOUNT",
       bi."WELLWATER",
       bi."SECWATERSUPPLY",
       bi."ELCBILL",
       bi."URGEWAY",
       bi."STEPPRICEITEMID",
       bi."LIMITUSEPRICEITEMID",
       bi."READMETERSTATE",
       bi."USERCREATETIME",
       bi."USERACTIVATIME",
       bi."USERCANCELLATIONTIME",
       bi."PROJECTCODE",
       bi."WATERSUPPLYCONTRACTCODE",
       bi."SUPPLYSIGNTIME",
       bi."STOPSUPPLYTIME",
       bi."BUILDUNIT",
       bi."BUILDER",
       bi."CHECKER",
       bi."CHECKERID",
       nvl(bi."ACCOUNTMMONEY", 0) as ACCOUNTMMONEY,
       bi."PAYWAY",
       bi."BANKACCOUNT",
       bi."BANKNAME",
       bi."REMARK",
       bi."METERINFOID",
       bi."COMMUNTYID",
       bi."CONTACTADDRESS",
       bi."CALLPHONE",
       bi."ELECTRONICBILL",
       bi."CUSTOMINFOID",
       bi."REGISTERCODE",
       bi."INSTALLTIME",
       bi."SUPPLYWATERAREA",
       bi."MULTIPLYWATERIN",
       bi."LIMITUSEFLOW",
       bi."USEWATERCATEGORY",
       bi."BUSINESSTYPEID",
       bi."COMPANYUSER",
       bi."METERINSTALLWAY",
       bi."METERADDRESS",
       bi."PIPECODE",
       bi."MODULECODE",
       bi."METERLONGITUDE",
       bi."METERLATITUDE",
       bi."METERWALLADDRESS",
       bi."COLLECTIONBANK",
       bi."DEPOSITBANK",
       bi."VAT",
       bi."MIXWATERTYPEID",
       bi."MIXWATERTYPE",
       bi."MIXWATERRATE",
       bi."MIXWATERFLOW",
       bi."ISUSED",
       --bi."USERGISINFO",
       bi."IMAGEURL",
       bi."LOCATIOAREAID",
       bi.usewatertypename,
       bi.customname,
       bi.cadminname,
       r.rostername,
       s.sitename

  from V_B_BILLINFO bi
  left join

 (select t. billid, t.totalprices as basePrice
    from B_BILLSPECIFICRATE t
    left join BS_B_SPECIFICPRICEITEM spi
      on spi.specificpriceitemid = t.specificpriceitemid
   where spi.itemtype = 0) ba
    on bi.billid = ba.billid
  left join

 (select sum(bs.totalprices) othertoatalPrice, bs.billid
    from (select *
            from B_BILLSPECIFICRATE t
            left join BS_B_SPECIFICPRICEITEM spi
              on spi.specificpriceitemid = t.specificpriceitemid
           where spi.itemtype <> 0) bs
   group by bs.billid) bo
    on bi.billid = bo.billid

  left join B_BILLADDRATE br
    on br.billid = bi.billid
  left join AM_R_ROSTER r
    on r.rosterid = bi.ROSTERID
  left join SM_S_SITE s
    on s.siteid = bi.SITEID


/

