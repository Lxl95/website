create PROCEDURE processupdatamonthinsert (
      out_msg       OUT      VARCHAR2,
      out_result    OUT      INTEGER                                --返回信息
   )
   AS
      n_id              NUMBER;
      m_meterid          NUMBER;
      dt_readdatelast      DATE;
      dt_mindate        DATE;
      n_months     NUMBER;
      needmonths   number;
      v_deptorgroup     VARCHAR (12);
      v_createempcode   VARCHAR (32);

      TYPE refcur IS REF CURSOR;

      cur_rec           refcur;


begin
  out_msg := '处理多条数据！';
      out_result := 0;

      OPEN cur_rec FOR
         select a.meterdatacurrentmonthid,a.notmonths,a.meterinfoid,a.readdate from mm_m_meterdatacurrentmonth a inner join
(select max(readdate) maxreaddate,meterinfoid from mm_m_meterdatacurrentmonth group by meterinfoid) b on a.readdate = b.maxreaddate
and a.meterinfoid = b.meterinfoid; --46906

      FETCH cur_rec
       INTO n_id, n_months,m_meterid,dt_readdatelast;--, dt_enddate, n_holidaytype, v_deptorgroup,
            --v_createempcode;

      WHILE (cur_rec%FOUND)
      LOOP
         IF (n_id <> 0)
         THEN
         select max(readdate) into dt_mindate from  mm_m_meterdatacurrentmonth where meterinfoid= m_meterid and meterdatacurrentmonthid<> n_id; --除去他之外的最大值
                                                         --记录
         if(dt_mindate is not null) then
         select MONTHS_BETWEEN(to_date(to_char(dt_readdatelast,'yyyy-mm')||'-01','yyyy-mm-dd'),to_date(to_char(dt_mindate,'yyyy-mm')||'-01','yyyy-mm-dd')) into needmonths from dual;
         --if(needmonths<>n_months) then
         insert into mm_m_meterdatacurrentmonth_t (meterdatacurrentmonthid,meterinfoid,readdate,lastreaddate,notmonths,sumnotmonths)
         values (n_id,m_meterid,dt_readdatelast,dt_mindate,n_months,needmonths);

         --end if;
         out_result:=out_result+1;
         else
         insert into mm_m_meterdatacurrentmonth_t (meterdatacurrentmonthid,meterinfoid,readdate,lastreaddate,notmonths,sumnotmonths)
         values (n_id,m_meterid,dt_readdatelast,dt_mindate,n_months,1);

         end if;

         --and dpid=prmdpid
         END IF;

         FETCH cur_rec
          INTO n_id, n_months,m_meterid,dt_readdatelast;
      END LOOP;

      CLOSE cur_rec;
     out_msg := '处理补充数据成功！';
      COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_result := 6;
         out_msg := TO_CHAR (SQLCODE) || '||||' || SQLERRM;

end processupdatamonthInsert;


/

