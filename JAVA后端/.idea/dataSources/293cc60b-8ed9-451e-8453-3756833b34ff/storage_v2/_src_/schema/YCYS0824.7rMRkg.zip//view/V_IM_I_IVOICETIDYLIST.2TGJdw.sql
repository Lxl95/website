create view V_IM_I_IVOICETIDYLIST as
SELECT i.invoicelimitmoney,i.invoicestate,il.invoicedatalistid,il.invoicetype,il.invoiceversioncode,il.invoicenumber,il.invoicestate as useinvoicestate
,il.invoiceuserid,il.MAKEOUTINVOICEMONEY,il.remark
  ,(select a.cadminname from sm_p_admin a where a.iadminid=il.MAKEOUTINVOICEPERSONID) as MAKEOUTINVOICEPERSON

   ,il.invoicerevertfiletime,il.MAKEOUTINVOICEPERSONID
      FROM IM_I_IVOICEDATALIST il join IM_I_IVOICESPECIFIC i on il.invoicetype=i.invoicetype and il.invoiceversioncode=i.invoiceversioncode


/

