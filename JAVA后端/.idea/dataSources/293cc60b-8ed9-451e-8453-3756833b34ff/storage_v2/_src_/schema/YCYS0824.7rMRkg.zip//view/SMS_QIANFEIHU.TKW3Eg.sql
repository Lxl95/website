create view SMS_QIANFEIHU as
select am.userinfoid,am.userinfocode,am.username,am.useraddress,am.contect,am.siteid,am.rosterid
,to_char(add_months(trunc(sysdate),-1),'yyyy') billyear,to_char(add_months(trunc(sysdate),-1),'mm') billmonth
,am.accountmmoney,b.waterate-am.accountmmoney waterate,b.waterate-am.accountmmoney qian
  from (select * from (select userinfoid,sum(waterate+LATEFEE) waterate ,count(0) num from bill
  where billstate=2 and isrectify=0  group by userinfoid  ) c where num>1 ) b
  left join am_u_userinfo am
    on b.userinfoid = am.userinfoid
where   (am.payway is  null or payway not in (7,8)) and length(am.contect)=11
 and b.waterate-am.accountmmoney>0


/

