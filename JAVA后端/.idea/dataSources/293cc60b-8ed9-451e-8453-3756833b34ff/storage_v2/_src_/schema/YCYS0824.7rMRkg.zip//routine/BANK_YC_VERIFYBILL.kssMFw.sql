create procedure Bank_YC_VerifyBill(VerifyBillDate in VARCHAR2, --对账日期
                                               BankCode       in VARCHAR2, --银行代号

                                               InRecordCount in VARCHAR2, --记录数
                                               SumMoney      in VARCHAR2, --对账金额
                                               Results       out VARCHAR2,
                                               outdata       out VARCHAR2) AS
  ReturnInfoCode VARCHAR2(3); --返回信息码

  OweReusts   sys_refcursor;
  RecordCount VARCHAR2(8); --记录数
  PayMoney    VARCHAR2(12); --实收总金额

begin

  select count(0),  sum(mm)
    INTO RecordCount, PayMoney
    from (
select lpad(COUNT(0), 8, 0),
                 lpad(SUM(bp.PAIDMONEY + bp.latefine) * 100, 8, 0) mm
            FROM B_VERIFYBILL T
            LEFT JOIN B_PAYLOG bp
              on T.paylogid = bp.paylog
           WHERE T.Bankccode = '02'
             AND to_char(bp.ddatetime, 'yyyyMMdd') = VerifyBillDate
             AND bp.PAYREDSTATE = 0 group by bp.userinfoid);
  -- AND ROWNUM = 1;

  IF (RecordCount = 0) THEN
    ReturnInfoCode := '021'; --无记录
  ELSE
    ReturnInfoCode := '000';
  END IF;
  IF (ReturnInfoCode = '000' and RecordCount = InRecordCount and
     PayMoney = SumMoney) THEN
    Results := ReturnInfoCode;
    outdata := '成功';
  ELSif (RecordCount != InRecordCount) then
    Results := '018';
    outdata := '总数失败';
  ELSe
    Results := '019';
    outdata := '金额失败';
  END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;

end Bank_YC_VerifyBill;


/

