create procedure ReadMeter(
meterid in varchar2,
curnum in number,
addflowN in number,
LASTNUM in number,
UpdateTIME in date
)as


begin
  
  /*update MM_M_METERINFO set METERCURRENTREADING=curnum ,
  ADDFLOW=addflowN,LASTNUMBER=LASTNUM ,CHANGETIME=UpdateTIME 
  where METERINFOID=meterid;*/
  update MM_M_METERINFO set METERCURRENTREADING=171
  where METERINFOID=660143;
  /*insert into MM_M_METERDATAHIS(METERDATACURRENTHISID,METERINFOID,METERCODE,
  READNUMBER,READDATE,DATAYEAR,DATAMONTH,ADDFLOW,LASTNUMBER) 
  select SEQ_ON_METERDATAHIS.NEXTVAL,meterInfoid,meterCode,
  METERCURRENTREADING,(select to_date(sysdate, 'yyyy-mm-dd hh24:mi:ss') from dual),
  (select to_char(sysdate, 'yyyy') as nowYear from dual),(select to_char(sysdate, 'mm') as nowYear from dual),
  addflow,LastNumber from MM_M_METERINFO where meterinfoid=meterInfoid;
  update MM_M_METERDATACURRENTMONTH set ReadNumber=METERCURRENTREADING,ADDFLOW=ADDFLOW,
  CURRENTTRAFFIC=(METERCURRENTREADING+LastNumber-ADDFLOW) where*/
      

    EXCEPTION 
      when others then
        rollback;
        
end ReadMeter;


/

