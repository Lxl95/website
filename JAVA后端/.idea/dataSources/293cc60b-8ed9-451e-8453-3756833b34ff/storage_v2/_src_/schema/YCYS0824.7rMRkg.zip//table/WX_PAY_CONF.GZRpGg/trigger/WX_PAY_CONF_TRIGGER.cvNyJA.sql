create trigger WX_PAY_CONF_TRIGGER
    before insert
    on WX_PAY_CONF
    for each row
begin
  select wx_pay_conf_sq.nextval into :NEW.PAYID from dual;
end;

/

