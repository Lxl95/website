create view V_U_USERCHANGEMETERLOG as
select u."USERCHANGEMETERLOGID",u."USERINFOID",u."USERNAME",u."USERINFOCODE",u."IDENTITYVALUE",u."EMAIL",u."METERADDRESS",u."NEWUSERNAME",u."NEWUSERINFOCODE",u."NEWIDENTITYVALUE",u."NEWEMAIL",u."TRANSFERTYPE",u."REMARK",ui.cardid
    from am_u_userchangemeterlog u
         join AM_U_USERINFO ui on u.userinfoid =ui.userinfoid


/

