create PROCEDURE processhcdetailmixreal (
      out_msg       OUT      VARCHAR2,
      out_result    OUT      INTEGER                                --返回信息
   )
   AS
      n_userinfoid              NUMBER;
      n_usewaterid          NUMBER;
      n_billid     NUMBER;
      n_pricecal   number;
      v_itemids     VARCHAR (100);
      n_needprice  NUMBER;
      d_makedate  date;
      n_currenttraffic NUMBER;
      n_allprice number;
      v_metercode     VARCHAR (100);
      n_nullbillid number;
      v_usewatertypename VARCHAR (100);

      n_itemprice number;
      n_itemid number;
      n_itemtype number;
      v_itemname VARCHAR (100);


      n_newallprice number;
      n_priceadd number;
      i number;
      m number;

      ismixmum number; --再用一个游标
      v_mixitemids     VARCHAR (100);
      n_mixuserwatertype number;
      n_mixtyperate number; --比率
      n_mixwatertype number; --定量定比   2 定量  1 定比
      n_mixwaterflow number; --定量值
      n_useorder number; --顺序
      n_mixfirstcurrrent number;
      n_mixsecondcurrrent number;
      mixok boolean;
      n_jisuanall number;
      cursorall number;
      TYPE refcur IS REF CURSOR;

      cur_rec           refcur;
      cur_recdetail           refcur;

      cur_recwater           refcur;


begin
  out_msg := '处理多条数据！';
      out_result := 0;
      OPEN cur_rec FOR
select map1.numberc,gg.needprice*ff.currenttraffic as newallprice,bs.usewatertypename,bs.specificpriceitemids,gg.needprice, am.usewatertypeid,ff.waterate/ff.currenttraffic as price1,ff.billid,ff.currenttraffic,ff.makebllltime,ff.waterate, ff.userinfoid,ff.metercode,ff.nbillid from
    (
    select  bi.*,bb.billid as nbillid  from bill bi
 left join
 (select distinct(b.billid) as billid from  b_billspecificrate b group by b.billid) bb on bb.billid=bi.billid
 where  bi.isrectify = 0  and bi.currenttraffic>0 and bi.waterate>0 ) ff
 left join am_u_userinfo am on ff.userinfoid = am.userinfoid
 left join ( select sum(price) as needprice,usewatertypeid
 from (
  select item.price,item.specificpriceitemid,all1.usewatertypeid,all1.usewatertypename,all1.aaan from bs_b_specificpriceitem item left join (
  select a.usewatertypeid,a.usewatertypename, REGEXP_SUBSTR(a.specificpriceitemids,'[^,]+',1,L) as aaan from bs_b_usewatertype a,
(select level L from dual connect by level <=1000) where L(+)<= length(a.specificpriceitemids)- LENGTH(replace(a.specificpriceitemids,','))+1
) all1 on item.specificpriceitemid = all1.aaan) kk group by kk.usewatertypeid) gg on am.usewatertypeid = gg.usewatertypeid
 left join bs_b_usewatertype bs on am.usewatertypeid = bs.usewatertypeid
  left join  (select userinfoid, count(*) as numberc  from bs_b_user_watertype_map group by userinfoid) map1 on ff.userinfoid=map1.userinfoid
  where ff.nbillid is null
  and gg.needprice <> ff.waterate/ff.currenttraffic
   and  map1.numberc=2 ;--map1.numberc>1;  仅处理 2个的   and ff.billid =27306  OK and ff.billid =18728

      FETCH cur_rec
       INTO ismixmum,n_newallprice,v_usewatertypename,v_itemids,n_needprice,n_usewaterid,n_pricecal, n_billid,n_currenttraffic,d_makedate,n_allprice,n_userinfoid,v_metercode,n_nullbillid;-- n_id 原先都是0
      WHILE (cur_rec%FOUND)
      LOOP
         IF (n_nullbillid is null)
         THEN
         --update b_billspecificrate set specificpriceitemid = n_needid where billspecificrateid =n_billsid ;
         if (v_itemids is not null)
         then
          --先判断一下
          mixok:=true;
          m:=0;
          n_mixfirstcurrrent:=0;
          out_msg := '全部是混合用水！';
          n_priceadd := n_newallprice - n_allprice;--全部的差额 最后一个直接扣掉

          n_jisuanall :=0;--//实际金额值
            --第二个循环
            open cur_recwater for
            select bs.specificpriceitemids,mp.userwatertype,mp.typerate,mp.mixwatertype,mp.mixwaterflow,mp.useorder from bs_b_user_watertype_map mp left join bs_b_usewatertype bs
on mp.userwatertype = bs.usewatertypeid where mp.userinfoid =n_userinfoid order by useorder; --几个性质
            FETCH cur_recwater
             INTO v_mixitemids,n_mixuserwatertype,n_mixtyperate,n_mixwatertype,n_mixwaterflow,n_useorder;-- n_id 原先都是0
             WHILE (cur_recwater%FOUND)
             LOOP
               begin
               m:=m+1;


                    --水量是在外面计算的
                    if(m=1)
                    then
                      if(n_mixwatertype=2) then
                        if(n_mixwaterflow>=n_currenttraffic) then
                            n_mixfirstcurrrent:=n_currenttraffic;--实际水量
                        else
                            n_mixfirstcurrrent:=n_mixwaterflow;
                        end if;

                      else
                        n_mixfirstcurrrent:=floor(n_mixtyperate*n_currenttraffic/100); --取整(比例的算错了)
                      end if;
                      n_mixsecondcurrrent:=n_mixfirstcurrrent;
                    else
                     n_mixsecondcurrrent:=n_currenttraffic-n_mixfirstcurrrent;
                    end if;


                    select count(*) into cursorall from bs_b_specificpriceitem where specificpriceitemid in (select regexp_substr(v_mixitemids||',','[^,]+',1,rownum) as needid
        from dual connect by rownum<=length(regexp_replace(v_mixitemids||',', '[^,]', null)));  --总数
                    i:=0;
                    OPEN cur_recdetail FOR
                    select price,specificpriceitemid,printname,itemtype from bs_b_specificpriceitem where specificpriceitemid in (select regexp_substr(v_mixitemids||',','[^,]+',1,rownum) as needid
        from dual connect by rownum<=length(regexp_replace(v_mixitemids||',', '[^,]', null)));
                     FETCH cur_recdetail
                     INTO n_itemprice,n_itemid,v_itemname,n_itemtype;
                     WHILE (cur_recdetail%FOUND)
                     LOOP
                       begin
                         i:=i+1;
                         n_jisuanall:=n_jisuanall+(n_itemprice*n_mixsecondcurrrent);--总价
                         if(cursorall=i and m=2)--最后一个 需要处理一下 混合的最后一个
                         then
                           --if(((n_itemprice*n_mixsecondcurrrent)-n_priceadd)<0)  --不能出现负数
                           if(n_jisuanall<>n_allprice and (n_jisuanall-n_allprice)<0)
                           then
                             --delete from b_billspecificrate where billid = n_billid;--全部删掉
                             --insert into billhcnullmixreal (billid,isok) values (n_billid,-1); --成功的  统计一下负数
                             --mixok:=false;
                             if (n_mixsecondcurrrent>0) then
                             insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,(n_itemprice*n_mixsecondcurrrent)-(n_jisuanall-n_allprice),n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                               end if;
                             else
                             if(n_jisuanall=n_allprice)  then
                               if (n_mixsecondcurrrent>0) then
                               insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,n_itemprice*n_mixsecondcurrrent,n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                               end if;
                             else
                               if (n_mixsecondcurrrent>0) then
                               insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,(n_itemprice*n_mixsecondcurrrent)-(n_jisuanall-n_allprice),n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                               end if;
                            end if;
                        end if;
                        else
                           if(m=1 and cursorall=i and n_mixsecondcurrrent =n_currenttraffic)  then ---需要处理
                           if (n_mixsecondcurrrent>0) then
                           if((n_jisuanall-n_allprice)>0) then

                               insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,(n_itemprice*n_mixsecondcurrrent)-(n_jisuanall-n_allprice),n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                            else
                               insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,(n_itemprice*n_mixsecondcurrrent)-(n_allprice-n_jisuanall),n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                            end if;

                           end if;

                           else

                           if (n_mixsecondcurrrent>0) then
                          insert into b_billspecificrate (BILLSPECIFICRATEID,SPECIFICPRICEITEMID,TOTALPRICES,BILLID,CURRENTFLOW,USEWATERTYPEID,ADDTIME,
                     SPECIFICPRICEITEMNAME,USEWATERTYPENAME,
                        WATERRATE,ITEMPRICE,ITEMTYPE)
                        values ((select nvl(max(BILLSPECIFICRATEID),0)+1 from b_billspecificrate),n_itemid,n_itemprice*n_mixsecondcurrrent,n_billid,n_mixsecondcurrrent,n_usewaterid,d_makedate,
                        v_itemname,v_usewatertypename,0,n_itemprice,n_itemtype);
                           end if;
                           end if;
                        end if;
                     end;
                     FETCH cur_recdetail
                     INTO n_itemprice,n_itemid,v_itemname,n_itemtype;-- n_id 原先都是0
                     END LOOP;
                     CLOSE cur_recdetail;--关闭游标

            --end if;
              end;
            FETCH cur_recwater
            INTO v_mixitemids,n_mixuserwatertype,n_mixtyperate,n_mixwatertype,n_mixwaterflow,n_useorder;-- n_id 原先都是0
            END LOOP;
            CLOSE cur_recwater;
            if(m=2 and mixok=true) then  --实际成功才插入
            insert into billhcnullmixreal (billid,isok) values (n_billid,1); --成功的
            end if;

         else
            insert into billhcnullmixreal (billid,isok) values (n_billid,0);--失败的记录
         end if;

         ELSE
          insert into billhcnullmixreal (billid,isok) values (n_billid,0);--失败的记录
         END IF;

         FETCH cur_rec
          INTO ismixmum,n_newallprice,v_usewatertypename,v_itemids,n_needprice,n_usewaterid,n_pricecal, n_billid,n_currenttraffic,d_makedate,n_allprice,n_userinfoid,v_metercode,n_nullbillid;-- n_id 原先都是0
      END LOOP;

      CLOSE cur_rec;
     out_msg := '处理补充数据成功！';
      COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_result := 6;
         out_msg := TO_CHAR (SQLCODE) || '||||' || SQLERRM;

end processhcdetailmixreal;


/

