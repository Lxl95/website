create view V_B_WAITREMINDERBILLINFO as
select distinct W.NOTE, w.receivetime,w.status,w.completedtime1,u.userinfoid,u.usertype,
u.userinfocode,u.username,u.useraddress,l.locationareaname,c.communtyname,
(select count(distinct(BILLMONTH)) from REMINDER re1 where USERINFOID=re.userinfoid ) as Arrearscount ,tem.billyear,tem.billmonth,tem.waterate

   from (select w.receivetime,w.completedtime1,w.groupid,w.title,w.status,w.note,w.instanceid
                          from WORKFLOWTASK w

                         where w.flowid =
                               'f34d4e54-93d2-4b75-b148-8a39589975a6'
                           and w.completedtime1 is null and w.note is null
                           group by w.groupid, w.receivetime,w.completedtime1,w.title,w.status,w.note,w.instanceid) w join TEMPTEST_USERREMINDER tem on w.instanceid=tem.id
                       join REMINDER re on tem.userinfoid=re.userinfoid
                       join AM_U_USERINFO u on tem.userinfoid=u.userinfoid
                       left join sm_p_locationarea l on u.locatioareaid=l.locatioareaid
                       left join bs_u_community c on u.communtyid=c.communtyid


/

