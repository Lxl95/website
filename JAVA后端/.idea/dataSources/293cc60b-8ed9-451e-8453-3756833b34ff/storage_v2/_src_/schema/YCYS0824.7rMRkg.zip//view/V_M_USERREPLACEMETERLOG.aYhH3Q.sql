create view V_M_USERREPLACEMETERLOG as
SELECT u.userinfocode,
       u.username,
       u.useraddress,
       u.usertype,
       nmi.metercode           as newmetercode,
       nmi.meterbasenumber     as newmeterbasenumber,
       nmi.metercurrentreading as newmetercurrentreading,
       omi.metercode           as oldmetercode,
       omi.meterbasenumber     as oldmeterbasenumber,
       ml.oldmeterreadnumber,
       ml.meterlogid,
       ml.modifytype,
       ml.modifytime,
       ml.operatorid,
       a.cadminname,
       ml.remark,
       u.cardid,ml.NEWADDFLOW,ml.huanqiandushu
  FROM MM_M_METERLOG ml
  join MM_M_METERINFO omi
    on ml.oldmeterinfoid = omi.meterinfoid
  join MM_M_METERINFO nmi
    on ml.oldmeterinfoid = nmi.meterinfoid
  join AM_U_USERINFO u
    on ml.userinfoid = u.userinfoid
  join sm_p_admin a
    on ml.operatorid = a.iadminid


/

