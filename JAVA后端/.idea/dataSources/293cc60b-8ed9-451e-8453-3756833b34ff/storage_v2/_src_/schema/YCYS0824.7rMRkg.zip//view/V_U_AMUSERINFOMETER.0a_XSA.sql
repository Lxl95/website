create view V_U_AMUSERINFOMETER as
SELECT u."USERINFOID",
       u."USERINFOCODE",
       u."SITEID",
       u."ROSTERID",
       u."LOCATIOAREAID",
       l.locationareaname,
       u."COMMUNTYID",
       co.communtyname,
       u."ROSTERORDER",
       u."ISMULTIMETERUSER",u.opentel,u.operaddress,u.invoicebankname,u.invoicebankaccount,
       u."USERADDRESS",
       u."USERTYPE",
       u."USERNAME",
       u."IDENTITYTYPE",
       u."IDENTITYVALUE",
       u."CONTECT",
       u."CONTECTPERSON",
       u."EMAIL",
       u."USEWATERTYPEID",
       u."USERSTATE",
       u."FAMILYCOUNT",
       u."PERSONCOUNT",
       u."WELLWATER",
       u."SECWATERSUPPLY",
       u."ELCBILL",
       u."URGEWAY",
       u."STEPPRICEITEMID",
       u."LIMITUSEPRICEITEMID",
       u."READMETERSTATE",
       u."USERCREATETIME",
       u."USERACTIVATIME",
       u."USERCANCELLATIONTIME",
       u."PROJECTCODE",
       u."WATERSUPPLYCONTRACTCODE",
       u."SUPPLYSIGNTIME",
       u."STOPSUPPLYTIME",
       u."BUILDUNIT",
       u."BUILDER",
       u."CHECKER",
       u."CHECKERID",
       u."ACCOUNTMMONEY",
       u."PAYWAY",
       u."BANKACCOUNT",
       u."BANKNAME",
       u."REMARK",
       mi."METERINFOID",
       u."CONTACTADDRESS",
       u."CALLPHONE",
       u."ELECTRONICBILL",
       u."REGISTERCODE",
       u."INSTALLTIME",
       u."WELLADD",
       u."SUPPLYWATERAREA",
       u."MULTIPLYWATERIN",
       u."LIMITUSEFLOW",
       u."USEWATERCATEGORY",
       u."BUSINESSTYPEID",
       u."COMPANYUSER",
       mi."METERINSTALLWAY",
       mi."METERADDRESS",
       mi."PIPECODE",
       mi."MODULECODE",
       mi."METERLONGITUDE",
       mi."METERLATITUDE",
       mi."METERWALLADDRESS",
       u."COLLECTIONBANK",
       u."DEPOSITBANK",
       u."VAT",
       u."MIXWATERTYPEID",
       u."MIXWATERTYPE",
       U.MIXWATERRATE * 100 AS mixwaterrate,
       u."MIXWATERFLOW",
       u.buildingid,
       u.floor,
       u.USERUNIT,
       u.printtypeid,
       u.SEALNUMBER,
       mi.meterbrandid,
       mi.metertype,
       mi.meteruse,
       mi.meterbasenumber,
       mi.metercurrentreading,
       mi.meterstate,
       mi.metercode,
       mi.metercalid,
       mi.lastnumber,
       mi.nchan,
       mi.ycmeteraddress,
       mc.metercal,
       c.custominfoid,
       c.custominfocode,
       c.customname,
       c.customaddress,
       c.identitytypetype,
       c.identitytypvalue,
       c.creditleval,
       c.businesslicencepath,
       c.taxregistrationlicencepath,
       c.industrytype,
       rt.rostercode,
       rt.rostername,
       s.sitecode,
       s.sitename,
       mb.meterbrandname,
       u.usergisinfo,
       U.IMAGEURL,
       uw.usewatertypename,
       u.id,
       uw.usewatertype,
       U.ISENJOYPRIVILEGE,
       mi.addflow,
       uw1.usewatertype as mixusewatertype,
       ul.latefinid,
       ul.latefinename,
       u.cardid,
       a.iadminid,
       a.cadminname,u.openid,u.unitname,mi.steelnumber,
       u.yhallowance,
       u.yhstarttime,
       u.yhendtime
  FROM AM_U_USERINFO u
  left join MM_M_METERINFO mi
    on u.meterinfoid = mi.meterinfoid
  left join mm_m_metercal mc
    on mi.metercalid = mc.metercalid
  left join mm_m_meterbrand mb
    on mi.meterbrandid = mb.meterbrandid
  left join am_c_custominfo c
    on u.custominfoid = c.custominfoid
  left join sm_p_locationarea l
    on u.locatioareaid = l.locatioareaid
  left join bs_u_community co
    on u.COMMUNTYID = co.communtyid
  left join am_r_roster rt
    on u.rosterid = rt.rosterid
  left join sm_p_admin a
    on a.iadminid = rt.meterreaderid
  left join sm_s_site s
    on u.siteid = s.siteid
  left join bs_b_usewatertype uw
    on u.usewatertypeid = uw.usewatertypeid
  left join bs_b_usewatertype uw1
    on u.mixwatertypeid = uw1.usewatertypeid
  left join AM_U_USERLATEFINE ul
    on u.latefinid = ul.latefinid


/

