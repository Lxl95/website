create view V_U_USERSTATECOUNT as
select ROSTERCODE, sum(decode(u.userstate,'未立户',count,null)) as Weilihu,
       sum(decode(u.userstate,'正常',count,null)) as Zhengchang,
       sum(decode(u.userstate,'销户',count,null)) as Xiaohu,
       sum(decode(u.userstate,'停用',count,null)) as Tingyong,
       sum(decode(u.userstate,'欠费',count,null)) as Qianfei,
       sum(decode(u.userstate,'拆表',count,null)) as Chaibiao

from (
select ROSTERCODE , case userstate when 0 then '未立户'
                      when 1 then '正常'
                      when 2 then '销户'
                      when 3 then '停用'
                      when 4 then '欠费'
                      when 5 then '拆表'
                        end as userstate

 ,count(0) as count from V_U_USERMETERINFO
 group by userstate,ROSTERCODE
) u
group by ROSTERCODE


/

