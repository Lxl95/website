create view V_B_BILLINFO as
SELECT distinct
'' as currentAccountMoney,
      ui.openid,
       ro.meterreaderid,
       b.billid,
       b.lastmonthnumber,
       b.readnumber,
       b.currenttraffic,
       b.readdate,
       b.readdate as readdatemonth,
       b.waterate,

  plog.invoiceprintstate,plog.elinvoiceprintstate,
              b.advanceprintoperaterid,
       CASE b.Billstate
          WHEN 1 THEN '已缴费'
          WHEN 2 THEN '未缴费'
          ELSE ''
       END
          AS BillstateName,
       CASE b.INVOICEPRINTSTATE
          WHEN 1 THEN '已打印'
          WHEN 2 THEN '未打印'
          WHEN 3 THEN '延迟打印'
          ELSE ''
       END
          AS INVOICEPRINTSTATEName,
       CASE ui.userstate
          WHEN 0 THEN '未立户'
          WHEN 1 THEN '正常'
          WHEN 2 THEN '销户'
          WHEN 3 THEN '停用'
          WHEN 4 THEN '欠费'
          WHEN 5 THEN '拆表'
          WHEN 6 THEN '过户中'
          WHEN 7 THEN '换表中'
          WHEN 8 THEN '停水'
          ELSE ''
       END
          AS UserStateName,
       CASE ui.usertype
          WHEN 1 THEN '户外'
          WHEN 2 THEN '户内'
          WHEN 3 THEN '高层户内'
          WHEN 4 THEN '高层管廊'
          ELSE ''
       END
          AS UserTypeName,

       b.billstate,
       b.billyear,
       b.billmonth,
       b.makebllltime,
       b.ISRECTIFY,
      nvl( b.LATEFEE,0) LateFineMoney,
      nvl( b.REDUCTIONMONEY,0) REDUCTIONMONEY,
       b.lef ,b.latedays,
       ui.USERINFOID,
       b.USERINFOCODE,
       ui.SITEID,
       ui.ROSTERID,
       ui.ROSTERORDER,
       ui.ISMULTIMETERUSER,
       mm.METERCODE,
       ui.USERADDRESS,
       ui.USERTYPE,
       b.USERNAME,
       b.billtype,
       b.REDUCTIONREMARK,
       ui.abcname,
       ui.IDENTITYTYPE,
       ui.IDENTITYVALUE,
       ui.CONTECT,
       ui.CONTECTPERSON,
       ui.EMAIL,
       mm.meterwatertypeid as USEWATERTYPEID,
       ui.USERSTATE,
       ui.FAMILYCOUNT,
       ui.PERSONCOUNT,
       ui.WELLWATER,
       ui.SECWATERSUPPLY,
       ui.ELCBILL,
       ui.URGEWAY,
       ui.STEPPRICEITEMID,
       ui.LIMITUSEPRICEITEMID,
       ui.READMETERSTATE,
       ui.USERCREATETIME,
       ui.USERACTIVATIME,
       ui.USERCANCELLATIONTIME,
       ui.PROJECTCODE,
       ui.WATERSUPPLYCONTRACTCODE,
       ui.SUPPLYSIGNTIME,
       ui.STOPSUPPLYTIME,
       ui.BUILDUNIT,
       ui.BUILDER,
       ui.CHECKER,
       ui.CHECKERID,
       ui.CARDID,
       nvl(ui.ACCOUNTMMONEY,0) as ACCOUNTMMONEY,
       ui.PAYWAY,
       ui.BANKACCOUNT,
       ui.BANKNAME,
       ui.REMARK,
       mm.METERINFOID,
       ui.COMMUNTYID,
       ui.CONTACTADDRESS,
       ui.CALLPHONE,
       ui.ELECTRONICBILL,
       ui.CUSTOMINFOID,
       nvl(cu.custommonty,0) as custommonty,
       ui.REGISTERCODE,
       ui.INSTALLTIME,
       ui.SUPPLYWATERAREA,
       ui.MULTIPLYWATERIN,
       ui.LIMITUSEFLOW,
       ui.USEWATERCATEGORY,
       ui.BUSINESSTYPEID,
       ui.COMPANYUSER,
       ui.METERINSTALLWAY,
       ui.METERADDRESS,
       ui.PIPECODE,
       ui.MODULECODE,
       ui.METERLONGITUDE,
       ui.METERLATITUDE,
       ui.METERWALLADDRESS,
       ui.COLLECTIONBANK,
       ui.DEPOSITBANK,
       ui.VAT,
       ui.MIXWATERTYPEID,
       ui.MIXWATERTYPE,
       ui.MIXWATERRATE,
       ui.MIXWATERFLOW,
       ui.ISUSED,
       --ui.USERGISINFO,
       ui.IMAGEURL,
       ui.LOCATIOAREAID,
       ui.printtypeid,
       ui.sealnumber,
       --mmw.userwellid meterwallcode,
       mmwm.wellcode meterwallcode,
       cu.custominfocode,
       wt.usewatertypename,
       wt.specificpriceitemids,
       cm.customname,
       ad.cadminname,ro.rostercode,ro.rostername,
       s.sitename,
       l.locationareaname,co.communtyname,co.communtycode,
       mdcm.ismakebill,
       mdcm.yearcyclesumflow
       ,mdcm.meterdatacurrentmonthid
       ,wt.usewatertype,plog.payredstate,plog.lastbalance,plog.thisbalance,plog.PAIDMONEY,plog.receivablemoney+decode(plog.Rubbishcost,null,0,plog.Rubbishcost)+decode(plog.latefine,null,0,plog.latefine) as receivablemoney,plog.CARDAMOUNT,plog.CHEQUEAMOUNT,plog.PATCHCARDAMOUNT
       ,decode(plog.PAIDMONEY,null,0,plog.PAIDMONEY)+decode(plog.CARDAMOUNT,null,0,plog.CARDAMOUNT)+decode(plog.CHEQUEAMOUNT,null,0,plog.CHEQUEAMOUNT)+decode(plog.PATCHCARDAMOUNT,null,0,plog.PATCHCARDAMOUNT)+decode(plog.Rubbishcost,null,0,plog.Rubbishcost)+decode(plog.latefine,null,0,plog.latefine) as sumPaid,plog.paidtype,plog.ddatetime
       ,  CASE ur.rubtype
          WHEN 1 THEN TOTALRUBCOST
          WHEN 2 THEN SINGLERUBCOST*ui.personcount

          ELSE 0
       END
          AS rubbishcost
        ,ul.latefinid,ul.latefinename,ul.startcalculatetype,ul.periodunit,ul.startcalculateday,ul.period,ul.payway as latefinepayway,ul.latefinerate,ul.latefinerflow,ul.toplimit,ul.ISEXTENDNEXTMONTH
        ,plog.latefine,plog.rubbishcost as rucost,plog.paylog,mdcm.NotMonths,case when ui.isenjoyprivilege is null then 0 else ui.isenjoyprivilege end as isenjoyprivilege, sm.cadminname as operatorname,plog.invoicedatalistid,upl.jmnumber,nvl(ur.totalrubcost,0) totalrubcost,decode(b.waterate,null,0,b.waterate)+decode(plog.rubbishcost,null,0,plog.rubbishcost)-decode(plog.LASTBALANCE,null,0,plog.LASTBALANCE) as yingshou
 ,b.currenttraffic+nvl(mdcm.yhlossaddflow,0)+nvl(mdcm.lossaddflow,0)  as currnumber,nvl(mdcm.yhlossaddflow,0) as yhlossaddflow,nvl(ui.yhallowance,0) as yhallowance,nvl(ui.lossaddflow,0) as sylossaddflow,nvl(mdcm.lossaddflow,0) lossaddflow,ui.USERURGEPAYremark
 ,b.currenttraffic-(b.readnumber-b.lastmonthnumber) as addflow,ml.huanqiandushu,ml.oldmeterreadnumber,b.LATEFEE
 FROM bill b
        left join mm_m_meterinfo mm on b.meterinfoid=mm.meterinfoid
       LEFT JOIN am_u_userinfo ui ON mm.userinfocode = ui.userinfocode
       left join am_c_custominfo cu on ui.custominfoid=cu.custominfoid
       LEFT JOIN bs_b_usewatertype wt
          ON ui.usewatertypeid = wt.usewatertypeid
       LEFT JOIN am_c_custominfo cm ON ui.custominfoid = cm.custominfoid
       LEFT JOIN am_r_roster ro ON ro.rosterid = ui.rosterid
      left join sm_s_site s on uI.siteid=s.siteid
       LEFT JOIN sm_p_admin ad ON ad.iadminid = ro.meterreaderid
       left join sm_p_locationarea l on ui.locatioareaid=l.locatioareaid
       left join bs_u_community co on ui.Communtyid=co.communtyid
       left join mm_m_meterdatacurrentmonth mdcm on mdcm.meterdatacurrentmonthid=b.meterdatacurrentmonthid--mdcm.readdate = b.readdate
       left join mm_m_meterlog ml on ml.meterlogid=mm.meterlogid
       left join b_paylog plog on b.paylog = plog.paylog
       left join am_u_userrubbishinfo ur on b.userinfoid=ur.userinfoid
       left join am_u_userlatefine ul on ui.latefinid=ul.latefinid
        LEFT JOIN sm_p_admin sm ON sm.iadminid = plog.iadminid
         left join am_u_userprivilege upl on upl.isenjoyprivilege=ui.isenjoyprivilege
         left join mm_w_userwell mmw on mmw.userid=ui.userinfoid
         left join mm_w_meterwellrelation mmwm on mmwm.id=mmw.wellid


/

