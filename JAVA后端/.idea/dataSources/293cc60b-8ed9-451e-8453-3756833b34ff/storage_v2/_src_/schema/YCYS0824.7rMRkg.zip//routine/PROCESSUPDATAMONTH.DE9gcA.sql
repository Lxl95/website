create PROCEDURE processupdatamonth (
      prmdpid       IN       NUMBER,                              --企业注册id
      out_msg       OUT      VARCHAR2,
      out_result    OUT      INTEGER                                --返回信息
   )
   AS
      n_id              NUMBER;
      m_meterid          NUMBER;
      dt_readdatelast      DATE;
      dt_mindate        DATE;
      n_months     NUMBER;
      needmonths   number;
      v_deptorgroup     VARCHAR (12);
      v_createempcode   VARCHAR (32);

      TYPE refcur IS REF CURSOR;

      cur_rec           refcur;


begin
  out_msg := '处理多条数据！';
      out_result := 0;
      OPEN cur_rec FOR
         select meterdatacurrentmonthid,NOTMONTHS,meterinfoid,readdate from mm_m_meterdatacurrentmonth where datayear =2017 and datamonth =10 and meterinfoid in (select ff.meterinfoid from
(select max(readdate) as timen,meterinfoid, to_char(max(readdate),'mm') as months from mm_m_meterdatacurrentmonth where meterinfoid in
(select distinct(meterinfoid) from mm_m_meterdatacurrentmonth where datayear =2017 and datamonth =10)
and meterdatacurrentmonthid not in (select distinct(a.meterdatacurrentmonthid) from mm_m_meterdatacurrentmonth a where datayear =2017 and datamonth =10
) group by meterinfoid) ff where ff.timen<=to_date('2017-09-01','yyyy-mm-dd'));

      FETCH cur_rec
       INTO n_id, n_months,m_meterid,dt_readdatelast;--, dt_enddate, n_holidaytype, v_deptorgroup,
            --v_createempcode;

      WHILE (cur_rec%FOUND)
      LOOP
         IF (n_id <> 0)
         THEN
         select max(readdate) into dt_mindate from  mm_m_meterdatacurrentmonth where meterinfoid= m_meterid and meterdatacurrentmonthid<> n_id; --除去他之外的最大值
                                                         --记录
         if(dt_mindate is not null) then
         select MONTHS_BETWEEN(to_date(to_char(dt_readdatelast,'yyyy-mm')||'-01','yyyy-mm-dd'),to_date(to_char(dt_mindate,'yyyy-mm')||'-01','yyyy-mm-dd')) into needmonths from dual;
         update mm_m_meterdatacurrentmonth set NOTMONTHS=needmonths where meterdatacurrentmonthid =n_id;
         out_result:=out_result+1;
         end if;

         --and dpid=prmdpid
         END IF;

         FETCH cur_rec
          INTO n_id, n_months,m_meterid,dt_readdatelast;
      END LOOP;

      CLOSE cur_rec;
     out_msg := '处理补充数据成功！';
      COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_result := 6;
         out_msg := TO_CHAR (SQLCODE) || '||||' || SQLERRM;

end processupdatamonth;


/

