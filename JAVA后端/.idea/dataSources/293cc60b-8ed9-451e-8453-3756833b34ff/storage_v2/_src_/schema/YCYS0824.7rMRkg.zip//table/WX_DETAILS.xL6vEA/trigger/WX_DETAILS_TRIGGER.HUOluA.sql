create trigger WX_DETAILS_TRIGGER
    before insert
    on WX_DETAILS
    for each row
begin
  select  WX_DETAILS_sequence.nextval into :NEW.ID from dual;
end;

/

