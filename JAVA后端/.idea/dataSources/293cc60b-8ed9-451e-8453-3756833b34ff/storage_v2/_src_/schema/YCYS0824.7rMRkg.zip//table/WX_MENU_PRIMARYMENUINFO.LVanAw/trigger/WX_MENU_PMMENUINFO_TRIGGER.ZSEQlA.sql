create trigger WX_MENU_PMMENUINFO_TRIGGER
    before insert
    on WX_MENU_PRIMARYMENUINFO
    for each row
begin
  select wx_menu_primaryMenuInfo_sq.nextval into :NEW.id from dual;
end;

/

