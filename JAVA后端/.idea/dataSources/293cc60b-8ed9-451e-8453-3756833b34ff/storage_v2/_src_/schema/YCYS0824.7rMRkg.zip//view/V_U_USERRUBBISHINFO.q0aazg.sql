create view V_U_USERRUBBISHINFO as
SELECT ur."USERINFOID",ur."TOTALRUBCOST",ur."SINGLERUBCOST",ur."RUBTYPE",ur."USERRUBBISHID",u.userinfocode,u.username
 FROM AM_U_USERRUBBISHINFO ur left join am_u_userinfo u on ur.userinfoid=u.userinfoid


/

