create trigger WX_NEWS_COLUMN_TRIGGER
    before insert
    on WX_NEWS_COLUMN
    for each row
begin
  select wx_news_column_sq.nextval into :NEW.id from dual;
end;

/

