create procedure Bank_YC_GetRateAndOwe(USERCODE in VARCHAR2,
                                                   Results   out NVarchar2,
                                                   outdata    out NVarchar2) AS
  ReturnInfoLength     VARCHAR2(6) :='000201'; --????
  TradeCode            VARCHAR2(2) :='01'; --???
  BankCode           VARCHAR2(2) := '02'; --??????  ???? ??????NY
  ReturnInfoCode     VARCHAR2(3); --???
  USERINFOCODE       VARCHAR2(100) := USERCODE;--????
  USERNAME           VARCHAR2(80);--????
  USERADDRESS        VARCHAR2(80);--????
  TotalOwe          VARCHAR2(8); --???? ??:?
  ACCOUNTMMONEY1      NUMBER(8, 2); --???? ??:?
   ACCOUNTMMONEY      NUMBER(8, 2); --???? ??:?
  EndCode             VARCHAR2(2) :='@@';--????
  userid         VARCHAR2(10); --??id
  OweCount              NUMBER;

begin

  select
         replace(RPAD(decode(T.USERNAME,null,' ', T.USERNAME),80),' ',' '),
         replace(RPAD(decode(T.USERADDRESS,null,' ', T.USERADDRESS),80),' ',' '),
         T.ACCOUNTMMONEY,
         decode(T.ACCOUNTMMONEY*100, null, ' ', T.ACCOUNTMMONEY*100),
         T.USERINFOID

    INTO USERNAME,
         USERADDRESS,
         ACCOUNTMMONEY,
         ACCOUNTMMONEY1,
         userid
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = USERCODE
     AND ROWNUM = 1;


  IF (userid IS NOT NULL) THEN


    IF (ACCOUNTMMONEY is null) THEN
      ACCOUNTMMONEY := 0; --?????0
      end if;
    SELECT COUNT(0) countNum,
     --(SUM(B.WATERATE)+sum(b.latefee)-sum(b.REDUCTIONMONEY) ) * 100 sumMoney
     --(SUM(B.WATERATE)+sum(b.latefee)-sum(b.REDUCTIONMONEY) - ACCOUNTMMONEY) * 100 sumMoney
       nvl((SUM(B.WATERATE)+sum(b.latefee)-sum(b.REDUCTIONMONEY) ) * 100,0) sumMoney
      INTO OweCount, TotalOwe
      from BILL B
     WHERE B.USERINFOID = userid
       AND B.BILLSTATE = 2
       AND B.ISRECTIFY = 0;
    -- GROUP BY B.USERINFOID;

    IF (OweCount = 0 OR TotalOwe <= 0) THEN
      ReturnInfoCode := '000'; --无欠费
    ELSE

          ReturnInfoCode := '000';
      end if;
 else
    ReturnInfoCode := '005';--不存在此用户
  END IF;
  IF (ReturnInfoCode = '000' ) THEN
     Results := ReturnInfoCode;
     outdata := ReturnInfoLength || TradeCode || BankCode ||ReturnInfoCode || REPLACE(RPAD(USERINFOCODE, 10), ' ', ' ') ||
               USERNAME || USERADDRESS ||
               lpad(TotalOwe, 8,'0') ||
               lpad(ACCOUNTMMONEY1, 8,'0') ||
                EndCode;
   ELSE
    Results := ReturnInfoCode;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --??????
    Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --??
    Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '002'; --??
    Results        := ReturnInfoCode;

end Bank_YC_GetRateAndOwe;


/

