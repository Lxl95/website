create view V_U_CHAOBIAO as
select mm.metercode as ONLYH,mm.metercurrentreading as LASTCOUNTS,0 as COUNTS, 1 as CBFLAG ,mm.nchan as LINENO, nvl(mm.NRYID,0) as NRYID,mm.ycmeteraddress as NBADDR
,nvl(cun.communtyname,0) as FANGH ,0 as BENH  ,0 as NBHAO,0 as YHXZ ,am.username as HNAME,am.contect as HPHONE,am.useraddress as HADDR,'' as CBTIME, 0 as YL,0 as FY,0 as DJ
 from am_u_userinfo am left join mm_m_meterinfo mm on am.meterinfoid=mm.meterinfoid
 left join bs_u_community cun on am.communtyid=cun.communtyid
  where mm.nchan is not null and mm.nchan>0 and mm.ycmeteraddress is not null


/

