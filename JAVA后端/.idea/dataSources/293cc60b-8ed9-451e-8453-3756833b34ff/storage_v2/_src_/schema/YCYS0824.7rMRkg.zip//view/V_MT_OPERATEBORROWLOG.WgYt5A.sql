create view V_MT_OPERATEBORROWLOG as
SELECT ib."OPERATELOGID",ib."STUFFMODEID",ib."OPERATIONTYPEID",ib."OPERATETIME",ib."OPERATER",ib."OPERATECODEID",ib."BORROWPEOPLE",
ib."BORROWCOUNT",ib."RETURNPEOPLE",ib."RETURNCOUNT",ib."ISRETURN",ib."BRROWTIME",ib."PLANRETURNTIME",ib."RETURNTIME",ib."PURPOSE",
ib."REMARK",s.stuffmodename,o.operatecodename,st.stufftypename,s.currentcount,so.storageid,so.storagename,st.stufftypeid
  from MT_OPERATEBORROWRETURNLOG ib left join MT_STUFFMODE s on s.stuffmodeid=ib.stuffmodeid
                                left join mt_stufftype st on st.stufftypeid=s.stufftypeid
                                left join MT_OPERATECODE o on o.operatecodeid=st.operatecodeid
                                left join mt_storage so on so.storageid=ib.storageid


/

