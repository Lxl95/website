create procedure AutoOrder(t_rosterid in number) AS

  --类型定义
  i number(10, 0) := 1;
  cursor c_job is
    select am.userinfoid, am.rosterorder
      from am_u_userinfo am
     where am.rosterid = t_rosterid
     order by am.userinfocode;

  c_row c_job%rowtype;
begin
  for c_row in c_job loop

    update am_u_userinfo am
       set am.rosterorder = i
     where am.userinfoid = c_row.userinfoid;
    i := i + 1;
  end loop;
end;


/

