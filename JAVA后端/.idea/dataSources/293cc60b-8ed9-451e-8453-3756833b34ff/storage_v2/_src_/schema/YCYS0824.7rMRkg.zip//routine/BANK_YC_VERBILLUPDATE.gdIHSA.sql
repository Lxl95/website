create procedure Bank_YC_VerBillUpdate(UserCode     in VARCHAR2, --用户代码
                                                  TradeCode    in VARCHAR2, --交易码
                                                  BankCode     in VARCHAR2, --银行识别码
                                                  PayMoney     in VARCHAR2, --缴费金额
                                                  RunWaterCode in VARCHAR2, --委托方流水号
                                                  PayDate      in VARCHAR2, -- 记账日期 收费日期yyyymmdd
                                                  PayID        in VARCHAR2, --操作员

                                                  Results out VARCHAR2) AS
  SQL_ERM          VARCHAR2(2000);
  -- TradeCode          VARCHAR2(2) :='02'; --交易码
  --BankCode           VARCHAR2(2) := 'NY'; --银行识别号码  银行代号 农业银行默认NY
  ReturnInfoCode VARCHAR2(20); --响应码
  --RunWaterCode       VARCHAR2(20) :=RunWaterCode;--委托方流水号
  OweCount      VARCHAR2(500); --凭证张数，缴费笔数 欠费月份数
  USERNAME1     VARCHAR2(500); --用户名称


  remarks  VARCHAR2(500); --备注

  BasePayMoney    VARCHAR2(500) := PayMoney; --缴费金额 银行原数据返回,不作为发票实收金额
  --TotalOwe        VARCHAR2(12); --欠费总额 单位:分
  FellBackMoney   VARCHAR2(500); --总违约金  去除违约金减免
  dyFellBackMoney VARCHAR2(500); --当月违约金 去除违约金减免
   currenttraffic_n NUMBER;
  ACCOUNTMMONEY1   NUMBER(20, 2); --账户余额 单位:分
  Balance          NUMBER(11, 2) := 0; --本次余额
  ThBalance        NUMBER(11, 2) := 0; --本次余额
  ShiJiao          FLOAT := 0;
  spayShiJiao          FLOAT := 0;
  CuurBalance      NUMBER(11, 2) := 0; --计算当前总可用金额(缴费现金+账户余额)
  CuurBalance_YuE  NUMBER(11, 2); --当前预存金额
  LastCountBalance NUMBER(11, 2);

  PrestoteOut   NUMBER(11, 2) := 0; --预存转出
  PrestoteIn    NUMBER(11, 2) := 0; --预存转入
  shouldPaySum  NUMBER(11, 2) := 0; --应收累加
 -- actPaid       NUMBER(11, 2) := 0; --实收
  laBlance      NUMBER(11, 2) := 0; --上次余额
 -- ShiShou       NUMBER(11, 2) := 0; --实收
  i             NUMBER := 0;
  rownb         NUMBER;
  IsDanBi       NUMBER; --是否是单条账单
  Currwaterrate NUMBER(11, 2); --当月水费
  actPAIDMONEY  NUMBER(11, 2); --实收
  AllCurrwaterrate NUMBER(11, 2) := 0; --总应收水费
  AllPrestoteOut   NUMBER(11, 2) := 0; --总预存转出
  AllPrestoteIn    NUMBER(11, 2) := 0; --总预存转入
  SUMWaterRate   VARCHAR2(12); --总欠费
  SumCurrentFlow VARCHAR2(12); --总水量

  OweReusts              sys_refcursor;
  OweReustsBills         VARCHAR2(200); --账单集合
  USERINFOIDs            NUMBER;
  BBILLID                NUMBER; --账单ID
  USERID                 NUMBER;
  paycash                NUMERIC(12, 2);
  maxpaylogid            NUMBER;
  maxspaylogid           NUMBER;
  maxbillid               NUMBER;
  maxVerifyBILLID        NUMBER;
  meterid             NUMBER;
  metcode              VARCHAR2(200); --水表编号
  num                    NUMBER;
  billreaddate VARCHAR2(8);

begin

  select

   T.username,
   nvl(T.ACCOUNTMMONEY, 0) 　 ACCOUNTMMONEY,
   T.USERINFOID,
   replace(RPAD(decode(T.remark, null, ' ', T.remark), 100), ' ', ' ')
  , t.meterinfoid,t.metercode
    INTO USERNAME1,
         ACCOUNTMMONEY1,
         USERINFOIDs,
         remarks--备注
       
         ,meterid--水表id
         ,metcode
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = UserCode
     AND ROWNUM = 1;

  BEGIN

   -- MONEY := CAST(BasePayMoney AS NUMBER);
    IF (to_number(BasePayMoney) <= 0) THEN
      ReturnInfoCode := '009'; --金额错误 :小于等于0
      Results        := ReturnInfoCode;
      RETURN;
    ELSE
      dbms_output.put_line(BasePayMoney || '是[0-9]的数字序列');
    END IF;
  EXCEPTION
    WHEN value_error THEN
      --字符串转实数错误
      dbms_output.put_line(BasePayMoney || '不是[0-9]的数字序列');
      ReturnInfoCode := '009'; --金额错误 :不是数字
      Results        := ReturnInfoCode;
      RETURN;
  END;
 delete bill_jsbillid;
 commit;
  --验证是否有欠费
  SELECT COUNT(0) into num
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2
             AND B.ISRECTIFY = 0;
    if(num >0) then
  --查询欠费笔数
  select nvl(t.num,0), nvl(t.sumwa,0), nvl(t.sumcu,0), nvl(t.sumwyj, 0)
    INTO OweCount, SUMWaterRate, SumCurrentFlow, FellBackMoney
    from (SELECT COUNT(0) as num,
                 SUM(B.WATERATE) + sum(b.latefee) - sum(b.REDUCTIONMONEY) as sumwa,
                 SUM(B.CURRENTTRAFFIC) as sumcu,
                 sum(b.latefee) - sum(b.REDUCTIONMONEY) sumwyj
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2
             AND B.ISRECTIFY = 0
           GROUP BY B.USERINFOID) t
   where rownum = 1;
   end if;

  --欠费笔数,是否是单条账单
  IsDanBi := OweCount;
  --获取实收金额
  paycash := to_number(PayMoney);
  --计算当前总可用金额(缴费现金+账户余额)
  CuurBalance := ACCOUNTMMONEY1 + paycash;
  -- 当前预存金额
  CuurBalance_YuE  := ACCOUNTMMONEY1;
  LastCountBalance := ACCOUNTMMONEY1;
  ShiJiao          := paycash - FellBackMoney;
  if(ShiJiao<0) then
    ShiJiao :=0;
    end if;
  spayShiJiao :=ShiJiao;
  --获取本次余额
  Balance := to_number(PayMoney) + ACCOUNTMMONEY1 -
             to_number(SUMWaterRate);
  if (Balance >= 0 ) and (num>0) then

    --**********************************************************循环结束
    IF (USERNAME1 IS NOT NULL) THEN
      USERID  := USERINFOIDs;
      OPEN OweReusts FOR
        SELECT row_number() over(partition by b.userinfoid order by b.billid asc) rn,
               b.waterate,
               b.billid,
               nvl(b.latefee - b.reductionmoney, 0) as yslatefine --应收滞纳金 已减去滞纳金减免
               ,  b.currenttraffic --用水量
          FROM BILL B
         WHERE B.USERINFOID = USERID
           AND B.BILLSTATE = 2
           AND B.ISRECTIFY = 0;
      LOOP
        FETCH OweReusts
          INTO rownb,
               Currwaterrate,
               BBILLID,
               dyFellBackMoney,
               currenttraffic_n;
        EXIT WHEN OweReusts%NOTFOUND;
        AllCurrwaterrate := AllCurrwaterrate + Currwaterrate;
        --------------------------将billid插入到临时表中
        insert into bill_jsbillid(userinfoid, billid) values(USERID,BBILLID);
        --------------------------
        --循环插入数据
        i := i + 1;

        shouldPaySum := shouldPaySum + Currwaterrate+dyFellBackMoney; --累加应收
        IF (ShiJiao >= Currwaterrate) THEN
          PrestoteOut := 0; --预存转出
          PrestoteIn  := 0; --预存转入
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;
          IF (IsDanBi = 1) THEN
            dbms_output.put_line(BasePayMoney || '单笔操作无');
          ELSE
            ShiJiao := ShiJiao - Currwaterrate;
          END IF;
          if (IsDanBi = 1) then
            actPAIDMONEY := ShiJiao;
          else
            --如果不是最后一条
            if (i != OweCount) then
              actPAIDMONEY := Currwaterrate;
              --不是单笔的最后一条
            else
              actPAIDMONEY := ShiJiao + Currwaterrate;
            end if;

          end if;
          --本次余额处理
          ThBalance := CuurBalance_YuE;
          --上次余额处理
          laBlance := CuurBalance_YuE;
        ELSE
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;

          --上次余额处理
          laBlance := CuurBalance_YuE;
          --本次余额处理
          CuurBalance_YuE := CuurBalance_YuE - (Currwaterrate - ShiJiao);
          ThBalance       := CuurBalance_YuE;
          actPAIDMONEY    := ShiJiao;
          --预存转出
          PrestoteOut := (Currwaterrate - ShiJiao);
          --没有转入操作 转入为0
          PrestoteIn := 0;
          ShiJiao    := 0;

        END IF;
        --最后一条----余额处理
        if (i = OweCount) then
          ThBalance := CuurBalance;
          --预存款转入
          if (CuurBalance >= LastCountBalance) then
            PrestoteIn := CuurBalance - LastCountBalance;
          else
            PrestoteIn := 0;
          end if;
        end if;
        --插入账单信息 B_PAYLOG
        --查询最大ID
       select b_paylogseq.nextval
          into maxpaylogid
          from dual;

        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine,REMARK)
        VALUES
          (maxpaylogid,
           Currwaterrate,
           actPAIDMONEY,
           6,
           0,
           BBILLID,
           PrestoteIn,
           PrestoteOut,
           USERID,
           sysdate-1,
           laBlance,
           ThBalance,
           currenttraffic_n,
           RunWaterCode,
           PayID,
           6,
           RunWaterCode,
           PayID,
           dyFellBackMoney,'银行自动对账');

            AllPrestoteIn := AllPrestoteIn + PrestoteIn;
            AllPrestoteOut := AllPrestoteOut + PrestoteOut;
        --更新账单缴费状态
        UPDATE BILL b
           SET b.billstate = 1,
               b.paylog    = maxpaylogid
         WHERE b.billid = BBILLID;

        --添加对账信息
        --查询最大ID
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY,result,bankpaidmoney)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           actPAIDMONEY + nvl(dyFellBackMoney, 0),1,actPAIDMONEY + nvl(dyFellBackMoney, 0));

        commit;
      END LOOP;
 
      --获取S_PAYLOG编号
   select s_paylogseq.nextval
    into maxspaylogid
    from dual ;
      ---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine,REMARK)
      VALUES
        (maxspaylogid,
         AllCurrwaterrate,
         spayShiJiao,
         6,
         0,
         AllPrestoteIn,
         AllPrestoteOut,
         USERID,
         sysdate-1,
        LastCountBalance,
         ThBalance,
         SumCurrentFlow,
         RunWaterCode,
         PayID,
         6,
         RunWaterCode,
         PayID,
         FellBackMoney,'银行自动对账');
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = Balance
       WHERE u.userinfoid = USERID;
          --更新账单SPALOY
        UPDATE BILL b
           SET  b.spaylog   = maxspaylogid
         WHERE b.billid in(select bi.billid from bill_jsbillid bi where bi.userinfoid=USERID);
      commit;
      ReturnInfoCode := '000'; --成功
    ELSE
      ReturnInfoCode := '021'; --不欠费
    END IF;
 -- elsif(OweCount>0) then
   -- ReturnInfoCode := '009'; --缴费金额不足
  else---------------------走预存接口
   
       ReturnInfoCode := '000';
    --插入bill信息
     select decode(max(to_number(b.billid)),
                      null,
                      0,
                      max(to_number(b.billid)))
          into maxbillid
          from bill b;
        maxbillid := maxbillid + 1;

    --插入账单信息 B_PAYLOG
        --查询最大ID
       select b_paylogseq.nextval
          into maxpaylogid
          from dual ;
      --获取S_PAYLOG编号
  select s_paylogseq.nextval
    into maxspaylogid
    from dual;
insert into BILL(BILLID,USERINFOID,METERINFOID,METERCODE,LASTMONTHNUMBER,READNUMBER,CURRENTTRAFFIC,WATERATE,BILLSTATE,INVOICEPRINTSTATE,BILLYEAR,BILLMONTH,ISRECTIFY,PAYLOG,MAKEBLLLTIME,SPAYLOG)  VALUES(maxbillid,USERINFOIDs,meterid,metcode,0,0,0,0,1,2,to_char(sysdate-1,'yyyy'),to_char(sysdate-1,'MM'),0,maxpaylogid,sysdate-1,maxspaylogid);


        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine,REMARK)
        VALUES
          (maxpaylogid,
           0,
           paycash,
           6,
           0,
           maxbillid,
           paycash,
           0,
           USERINFOIDs,
           sysdate-1,
           LastCountBalance,
           LastCountBalance+paycash,
           0,
           RunWaterCode,
           PayID,
           6,
           RunWaterCode,
           PayID,
           0,'银行自动对账');
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY,result,bankpaidmoney)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           PayID,
           RunWaterCode,
           billreaddate,
           PayDate,
           paycash,1,paycash);
---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine,REMARK)
      VALUES
        (maxspaylogid,
         0,
         paycash,
         6,
         0,
         paycash,
         0,
         USERINFOIDs,
         sysdate-1,
        LastCountBalance,
         LastCountBalance+paycash,
         0,
         RunWaterCode,
         PayID,
         6,
         RunWaterCode,
         PayID,
         0,'银行自动对账');
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = u.accountmmoney+paycash
       WHERE u.userinfoid = USERINFOIDs;
       commit;
  
    -----------------------走预存接口结束
  end if;
  IF (ReturnInfoCode = '000') THEN
    Results := ReturnInfoCode;
  

  ELSE
    Results := ReturnInfoCode;
  END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '021'; --没有查到数据
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;
    ROLLBACK;
  WHEN OTHERS THEN
     SQL_ERM:=SQLERRM;
     INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_YC_VerBillUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_YC_VerBillUpdate');
     COMMIT;
    ReturnInfoCode := '002'; --报错
    Results        := ReturnInfoCode;


    ROLLBACK;
 end Bank_YC_VerBillUpdate;


/

