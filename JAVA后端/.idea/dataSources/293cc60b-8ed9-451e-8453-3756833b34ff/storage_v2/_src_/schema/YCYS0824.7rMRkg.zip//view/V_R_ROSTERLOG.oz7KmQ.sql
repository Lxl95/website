create view V_R_ROSTERLOG as
select rg.Rosterlogid, u.userinfoid, u.userinfocode,u.username ,u.useraddress, r.rostercode beforerostercode, r.rostername beforerrostername, rg.beforeorder,
       r.rostercode afterrostercode, r.rostername afterrostername, rg.afterorder, rg.modifytime,rg.beforerosterid,rg.afterrosterid,u.meterinfoid,m.meteraddress,spa.cadminname
                               from AM_R_rosterlog rg join AM_R_ROSTER r on rg.beforerosterid=r.rosterid
                                       join AM_U_USERINFO u on rg.userinfoid=u.userinfoid
                                       join mm_m_meterinfo m on u.meterinfoid=m.meterinfoid
                                       join sm_p_admin spa on spa.iadminid=rg.operatorid
                                        where rg.beforeorder <> rg.afterorder
                                       and (rg.beforerosterid <> 0 and rg.afterrosterid <> 0 )  and ( rg.afterorder <> 0 and rg.beforeorder <> 0)


union
--左右移动
select t1.Rosterlogid, t1.userinfoid, t1.userinfocode,t1.username ,t1.useraddress, t1.beforerostercode , t1.beforerrostername , t1.beforeorder,
       t2.afterrostercode , t2.afterrostername , t2.afterorder, t2.modifytime,t1.beforerosterid,t2.afterrosterid,t1.meterinfoid,t1.meteraddress,t2.cadminname from
   (select rg.Rosterlogid, u.userinfoid, u.userinfocode,u.username ,u.useraddress, r.rostercode beforerostercode, r.rostername beforerrostername, rg.beforeorder,
       r.rostercode afterrostercode, r.rostername afterrostername, rg.afterorder, rg.modifytime,rg.beforerosterid,rg.afterrosterid,u.meterinfoid,m.meteraddress
        from AM_R_rosterlog rg join AM_R_ROSTER r on rg.beforerosterid=r.rosterid
                                       join AM_U_USERINFO u on rg.userinfoid=u.userinfoid
                                        join mm_m_meterinfo m on u.meterinfoid=m.meterinfoid
                                        where  rg.beforeorder = rg.afterorder) t1
    join
   ( select rg.Rosterlogid, u.userinfoid, u.userinfocode,u.username ,u.useraddress, r.rostercode beforerostercode, r.rostername beforerrostername, rg.beforeorder,
       r.rostercode afterrostercode, r.rostername afterrostername, rg.afterorder, rg.modifytime,rg.beforerosterid,rg.afterrosterid,u.meterinfoid,m.meteraddress，spa.cadminname
        from AM_R_rosterlog rg join AM_R_ROSTER r on rg.afterrosterid=r.rosterid
                                       join AM_U_USERINFO u on rg.userinfoid=u.userinfoid
                                        join mm_m_meterinfo m on u.meterinfoid=m.meterinfoid
                                        join sm_p_admin spa on spa.iadminid=rg.operatorid
                                       where  rg.beforeorder = rg.afterorder) t2
                                 on t1.userinfoid=t2.userinfoid where t1.beforerosterid <> t2.afterrosterid and t1.modifytime=t2.modifytime
--新用户入册
union
 select rg.Rosterlogid, u.userinfoid, u.userinfocode,u.username ,u.useraddress, r.rostercode beforerostercode, r.rostername beforerrostername, rg.beforeorder,
       rg1.rostercode afterrostercode, rg1.rostername afterrostername, rg.afterorder, rg.modifytime,rg.beforerosterid,rg.afterrosterid,u.meterinfoid,m.meteraddress,spa.cadminname
         from AM_R_rosterlog rg join AM_R_ROSTER r on rg.beforerosterid=r.rosterid
                           join AM_R_ROSTER rg1 on rg1.rosterid = rg.afterrosterid
                           join AM_U_USERINFO u on rg.userinfoid=u.userinfoid
                            join mm_m_meterinfo m on u.meterinfoid=m.meterinfoid
                            join sm_p_admin spa on spa.iadminid=rg.operatorid
                                         where rg.beforerosterid = 0 or rg.afterrosterid=0


/

