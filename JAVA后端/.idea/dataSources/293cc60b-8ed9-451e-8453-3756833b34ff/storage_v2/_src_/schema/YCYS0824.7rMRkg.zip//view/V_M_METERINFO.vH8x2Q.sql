create view V_M_METERINFO as
SELECT distinct mi."METERINFOID",mi."METERCODE",mi."METERBRANDID",mi."METERCALID",mi."METERTYPE",mi."METERUSE",mi."METERBASENUMBER",
mi."METERCURRENTREADING",mi."METERADDRESS",mi."METERSTATE",
ml.lastmonthnumber,ml.readnumber,ml.currenttraffic,ml.readdate,ml.datayear,ml.datamonth
,mc.metercal,mb.meterbrandname,u.userinfoid
 FROM mm_m_meterinfo mi  left  join (select tt.* from ( select ml.meterinfoid,max(ml.meterdatacurrentmonthid) meterdatacurrentmonthid
          from mm_m_meterdatacurrentmonth ml
                    group by ml.meterinfoid
         order by METERDATACURRENTMONTHID desc ) t join mm_m_meterdatacurrentmonth tt on t.meterdatacurrentmonthid=tt.meterdatacurrentmonthid) ml on mi.meterinfoid=ml.meterinfoid
                       left join mm_m_metercal mc on mi.metercalid=mc.metercalid
                       left join mm_m_meterbrand mb on mi.meterbrandid=mb.meterbrandid
                      left  join am_u_userinfo u on mi.meterinfoid=u.meterinfoid


/

