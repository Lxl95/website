create procedure Bank_ABC_PayInfoUpdate(UserCode     in VARCHAR2,
                                                   UserCategory  in VARCHAR2,--用户类别
                                                   PayMoney      in VARCHAR2, --实收金额

                                                   PayDate       in VARCHAR2, --收费日期
                                                  -- BankCardCode  in VARCHAR2, --银行卡号
                                                   TradeCode     in VARCHAR2, --交易码
                                                   BankCode      in VARCHAR2, --银行代号 区分各大银行
                                                   NetWorkCode   in VARCHAR2, --网点代号 储蓄所或分理处的代号
                                                   PayID         in VARCHAR2, --收费员
                                                   RunWaterCode  in VARCHAR2, --流水号
                                                   Results       out VARCHAR2) AS
   SQL_ERM          VARCHAR2(4000);
  ReturnInfoCode  VARCHAR2(2); --返回信息码
  USERINFOCODE    VARCHAR2(20) := UserCode;
  USERNAME        VARCHAR2(200);
  USERADDRESS     VARCHAR2(200);
  PAYWAY          VARCHAR2(3); --缴费方式 1：现金 2：代扣 3：托收 4：支票 5:预付
  WateRatePublish VARCHAR2(1); --水费应收已发行  Y/N           水费应收已发行
  IsOwe           VARCHAR2(1); --本次交费后用户已经不欠费 Y/N  结清标志
  BasePayMoney    VARCHAR2(12) := PayMoney; --缴费金额 银行原数据返回,不作为发票实收金额
  TotalOwe        VARCHAR2(12); --欠费总额 单位:分
  FellBackMoney   VARCHAR2(12); --总违约金  去除违约金减免
  dyFellBackMoney VARCHAR2(12); --当月违约金 去除违约金减免
  OweCount        VARCHAR2(2); --欠费月份数
  WateRatePublishCount VARCHAR2(1); --水费应收已发行  Y/N           水费应收已发行
  IsOweCount           VARCHAR2(1); --本次交费后用户已经不欠费 Y/N  结清标志
  ACCOUNTMMONEY      NUMBER(20,2); --账户余额 单位:分
  Balance      NUMBER(11,2) :=0;--本次余额
  ThBalance   NUMBER(11,2) :=0;--本次余额
  ShiJiao       FLOAT :=0;
  CuurBalance    NUMBER(11,2) :=0;--计算当前总可用金额(缴费现金+账户余额)
  CuurBalance_YuE NUMBER(11,2);          --当前预存金额
  LastCountBalance NUMBER(11,2);
  BillDate      VARCHAR2(20);
 PrestoteOut NUMBER(11,2) := 0; --预存转出
 PrestoteIn  NUMBER(11,2) := 0;--预存转入
 shouldPaySum NUMBER(11,2) := 0;--应收累加
 actPaid NUMBER(11,2) := 0;--实收
 laBlance NUMBER(11,2) := 0;  --上次余额
 ShiShou NUMBER(11,2) := 0;--实收
 verpaidmoney NUMBER(11,2) := 0;--实收
 i NUMBER := 0;
 IsDanBi NUMBER ;--是否是单条账单
 Currwaterrate  NUMBER(11,2);    --当月水费
 actPAIDMONEY NUMBER(11,2);   --实收
  AllCurrwaterrate NUMBER(11, 2) := 0; --总应收水费
  AllPrestoteOut   NUMBER(11, 2) := 0; --总预存转出
  AllPrestoteIn    NUMBER(11, 2) := 0; --总预存转入
 spayShiJiao          FLOAT := 0;
sumFellBackMoney NUMBER(20, 2) := 0; --总违约金 分
 /* PrestoteOut   NUMBER(11,2);--预存销账
  PrestoteIn     NUMBER(11,2);--预存准入    */
  InvoiceForm   VARCHAR2( 1) := ' '; --空 发票格式
  CurrentFlow   VARCHAR2(12); --该月总水量
  WaterRate     NUMBER(12,2); --该月总水费 单位:分
  SUMWaterRate VARCHAR2(12); --总欠费
  SumCurrentFlow VARCHAR2(12);--总水量
sumcsf  VARCHAR2(12); --总欠费 不包括违约金
  OweReusts              sys_refcursor;
  OweReustsBills         VARCHAR2(200); --账单集合
  OweReustsTotalOwe      NUMBER :=0; --欠费总金额
  OweReustsString        VARCHAR2(2000); --12笔的欠费记录
  USERINFOIDs             NUMBER;
  ADVANCEPRINTOPERATERID NUMBER; --预打印人
  BBILLID                 NUMBER; --账单ID
  USERID                 NUMBER;
  MONEY                  NUMERIC(10);
  paycash                NUMERIC(12,2);
  maxpaylogid            NUMBER;
  maxVerifyBILLID        NUMBER;
  maxspaylogid           NUMBER;
  maxBILLID        NUMBER;
  meterid number;
  mecode   VARCHAR2(200);
   sfiadminid  VARCHAR2(200);
     num                    NUMBER;
 -- teSTID NUMBER;
  --billmonth              VARCHAR2(2);

begin

  select
         replace(RPAD(decode(T.USERNAME,null,' ', T.USERNAME),64),' ',' '),
         replace(RPAD(decode(T.USERADDRESS,null,' ', T.USERADDRESS),64),' ',' '),
         decode( T.PAYWAY,null,' ',  T.PAYWAY),
           T.ACCOUNTMMONEY,
        -- decode( T.ACCOUNTMMONEY,null,' ',  T.ACCOUNTMMONEY),
         T.USERINFOID,t.meterinfoid,t.metercode

    INTO USERNAME,
         USERADDRESS,
         PAYWAY,
         ACCOUNTMMONEY,
         USERINFOIDs,meterid,mecode
    FROM am_u_userinfo T
   WHERE T.USERINFOCODE = UserCode
     AND ROWNUM = 1;
  IF (ACCOUNTMMONEY is null) THEN
      ACCOUNTMMONEY := 0; --账户余额为0
      end if;

  IF (PAYWAY = '3') THEN
    ReturnInfoCode := '24'; --托收不能在银行缴费
  END IF;


    BEGIN

    MONEY := CAST(BasePayMoney AS NUMBER) ;
    IF (to_number(BasePayMoney) <= 0) THEN
         ReturnInfoCode := '13'; --金额错误 :小于等于0
          Results        := ReturnInfoCode ;
       RETURN;
    ELSE
        dbms_output.put_line(BasePayMoney || '是[0-9]的数字序列');
    END IF;
    EXCEPTION
    WHEN value_error THEN --字符串转实数错误
       dbms_output.put_line(BasePayMoney || '不是[0-9]的数字序列');
       ReturnInfoCode := '13'; --金额错误 :不是数字
       Results        := ReturnInfoCode ;
       RETURN;

END;
   delete bill_jsbillid;
    commit;
 --验证是否有欠费
  SELECT COUNT(0) into num
            from BILL B
           WHERE B.USERINFOID = USERINFOIDs
             AND B.BILLSTATE = 2 and b.waterate>0 and b.readdate is not null
             AND B.ISRECTIFY = 0;
    if(num >0) then
--查询欠费笔数
  select nvl(t.num,0), nvl(t.sumwa,0), nvl(t.sumcu,0), nvl(t.sumwyj, 0),
   nvl(t.sumcsf, 0)* 100, nvl(t.sumwyj, 0)*100
 INTO OweCount,SUMWaterRate,SumCurrentFlow, FellBackMoney,sumcsf,sumFellBackMoney
     from (SELECT  COUNT(0) as num,
       SUM(B.WATERATE) + sum(b.latefee) - sum(b.REDUCTIONMONEY) as sumwa,
      SUM(B.CURRENTTRAFFIC) as sumcu,
       sum(b.latefee) - sum(b.REDUCTIONMONEY) sumwyj,SUM(B.WATERATE) sumcsf  from BILL B
       WHERE B.USERINFOID = USERINFOIDs
       AND B.BILLSTATE = 2
       AND B.ISRECTIFY = 0
     GROUP BY B.USERINFOID) t where rownum=1;
       OweReustsString :=  REPLACE(RPAD(SumCurrentFlow, 12), ' ', ' ')  || REPLACE(RPAD(sumcsf, 12), ' ', ' ') || REPLACE(RPAD(sumFellBackMoney, 12), ' ', ' ')  ;
end if;
    IF (OweCount = 0 ) THEN
      ReturnInfoCode := '09'; --查询不到该月水费信息
      SUMWaterRate :=0;
    END IF;
  --欠费笔数,是否是单条账单
    IsDanBi :=OweCount;
    --获取实收金额
      paycash :=to_number(PayMoney)/100;
   --计算当前总可用金额(缴费现金+账户余额)
      CuurBalance := ACCOUNTMMONEY +paycash;
      -- 当前预存金额
      CuurBalance_YuE := ACCOUNTMMONEY;
      LastCountBalance  := ACCOUNTMMONEY;
       ShiJiao :=paycash - FellBackMoney;
         if(ShiJiao<0) then
    ShiJiao :=0;
    end if;
  spayShiJiao :=ShiJiao;
        --获取本次余额
     Balance :=to_number(PayMoney)/100 + ACCOUNTMMONEY-to_number(SUMWaterRate);
   if (Balance >= 0 ) and (num>0) then

  IF (USERNAME IS NOT NULL) THEN
    USERID :=USERINFOIDS;
    --生成每月用水量 协议变长部分
    OPEN OweReusts FOR
      SELECT
             B.WATERATE,
             B.CURRENTTRAFFIC,
             B.WATERATE * 100,
             B.ADVANCEPRINTOPERATERID,
             B.billid,
             b.billyear||b.billmonth,
               nvl(b.latefee - b.reductionmoney, 0) as yslatefine --应收滞纳金 已减去滞纳金减免
        FROM BILL B
       WHERE B.USERINFOID = USERID
         AND B.BILLSTATE = 2
         AND B.ISRECTIFY = 0
         --添加收费排序
         order by b.billid asc;

    LOOP
      FETCH OweReusts
        INTO Currwaterrate,
             CurrentFlow,
             WaterRate,
             ADVANCEPRINTOPERATERID,
             BBILLID,
             BillDate,
             dyFellBackMoney ;
      EXIT WHEN OweReusts%NOTFOUND;
      IF (ADVANCEPRINTOPERATERID IS NOT null) THEN
        ReturnInfoCode := '11'; --预打印状态
        exit;
      END IF;
    AllCurrwaterrate := AllCurrwaterrate + Currwaterrate;

     OweReustsTotalOwe := OweReustsTotalOwe + WaterRate;
     /*OweReustsString := OweReustsString ||  REPLACE(RPAD(CurrentFlow, 12), ' ', ' ')  || REPLACE(RPAD(WaterRate, 12), ' ', ' ') || REPLACE(RPAD(dyFellBackMoney, 12), ' ', ' ')  ;*/
        --------------------------将billid插入到临时表中
        insert into bill_jsbillid(userinfoid, billid) values(USERID,BBILLID);
        --------------------------
     --循环插入数据
     i :=i+1;

    shouldPaySum := shouldPaySum + Currwaterrate+dyFellBackMoney; --累加应收
       IF (ShiJiao >= Currwaterrate) THEN
          PrestoteOut := 0; --预存转出
          PrestoteIn  := 0; --预存转入
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;
          IF (IsDanBi = 1) THEN
            dbms_output.put_line(BasePayMoney || '单笔操作无');
          ELSE
            ShiJiao := ShiJiao - Currwaterrate;
          END IF;
          if (IsDanBi = 1) then
            actPAIDMONEY := ShiJiao;
          else
            --如果不是最后一条
            if (i != OweCount) then
              actPAIDMONEY := Currwaterrate;
              --不是单笔的最后一条
            else
              actPAIDMONEY := ShiJiao + Currwaterrate;
            end if;

          end if;
          --本次余额处理
          ThBalance := CuurBalance_YuE;
          --上次余额处理
          laBlance := CuurBalance_YuE;
        ELSE
          --计算可用金额
          CuurBalance := CuurBalance - Currwaterrate-dyFellBackMoney;

          --上次余额处理
          laBlance := CuurBalance_YuE;
          --本次余额处理
          if(paycash < dyFellBackMoney) then
            CuurBalance_YuE := CuurBalance_YuE - (Currwaterrate - ShiJiao)-(dyFellBackMoney-paycash);
          else
            CuurBalance_YuE := CuurBalance_YuE - (Currwaterrate - ShiJiao);
          end if;
          ThBalance       := CuurBalance_YuE;
          actPAIDMONEY    := ShiJiao;
          --预存转出
          PrestoteOut := (Currwaterrate - ShiJiao);
          --没有转入操作 转入为0
          PrestoteIn := 0;
          ShiJiao    := 0;

        END IF;
        --最后一条----余额处理
        if (i = OweCount) then
          ThBalance := CuurBalance;
          --预存款转入
          if (CuurBalance >= LastCountBalance) then
            PrestoteIn := CuurBalance - LastCountBalance;
          else
            PrestoteIn := 0;
          end if;
        end if;
     --插入账单信息 B_PAYLOG
        --查询最大ID
         select b_paylogseq.nextval
          into maxpaylogid
          from dual;


        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine)
        VALUES
          (maxpaylogid,
           Currwaterrate,
           actPAIDMONEY,
           6,
           0,
           BBILLID,
           PrestoteIn,
           PrestoteOut,
           USERID,
           sysdate,
           laBlance,
           ThBalance,
           CurrentFlow,
           RunWaterCode,
           42,
           6,
           RunWaterCode,
           42,
           dyFellBackMoney);

            AllPrestoteIn := AllPrestoteIn + PrestoteIn;
            AllPrestoteOut := AllPrestoteOut + PrestoteOut;
        --更新账单缴费状态
        UPDATE BILL b
           SET b.billstate = 1,
               b.paylog    = maxpaylogid
         WHERE b.billid = BBILLID;

        --添加对账信息
        --查询最大ID
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;
if(paycash < dyFellBackMoney) then
verpaidmoney := paycash;
else
  verpaidmoney :=actPAIDMONEY + nvl(dyFellBackMoney, 0);
  end if;
        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY,RESULT)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           42,
           RunWaterCode,
           BillDate,
           PayDate,
           actPAIDMONEY + nvl(dyFellBackMoney, 0),1);

     if(ReturnInfoCode ='11') then
         ReturnInfoCode := '11';
       else
         ReturnInfoCode := '00';
        end if;

    END LOOP;
    if(ReturnInfoCode !='11') then

     --获取S_PAYLOG编号
  select s_paylogseq.nextval
    into maxspaylogid
    from dual;
      ---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine)
      VALUES
        (maxspaylogid,
         AllCurrwaterrate,
         spayShiJiao,
         6,
         0,
         AllPrestoteIn,
         AllPrestoteOut,
         USERID,
         sysdate,
        LastCountBalance,
         ThBalance,
         SumCurrentFlow,
         RunWaterCode,
         42,
         6,
         RunWaterCode,
         42,
         FellBackMoney);
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = Balance
       WHERE u.userinfoid = USERID;
          --更新账单SPALOY
        UPDATE BILL b
           SET  b.spaylog   = maxspaylogid
         WHERE b.billid in(select bi.billid from bill_jsbillid bi where bi.userinfoid=USERID);
     commit;
      end if;
  ELSE
    ReturnInfoCode := '08'; --不欠费
    END IF;
    elsif(OweCount>0) then
         ReturnInfoCode := '16'; --缴费金额不足
    else
      OweReustsString := '000000000000' || '000000000000' || '000000000000'  ;
        ReturnInfoCode :='00';
       --插入bill信息
     select decode(max(to_number(b.billid)),
                      null,
                      0,
                      max(to_number(b.billid)))
          into maxbillid
          from bill b;
        maxbillid := maxbillid + 1;

    --插入账单信息 B_PAYLOG
        --查询最大ID
         select b_paylogseq.nextval
          into maxpaylogid
          from dual ;
      --获取S_PAYLOG编号
  select s_paylogseq.nextval
    into maxspaylogid
    from dual;
insert into BILL(BILLID,USERINFOID,METERINFOID,METERCODE,LASTMONTHNUMBER,READNUMBER,CURRENTTRAFFIC,WATERATE,BILLSTATE,INVOICEPRINTSTATE,BILLYEAR,BILLMONTH,ISRECTIFY,PAYLOG,MAKEBLLLTIME,SPAYLOG)  VALUES(maxbillid,USERINFOIDs,meterid,mecode,0,0,0,0,1,2,to_char(sysdate,'yyyy'),to_char(sysdate,'MM'),0,maxpaylogid,sysdate,maxspaylogid);


        INSERT INTO B_PAYLOG
          (PAYLOG,
           RECEIVABLEMONEY,
           PAIDMONEY,
           PAIDTYPE,
           INVOICEPRINTSTATE,
           BILLIDS,
           PRESTOREIN,
           PRESTOREOUT,
           USERINFOID,
           DDATETIME,
           LASTBALANCE,
           THISBALANCE,
           WATERTRAFFIC,
           BANKCURRENTNUM,
           CHEQUEBANKID,
           Moneytype,
           PAYLOGBATCH,
           Iadminid,
           Latefine)
        VALUES
          (maxpaylogid,
           0,
           paycash,
           6,
           0,
           maxbillid,
           paycash,
           0,
           USERINFOIDs,
           sysdate,
           LastCountBalance,
           LastCountBalance+paycash,
           0,
           RunWaterCode,
           42,
           6,
           RunWaterCode,
           42,
           0);
        select decode(max(to_number(v.verifybillid)),
                      null,
                      0,
                      max(to_number(v.verifybillid)))
          into maxVerifyBILLID
          from B_VERIFYBILL v;
        maxVerifyBILLID := maxVerifyBILLID + 1;

        INSERT INTO B_VERIFYBILL
          (VERIFYBILLID,
           PAYLOGID,
           USEINFOCODE,
           TRADECCODE,
           BANKCCODE,
           OPERATERID,
           BANKCURRENTNUM,
           WATERDATE,
           PAYDDATE,
           PAIDMONEY,RESULT)
        VALUES
          (maxVerifyBILLID,
           maxpaylogid,
           UserCode,
           TradeCode,
           BankCode,
           42,
           RunWaterCode,
           BillDate,
           PayDate,
           paycash,1);
---插入s_paylog

      INSERT INTO S_PAYLOG
        (SPAYLOG,
         RECEIVABLEMONEY,
         PAIDMONEY,
         PAIDTYPE,
         INVOICEPRINTSTATE,
         PRESTOREIN,
         PRESTOREOUT,
         USERINFOID,
         DDATETIME,
         LASTBALANCE,
         THISBALANCE,
         WATERTRAFFIC,
         BANKCURRENTNUM,
         CHEQUEBANKID,
         Moneytype,
         PAYLOGBATCH,
         Iadminid,
         Latefine)
      VALUES
        (maxspaylogid,
         0,
         paycash,
         6,
         0,
         paycash,
         0,
         USERINFOIDs,
         sysdate,
        LastCountBalance,
         LastCountBalance+paycash,
         0,
         RunWaterCode,
         42,
         6,
         RunWaterCode,
         42,
         0);
      --更新用户账户余额
      UPDATE AM_U_USERINFO u
         SET u.accountmmoney = u.accountmmoney+paycash
       WHERE u.userinfoid = USERINFOIDs;
       commit;
       end if;

    --查询本月水费账单是否发行
     SELECT COUNT(0) INTO WateRatePublishCount
        FROM BILL B
       WHERE B.USERINFOID = USERID
         AND B.BILLSTATE = 2
         AND B.BILLYEAR= (select to_char(sysdate, 'yyyy') as nowYear from dual)
         AND B.BILLMONTH =to_number((select to_char(sysdate, 'mm') as nowYear from dual))
         AND B.ISRECTIFY = 0;
      IF (WateRatePublishCount = 1 ) THEN
        WateRatePublish := 'Y'; --已发行
      ELSE
        WateRatePublish :='N';
    END IF;


  --查询本月水费账单是否发行
     SELECT COUNT(0) INTO IsOweCount
        FROM BILL B
       WHERE B.USERINFOID = USERID
         AND B.BILLSTATE = 2
         AND B.ISRECTIFY = 0;
      IF (IsOweCount = 0 ) THEN
        IsOwe := 'Y'; --已结清
      ELSE
        IsOwe :='N';
    END IF;
  IF(  ReturnInfoCode = '00' or ReturnInfoCode='11'  or ReturnInfoCode='09') THEN
   Results        := ReturnInfoCode || REPLACE(RPAD(USERINFOCODE, 20), ' ', ' ') || USERNAME || USERADDRESS ||
                      REPLACE(RPAD(PAYWAY, 3), ' ', ' ') || WateRatePublish ||
                      IsOwe ||  REPLACE(RPAD(BasePayMoney, 12), ' ', ' ')  || OweReustsString;
    ELSE
       Results        := ReturnInfoCode ;
       END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
      SQL_ERM:=SQLERRM;
    ReturnInfoCode := '03'; --没有查到数据
     Results        := ReturnInfoCode ;
      INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_ABC_PayInfoUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_ABC_PayInfoUpdate');
     rollback;
  WHEN TOO_MANY_ROWS THEN
 SQL_ERM:=SQLERRM;
    ReturnInfoCode := '02'; --报错
     Results        := ReturnInfoCode;
        INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_ABC_PayInfoUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_ABC_PayInfoUpdate');
 rollback;
  WHEN OTHERS THEN
     SQL_ERM:=SQLERRM;
    ReturnInfoCode := '02'; --报错
     Results        := ReturnInfoCode;
        INSERT INTO sys_errorlog(ID,Table_Name,Error_Date,error_data,error_operate,remarks)
     values(SEQ_ERRORID.NEXTVAL,'Bank_ABC_PayInfoUpdate',SYSDATE,SQL_ERM,'CTI','PR.Bank_ABC_PayInfoUpdate');
   ROLLBACK;
end Bank_ABC_PayInfoUpdate;


/

