create view V_U_USERINFOPUSH as
select r.meterreaderid,
-- (select count(distinct(BILLMONTH)) from bill  where USERINFOID=u.userinfoid and  billstate=2 and isrectify=0  ) as Arrearscount ,
 --(select sum(WATERATE) from BILL where USERINFOID = u.userinfoid and  billstate=2 and isrectify=0  ) as SumMoney,
 r.rostercode,r.rostername,
  u.welladd , wl.wellid,wl.wellname,
 u."ROSTERID",u."USERINFOID",u."USERINFOCODE",u."USERNAME"
  ,u.useraddress, case when bb.Arrearscount is null then 0 else  bb.Arrearscount end as Arrearscount ,
  --sum(b.WATERATE) as SumMoney
case when sum(bb.sumWATERATE) is null then 0 else  sum(bb.sumWATERATE) end as SumMoney
   from am_u_userinfo u
      LEFT JOIN mm_w_userwell w on w.userid=u.USERINFOID
      LEFT JOIN mm_w_meterwellrelation wl on w.wellid=wl.wellid
      LEFT JOIN am_r_roster r on r.rosterid=u.rosterid
      left join
      (select count(0) as Arrearscount, sum(b.WATERATE) as  sumWATERATE,b.userinfoid
      from  bill b  where  billstate=2 and isrectify=0  and b.makebllltime < to_char(sysdate,'yyyy-mm')||'-01'  group by userinfoid ) bb on bb.userinfoid=u.userinfoid

      group by bb.Arrearscount,  r.rostercode,r.rostername,u.welladd , wl.wellid,wl.wellname,u."ROSTERID",u."USERINFOID",u."USERINFOCODE",u."USERNAME" ,u.useraddress,r.meterreaderid


/

