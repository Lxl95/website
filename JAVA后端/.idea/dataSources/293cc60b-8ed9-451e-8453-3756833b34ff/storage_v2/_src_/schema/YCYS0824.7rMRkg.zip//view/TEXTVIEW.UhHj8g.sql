create view TEXTVIEW as
select "ID","NAME","NUM"
    from text


/

