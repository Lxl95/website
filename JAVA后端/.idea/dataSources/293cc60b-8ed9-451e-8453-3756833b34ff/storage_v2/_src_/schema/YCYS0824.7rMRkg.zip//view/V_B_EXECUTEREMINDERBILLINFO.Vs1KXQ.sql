create view V_B_EXECUTEREMINDERBILLINFO as
select distinct W.NOTE, w.receivetime,w.status, w.receiveid,w.completedtime1,w.receivename,w.sendername,u.userinfoid,u.usertype,
u.userinfocode,u.username,u.useraddress,l.locationareaname,c.communtyname,c.communtyid,l.locatioareaid,
(select count(distinct(BILLMONTH)) from REMINDER re1 where USERINFOID=re.userinfoid ) as Arrearscount ,tem.billyear,tem.billmonth,tem.waterate

   from (select *
  from WORKFLOWTASK w
  join (select w1.groupid, max(w1.completedtime1) maxcompletedtime1
          from (select *
                  from WORKFLOWTASK w
                 where w.groupid not in
                       (select w.groupid
                          from WORKFLOWTASK w
                         where w.flowid =
                               'f34d4e54-93d2-4b75-b148-8a39589975a6'
                           and w.completedtime1 is null)) w1
         where w1.completedtime1 is not null
         group by w1.groupid) wf
    on w.groupid = wf.groupid
   and w.completedtime1 = wf.maxcompletedtime1
 where w.flowid = 'f34d4e54-93d2-4b75-b148-8a39589975a6') w join TEMPTEST_USERREMINDER tem on w.instanceid=tem.id
                       join REMINDER re on tem.userinfoid=re.userinfoid
                       join AM_U_USERINFO u on tem.userinfoid=u.userinfoid
                       left join sm_p_locationarea l on u.locatioareaid=l.locatioareaid
                       left join bs_u_community c on u.communtyid=c.communtyid


/

