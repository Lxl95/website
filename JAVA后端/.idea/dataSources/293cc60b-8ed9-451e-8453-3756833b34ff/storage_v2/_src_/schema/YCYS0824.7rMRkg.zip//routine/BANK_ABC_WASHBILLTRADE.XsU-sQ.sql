create procedure Bank_ABC_WashBillTrade( BankCode      in VARCHAR2, --银行代号 区分各大银行
                                                   PayID         in VARCHAR2, --操作员
                                                   PayDate       in VARCHAR2, --收费日期 必须当天
                                                   OriginalRunWaterCode  in VARCHAR2, --原流水号
                                                   NetWorkCode   in VARCHAR2, --网点代号 储蓄所或分理处的代号
                                                   Results       out VARCHAR2) AS
  ReturnInfoCode  VARCHAR2(2); --返回信息码
  PrestoteOut   NUMBER(11,2);--预存销账
  PrestoteIn     NUMBER(11,2);--预存转入
  Bills         VARCHAR2(200); --账单集合
  USERID                  VARCHAR2(30);
  PayLogID               NUMBER;
  Nowdate              VARCHAR2(8);
  OweReusts              sys_refcursor;




begin

   select  to_char(sysdate,'yyyymmdd')
   into Nowdate from dual;

 IF(Nowdate = PayDate) THEN
--查询对账单中缴费记录ID
  OPEN OweReusts FOR
      SELECT b.paylogid

     FROM B_VERIFYBILL b LEFT JOIN B_PAYLOG bp on b.paylogid=bp.paylog
     WHERE b.bankccode = BankCode
     AND b.operaterid=PayID
     AND b.payddate=PayDate
     AND b.bankcurrentnum=OriginalRunWaterCode
     AND bp.PAYREDSTATE=0;

    LOOP
      FETCH OweReusts
        INTO PayLogID;

      EXIT WHEN OweReusts%NOTFOUND;

        IF (PayLogID is not null) THEN

    select  P.BILLIDS,P.USERINFOID,P.PRESTOREOUT,P.PRESTOREIN

    INTO Bills,USERID,PrestoteOut,PrestoteIn

    FROM B_PAYLOG P
   WHERE P.Paylog=PayLogID
     AND P.PAYREDSTATE=0
     AND ROWNUM = 1;

      IF (Bills IS NOT NULL) THEN

    --更新账单缴费状态
     UPDATE BILL b SET b.billstate=2 WHERE b.billid in (Bills);
    --更新缴费记录红冲状态
     UPDATE B_PAYLOG pl SET pl.payredstate=1,pl.redtime=sysdate,pl.payrediadminid=PayID WHERE pl.paylog=PayLogID  ;
    --更新账户余额
     UPDATE AM_U_USERINFO SET ACCOUNTMMONEY=ACCOUNTMMONEY+to_number(PrestoteOut)-to_number(PrestoteIn) WHERE USERINFOID=USERID;

 ReturnInfoCode := '00';
     ELSE
        ReturnInfoCode := '03'; --无记录
        END IF;

  ELSE
    ReturnInfoCode := '03'; --无记录
    END IF;
    commit;
    END LOOP;

 ELSE
    ReturnInfoCode := '03'; --无记录;
END IF;
   IF( ReturnInfoCode = '00') THEN

   Results        := ReturnInfoCode || REPLACE(RPAD(BankCode, 2), ' ', ' ') || REPLACE(RPAD(NetWorkCode, 25), ' ', ' ') ||
                     REPLACE(RPAD(PayID, 8), ' ', ' ') ||  REPLACE(RPAD(OriginalRunWaterCode, 16), ' ', ' ')  ||
                     REPLACE(RPAD(PayDate, 8), ' ', ' ' );
    ELSE
      ReturnInfoCode:='03';
      Results        := ReturnInfoCode;
      END IF;
EXCEPTION

  WHEN NO_DATA_FOUND THEN
    ReturnInfoCode := '03'; --没有查到数据
       Results        := ReturnInfoCode;
  WHEN TOO_MANY_ROWS THEN

    ReturnInfoCode := '02'; --报错
        Results        := ReturnInfoCode;
  WHEN OTHERS THEN
    ReturnInfoCode := '02'; --报错
      Results        := ReturnInfoCode;
      ROLLBACK;

end Bank_ABC_WashBillTrade;


/

