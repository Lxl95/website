create view V_W_WORKFLOW_TEMP_WATERFAVOR as
select "ID","OPENID","INSTANCEID","RESERVATIONCODE","STATE","INSERTTIME","USERINFOCODE","USERNAME","USERADDRESS","CONTECTPERSON","CONTECT","FAVORTYPE","REMARKS","FILES","WORKFLOWSTATE" from (
  select t.*,case when w.id is null then t.state else 100 end as workflowstate
    from WORKFLOW_TEMP_WATERFAVOR t
    left join (select * from WORKFLOWTASK order by sort desc) w on w.instanceid=t.instanceid
) a where a.workflowstate != 100  and a.STATE != -2


/

