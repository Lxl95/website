create trigger WORK_LOG
    before insert
    on WORK_LOG
    for each row
begin
 select WORK_LOG_ID.nextval into:New.id from dual;
 end;
/

