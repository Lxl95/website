create trigger WX_SAFETY_USER_TRIGGER
    before insert
    on WX_SAFETY_USER
    for each row
begin
  select wx_safety_user_sq.nextval into :NEW.id from dual;
end;

/

