create view V_U_CUSTOMINFOLOG as
SELECT
c."CUSTOMLOGID",c."CUSTOMINFOID",c."MODIFYTYPE",c."MODIFYTIME",c."OPERATORID",c."REMARK",a.cadminname,co.custominfocode,co.customname,co.customaddress,co.identitytypvalue,co.creditleval,co.email,co.contact,co.corporation,co.vat
 FROM         AM_C_CUSTOMLOG c INNER JOIN
                      sm_p_admin a ON c.operatorid=a.iadminid
                     join AM_C_CUSTOMINFO co on c.custominfoid=co.custominfoid


/

