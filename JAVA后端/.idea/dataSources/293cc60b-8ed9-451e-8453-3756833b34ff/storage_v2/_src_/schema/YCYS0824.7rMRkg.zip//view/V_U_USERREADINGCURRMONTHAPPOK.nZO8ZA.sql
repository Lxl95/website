create view V_U_USERREADINGCURRMONTHAPPOK as
select u.usertype,
       u.sealnumber,
       u.meterreaderid,
       u.welladd,
       u.meterwalladdress,
       u.contect,
       u.mixwatertypeid,
       u.mixwaterrate,
       u.mixwaterflow,
       u.usewatertypeid,
       u.usewatertypename,
       u."LOCATIOAREAID",
       u."LOCATIONAREACODE",
       u."LOCATIONAREANAME",
       u."COMMUNTYID",
       u."COMMUNTYCODE",
       u."COMMUNTYNAME",
       u."ROSTERCODE",
       u."ROSTERID",
       u."ROSTERNAME",
       u."USERINFOID",
       u."USERSTATE",
       u."USERINFOCODE",
       u."USERNAME",
       u."USERADDRESS",
       u."METERINFOID",
       u."METERCODE",
       u."METERBRANDID",
       u."METERCALID",
       u."METERTYPE",
       u."METERUSE",
       u."METERBASENUMBER",
       u."METERCURRENTREADING",
       u."METERADDRESS",
       u."METERSTATE",
       u."LASTMONTHNUMBER",
       u."READNUMBER",
       u."CURRENTTRAFFIC",
       u."DATAYEAR",
       u."DATAMONTH",
       u."REMARK",
       u."ROSTERORDER",
       u."METERCAL",
       u."SITEID",
       u."SITECODE",
       u."SITENAME",
       u."METERBRANDNAME",
       u."ISACCOUNT",
       u.accountmmoney,
       u.needtyperate,
       u.needflow,
       u.nusewatertypename as watertypename,
       u.mixwatertype,
       u.lsumwnum,
       u.lastcurrent,
       case
         when u.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              u.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)then
          u.readnumber
         else
          null
       end as currnum,
       case
         when u.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              u.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual)then
          u.lastmonthnumber
         else
          u.readnumber
       end as lastnumber,
       case
         when u.datayear =
              (select to_char(sysdate, 'yyyy') as nowYear from dual) and
              u.datamonth =
              (select to_char(sysdate, 'mm') as nowYear from dual) then
          u.currenttraffic
         else
          null
       end as currwaternum,
       u.addflow,
   /*    case
         when (select to_char(sysdate, 'yyyy-mm-dd') as nowYear from dual) >
              (select to_char(sysdate, 'yyyy-mm') || '-26' as nowYear
                 from dual) then
          (select to_char(add_months(trunc(sysdate), 1), 'yyyy-mm-dd') as nowdate
             from dual)
         else
          to_char(u.readdate)
       end as readdate*/
       u.readdate,to_char(add_months(trunc(sysdate),-1),'yyyy') as yy, to_char(add_months(trunc(sysdate),-1),'MM') as mm

  from V_U_USERMETERINFON u


/

