create procedure RemoteMeterInsert(MeterCode           in VARCHAR2, --水表编号
                                              MeterCurrentReading in number, --水表当前读数
                                              Results             out number) --返回状态

 AS

  --add by li.shuangli 增加损耗量计算和水资源量计算

  lastnum           number := 0; --上期读数;

  yd                number := 0; --是否存在当月月冻结数据
  isExistMonth      number := 0; --是否存在月冻结数据
  --weizhimin add
  out_return varchar2(1000);
  val        int; --全局变量  
  errorException exception; --申明异常  
  errorCode number; --异常编码  
  errorMsg  varchar2(1000);
  -----------------------------
  NewMeterCode           VARCHAR2(20) := MeterCode;
  NewMeterCurrentReading number := MeterCurrentReading;
  IsAccount              number; --是否开过账;
  userid                 VARCHAR2(20); --用户编号;
  watertypeid            number; --用水性质
begin

  ---------------------------
  --首先查询是否存在月冻结记录
  select COUNT(METERINFOID)
    into isExistMonth
    from MM_M_METERDATACURRENTMONTH
   where MeterCode = NewMeterCode;
  if (isExistMonth = 0) then
    --不存在月冻结记录，从水表表中获取上期读数
    select m.metercurrentreading
      into lastnum
      from mm_m_meterinfo m
     where m.metercode = NewMeterCode;
  else
    --1查询该表号上期读数
    select COUNT(METERINFOID),
           max(MM_M_METERDATACURRENTMONTH.Lastmonthnumber)
      into yd, lastnum
      from MM_M_METERDATACURRENTMONTH
     where MeterCode = NewMeterCode
       and (to_char(READDATE, 'yyyy')) =
           (select to_char(sysdate, 'yyyy') as nowYear from dual)
       and (to_char(READDATE, 'mm')) =
           (select to_char(sysdate, 'mm') as nowYear from dual);
    if (yd = 0) then
      --2不存在当月月冻结，取最大日期的当期读数就是当前月份的上期读数
      select readnumber
        into lastnum
        from (select decode(mo.readnumber, null, 0, mo.readnumber) as readnumber,
                     row_number() over(partition by mo.meterinfoid order by mo.readdate desc) rn
              
                from MM_M_METERDATACURRENTMONTH mo
               where mo.metercode = NewMeterCode) mm
       where mm.rn = 1;
    end if;
  end if;
  -------------------------
  select u.isaccount, u.userinfoid, u.usewatertypeid
    INTO IsAccount, userid, watertypeid
    from am_u_userinfo u
   where u.metercode = NewMeterCode;
  if (IsAccount is null or IsAccount = 0) then
    --修改用水量
    update MM_M_METERINFO m
       set m.METERCURRENTREADING = NewMeterCurrentReading,
           m.lastnumber          = lastnum
     where m.metercode = NewMeterCode;
    Results := 1;
  else
    --已经开账用户不能修改
    Results := 2;
  end if;
    insert into CEPRO(metercode,NUM,state) values (MeterCode,MeterCurrentReading,Results);
EXCEPTION

  WHEN NO_DATA_FOUND THEN
       errorMsg   := SUBSTR(SQLERRM, 1, 200);
    Results := 3;
  WHEN TOO_MANY_ROWS THEN
       errorMsg   := SUBSTR(SQLERRM, 1, 200);
    Results := 3;
  
  WHEN OTHERS THEN
    Results := 3;
       errorMsg   := SUBSTR(SQLERRM, 1, 200);
    ROLLBACK;
    insert into CEPRO(metercode,NUM,state,ERRORC) values (MeterCode,MeterCurrentReading,Results,errorMsg);
    
end RemoteMeterInsert;


/

