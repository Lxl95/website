create view V_B_CURRENTMONTHBILL as
select la.locatioareaid,
       la.locationareaname,
       co.communtyid,
       co.communtyname,
       mdcm."METERDATACURRENTMONTHID",
       mdcm."METERINFOID",
       mdcm."METERCODE",
       mdcm."LASTMONTHNUMBER",
       mdcm."READNUMBER",
       mdcm."CURRENTTRAFFIC",
       mdcm.ismakebill,
       mdcm.isstepstartmonth,
      nvl( mdcm.yearcyclesumflow,0) yearcyclesumflow,
       round((select AVG(currenttraffic)
               from MM_M_METERDATACURRENTMONTH t
              where meterinfoid = mdcm.meterinfoid
                and READDATE between add_months(mdcm.READDATE, -3) and
                    mdcm.READDATE),
             2) as avgCurrenttraffic,
       to_char(mdcm.READDATE,'yyyy-MM-dd') as READDATE,
       mdcm.addflow,
       ui.STEPPRICEITEMID,
       ui.LIMITUSEPRICEITEMID,
      ui.usewatertypeid as USEWATERTYPEID,
       ui.MIXWATERTYPEID,
       ui.MIXWATERTYPE,
       ui.MIXWATERRATE,
       ui.MIXWATERFLOW,
       ui.userinfocode,
       ui.siteid,
       ui.rosterid,
       ui.useraddress,
       ui.username,
       ui.userstate,
       r.rostercode,
       r.rostername,
       mdcm.meterreaderid,
       s.sitecode,
       s.sitename,
       mi.meterstate,
       ui.imageurl,
       ui.userinfoid,
       ui.meteraddress,
       ui.rosterorder,
       ui.personcount,
       wt.usewatertype,wt.usewatertypename,
       mdcm.NotMonths,
       case when ui.isenjoyprivilege is null then 0 else ui.isenjoyprivilege end as isenjoyprivilege
         ,nvl(upl.jmnumber,0) as jmnumber,ma.ismix,ui.cardid
  from MM_M_METERDATACURRENTMONTH mdcm
  join mm_m_meterinfo mi
    on mdcm.meterinfoid = mi.meterinfoid
  inner join AM_U_USERINFO ui
    on mi.userinfocode = ui.userinfocode
     LEFT JOIN bs_b_usewatertype wt
          ON mi.meterwatertypeid = wt.usewatertypeid

  join AM_R_ROSTER r
    on r.rosterid = ui.rosterid
  join SM_S_SITE s
    on r.siteid = s.siteid
  left join sm_p_locationarea la
    on ui.locatioareaid = la.locatioareaid
  left join bs_u_community co
    on ui.communtyid = co.communtyid
        left join am_u_userprivilege upl on upl.isenjoyprivilege=ui.isenjoyprivilege
   left join (select distinct m.meterinfoid,count(0) ismix  from bs_b_user_watertype_map m group by m.meterinfoid) ma on ma.meterinfoid=mi.meterinfoid


/

