create trigger WORK_COMMENT
    before insert
    on WORK_COMMENT
    for each row
begin
 select WORK_COMMENT_ID.nextval into:New.id from dual;
 end;
/

