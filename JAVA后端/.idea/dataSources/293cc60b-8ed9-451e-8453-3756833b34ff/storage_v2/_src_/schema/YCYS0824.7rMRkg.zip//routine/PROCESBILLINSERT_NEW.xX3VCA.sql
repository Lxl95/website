create PROCEDURE procesbillinsert_new (
      out_msg       OUT      VARCHAR2,
      out_result    OUT      INTEGER                                --返回信息
   )
   AS
      n_id              NUMBER;
      flown          NUMBER;
      ishave          NUMBER;
      dt_readdatelast      DATE;
      n_months     NUMBER;
      n_year   number;
      n_last     NUMBER;
      n_read   NUMBER;
      n_mid   NUMBER;
      ismakebill  NUMBER;
      monthid  NUMBER;
      n_userinfoid NUMBER;
      TYPE refcur IS REF CURSOR;

      cur_rec           refcur;


begin
  out_msg := '处理多条数据！';
      out_result := 0;

      OPEN cur_rec FOR
         --select to_number(a.currenttraffic) as currenttraffic,a.userinfoid,a.billyear,a.billmonth,
         --a.readdate,a.billid,a.lastmonthnumber,a.readnumber
         --from bill a where a.readdate>=TO_DATE('2017-10-01','yyyy-mm-dd');
         select a.userinfoid,a.meterinfoid,a.meterdatacurrentmonthid,a.currenttraffic,a.readdate,a.datayear,a.datamonth,lastmonthnumber,readnumber
         from mm_m_meterdatacurrentmonth a where 
         --a.ismakebill =0 and readdate>to_date('2017-01-01','yyyy-mm-dd') and userinfoid is not null;
 a.ismakebill =0 and a.readnumber>0  and readdate>to_date('2017-10-01','yyyy-mm-dd') and userinfoid is null;
      FETCH cur_rec
       INTO n_userinfoid,n_mid,n_id,flown,dt_readdatelast,n_year,n_months,n_last,n_read;--, dt_enddate, n_holidaytype, v_deptorgroup,
            --v_createempcode;

      WHILE (cur_rec%FOUND)
      LOOP
      select userinfoid into n_userinfoid from am_u_userinfo where meterinfoid = n_mid;
         select count(*) into ishave from  bill b
         where userinfoid =n_userinfoid and b.readdate= dt_readdatelast and b.currenttraffic=flown
         and b.billyear=n_year and b.billmonth = n_months and b.lastmonthnumber=n_last and b.readnumber=n_read; --除去他之外的最大值
                                                         --记录
         if ishave>0 then
         --select b.ismakebill,b.meterdatacurrentmonthid  into ismakebill,monthid from  mm_m_meterdatacurrentmonth b
         --where b.readdate= dt_readdatelast and b.currenttraffic=flown
         --and b.datayear=n_year and b.datamonth = n_months and b.lastmonthnumber=n_last and b.readnumber=n_read and userinfoid =n_userinfoid;

         --if ismakebill =0 then
         insert into mm_m_meterdatacmonth_bill (meterdatacurrentmonthid,ismakebill)
         values (n_id,1);
         update mm_m_meterdatacurrentmonth set ismakebill=1 where meterdatacurrentmonthid =n_id;
         --end if;
         end if;

         --and dpid=prmdpid

         FETCH cur_rec
          INTO n_userinfoid,n_mid,n_id,flown,dt_readdatelast,n_year,n_months,n_last,n_read;
      END LOOP;

      CLOSE cur_rec;
     out_msg := '处理补充数据成功！';
      COMMIT;

   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         out_result := 6;
         out_msg := TO_CHAR (SQLCODE) || '||||' || SQLERRM;

end procesbillinsert_new;


/

