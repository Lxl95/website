create procedure insertbp2 is
  paidmoney   number := 0;
  thisbalance number := 0;
  prestorein   number := 0;
  prestoreout number := 0;
  receivablemoney number := 0;
begin
  --开始游标
  declare
    cursor c_joba is
      select v.id,v.水费,v.排污费,v.附加费,v.上月结余,v.滞纳金,
      to_date((substr(v.收费日期,7,4)||'-'|| substr(v.收费日期,0,2)||'-'||Nvl(replace(substr(v.收费日期,4,1),' ',''),0)||substr(v.收费日期,5,1)),'yyyy-MM-dd') as 收费日期,
      replace(v.用户编号,' ','') as 用户编号,
      v.开始月份 vk,eu.开始月份 ek,v.结束月份 vj,eu.结束月份 ej,eu.实收款,eu.本月结余,v.流水号
        from view_historysf2 v
        left join enterprise_user eu
          on eu.流水号 = v.收费编码
         and replace(eu.用户编号,' ','') = replace(v.用户编号,' ','')
       where v.id in
             (select min(s.id) from view_historysf2 s group by s.newpayp);
       --order by v.用户编号 asc,v.开始月份 asc;
    c_rowa c_joba%rowtype;
  begin
    for c_rowa in c_joba loop
      receivablemoney := to_number(c_rowa.水费) + to_number(c_rowa.排污费) + to_number(c_rowa.附加费);
      --开始判断
      if to_number(c_rowa.vk) >= to_number(c_rowa.ek) and to_number(c_rowa.vj) < to_number(c_rowa.ej) then--开始
        paidmoney := 0;
        prestorein := 0;
        prestoreout := receivablemoney;
        thisbalance := to_number(c_rowa.上月结余) - prestoreout;
      end if;
      if to_number(c_rowa.vj) = to_number(c_rowa.ej) then--结束
        paidmoney := c_rowa.实收款;
        thisbalance := c_rowa.本月结余;
        if to_number(c_rowa.实收款) >= receivablemoney then
          prestorein := to_number(c_rowa.实收款) - receivablemoney;
          prestoreout := 0;
        else
          prestoreout := receivablemoney - to_number(c_rowa.实收款);
          prestorein := to_number(c_rowa.上月结余) - prestoreout;
        end if;
      end if;
      ----------------------
      begin
      Insert into b_paylog
        (paylog,
         receivablemoney,
         paidmoney,
         paidtype,
         prestorein,
         prestoreout,
         billids,
         lastbalance,
         thisbalance,
         latefine,
         ddatetime,
         paylogbatch,
         userinfoid)
      values
        (c_rowa.id,
        receivablemoney,
        paidmoney,
        1,
         prestorein,
         prestoreout,
        c_rowa.id,
        to_number(c_rowa.上月结余),
        thisbalance,
        to_number(c_rowa.滞纳金),
        to_date(c_rowa.收费日期,'yyyy-MM-dd'),
        c_rowa.用户编号 || '_' ||c_rowa.流水号 || '_' || c_rowa.上月结余,
        c_rowa.用户编号);
     exception
       when others then
         dbms_output.put_line(c_rowa.id);
         continue;
         end;
      ----------------------
    commit;
    end loop;
  end;
end insertbp2;


/

