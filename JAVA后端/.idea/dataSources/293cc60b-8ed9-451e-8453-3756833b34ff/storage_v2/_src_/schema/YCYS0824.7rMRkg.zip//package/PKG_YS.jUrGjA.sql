create package pkg_ys
as
TYPE ref_cursor is REF CURSOR;
procedure Bank_YC_PayInfoUpdate(UserCode     in VARCHAR2, --用户代码
                                                  TradeCode    in VARCHAR2, --交易码
                                                  BankCode     in VARCHAR2, --银行识别码
                                                  PayMoney     in VARCHAR2, --缴费金额
                                                  RunWaterCode in VARCHAR2, --委托方流水号
                                                  PayDate      in VARCHAR2, -- 记账日期 收费日期yyyymmdd
                                                  PayID        in VARCHAR2, --操作员

                                                  Results out VARCHAR2,
                                                  --retoutdatya  out VARCHAR2,
                                                  outdata out ref_cursor);
                                                  end pkg_ys;


/

